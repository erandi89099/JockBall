# JockBall - Fase 0 (proyecto base)

## Instalar (una sola vez)
1. JDK 25: https://adoptium.net (elige Temurin 25, Windows/Mac/Linux).
2. IntelliJ IDEA Community: https://www.jetbrains.com/idea/download
3. Descomprime esta carpeta, abre IntelliJ -> Open -> selecciona la carpeta `jockball`.
4. File > Project Structure > SDK = JDK 25. Settings > Build Tools > Gradle > Gradle JVM = 25.
5. Espera a que Gradle termine de descargar (la primera vez tarda varios minutos).
6. Arriba a la derecha, ejecuta la tarea `Minecraft Client` (o en terminal: `gradle runClient`).

## Que deberia pasar
Se abre Minecraft 26.2 con el mod cargado. En el log aparece:
"JockBall cargado. Fase 0: el proyecto base funciona."

Si falla algo, copiame el error completo (o captura) y lo corrijo.

## Texturas
`python3 tools/gen_textures.py` regenera las texturas provisionales (requiere Pillow).

## Fase 1 (armaduras, Trofeo, bonus de set)
- 20 piezas: casco, hombreras, fundas y tachos x 5 niveles. Estan en la pestana de Combate del modo creativo.
- Trofeo en la pestana de Ingredientes.
- Mejora: en la mesa de herreria pon la Plantilla de Mejora, la pieza (base) y 1 Trofeo (material); la plantilla se consume
  y la Plantilla de Mejora en la ranura de plantilla. Sube la pieza un nivel.
- Bonus de set: se usa el nivel de la pieza mas baja; si falta una pieza, no hay bonus.
- Balance: edita las tablas en gear/SetBonus.java y gear/GearLevel.java.
- Regenerar assets: python3 tools/gen_assets.py y python3 tools/gen_textures.py

## Obtener el .jar para la carpeta mods
Opcion A (local): en la carpeta del proyecto ejecuta `gradle build`. El archivo queda en build/libs/jockball-0.1.0.jar
(no uses el que termina en -sources.jar).
Opcion B (sin instalar nada): sube el proyecto a un repositorio de GitHub; en la pestana Actions, abre la ejecucion
"Compilar JockBall" y descarga el artefacto "jockball-jar".
Para jugar necesitas ademas Fabric Loader y Fabric API 0.150.1+26.2 (o superior) en la carpeta mods.

## Fase 2 (jugadores enemigos y capitan)
Comandos de prueba (mundo con trucos):
  /summon jockball:lineman ~ ~ ~              (reserva: equipo nivel 1-3 al azar)
  /summon jockball:lineman ~ ~ ~ {starter:1}  (titular: equipo nivel 4, mas vida/dano/velocidad)
  /summon jockball:captain ~ ~ ~              (jefe: nivel 5, barra de jefe, suelta el Trofeo)
Posiciones: lineman, running_back, receiver, linebacker, safety, captain.
Balance de enemigos: entity/Position.java.  Regenerar pieles: python3 tools/gen_entities.py

## Cambios Fase 2.1
- Arreglada la barra del capitan duplicada al morir el jugador.
- Distintivos: tamano por posicion (liniero enorme, corredor bajito, capitan gigante), nombre de la posicion
  sobre la cabeza (siempre visible en titulares con estrella y en el capitan; en reservas al apuntarles).
- Receptor: salto aumentado (entity/Position.java, columna "salto").

## Fase 3a (estadio por comando)
Comando: /jockball stadium   -> construye el estadio con el centro del campo donde estas parado.
- Tamano 193 x 241, hasta 44 bloques de alto. REEMPLAZA todo lo que haya en esa zona. Mejor en un mundo plano.
- Tarda unos segundos (se construye por tandas). Al terminar aparecen los 53 jugadores.
- Los jugadores nacen dormidos y despiertan al acercarte (reservas 20 bloques, titulares/capitan 35).
  Los jugadores en Creativo no son atacados: prueba en Supervivencia.
- 12 cofres con loot en los 2 vestidores (loot_table jockball:chests/locker_room).
- Diseno: stadium/StadiumDesign.java (constantes arriba). Jugadores: stadium/StadiumRoster.java.

## Fase 3b (estadios naturales, barra, reinicio)
- Los estadios aparecen solos: cada region de 1024x1024 tiene 60% de probabilidad de un estadio; se construye
  cuando te acercas a menos de 240 bloques (stadium/StadiumSites.java: REGION, CHANCE).
- /jockball locate  -> coordenadas del estadio mas cercano (aunque no se haya generado aun).
- /jockball stadium -> sigue funcionando para construir uno donde estes.
- Barra roja "Jugadores restantes: X/53" mientras estas dentro de un estadio.
- Al vencer al Capitan: mensaje de victoria y el estadio se reinicia a los 30 min (cuando no haya jugadores dentro):
  se reconstruye todo, se rellenan los cofres y vuelven los 53 jugadores.
- Los estadios del mundo se guardan en jockball_stadiums.txt (carpeta del mundo).

## Fase 3c (tienda de aldea y habilidades por posicion)
Tienda: al entrar a una aldea se construye UNA tienda en su orilla, con el frente hacia el centro de la aldea,
con materiales segun el bioma (llanura, desierto, sabana, taiga). Adentro: 4 cofres con loot (chests/shop), alfombra,
mostrador de vallas (el vendedor no puede pasar; comercias por encima), puerta a la trastienda con cama,
alto horno, barril y mesa. El "Vendedor de Equipo" vende: Plantilla de Mejora (12 esmeraldas) y equipo nivel 1-3
(4-6 / 10-14 / 24-32 esmeraldas). Precios en shop/ShopBuilder.java; diseno en shop/ShopDesign.java.
Probar: /locate structure minecraft:village_plains  (y /tp), entrar a la aldea y esperar unos segundos.

Habilidades (entity/ai):
- Apoyador y Capitan: ChargeGoal (taclada tipo cabra: prepara, embiste, empuja, queda aturdido).
- Liniero y Capitan: StompGoal (pisoton: fauces del invocador en linea y en circulo).
- Receptor: salta mientras persigue (FootballPlayer.positionAbilities). Corredor: se desvia de lado de golpe.
Todos los numeros estan al inicio de cada clase.
