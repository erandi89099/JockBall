# JockBall - Fase 0 (proyecto base)

## Instalar (una sola vez)
1. JDK 25: https://adoptium.net (elige Temurin 25, Windows/Mac/Linux).
2. IntelliJ IDEA Community: https://www.jetbrains.com/idea/download
3. Descomprime esta carpeta, abre IntelliJ -> Open -> selecciona la carpeta `jockball`.
4. File > Project Structure > SDK = JDK 25. Settings > Build Tools > Gradle > Gradle JVM = 25.
5. Espera a que Gradle termine de descargar (la primera vez tarda varios minutos).
6. Arriba a la derecha, ejecuta la tarea `Minecraft Client` (o en terminal: `gradle runClient`).

## Que deberia pasar
Se abre Minecraft 26.2 con el mod cargado. En el log aparece:
"JockBall cargado. Fase 0: el proyecto base funciona."

Si falla algo, copiame el error completo (o captura) y lo corrijo.

## Texturas
`python3 tools/gen_textures.py` regenera las texturas provisionales (requiere Pillow).

## Fase 1 (armaduras, Trofeo, bonus de set)
- 20 piezas: casco, hombreras, fundas y tachos x 5 niveles. Estan en la pestana de Combate del modo creativo.
- Trofeo en la pestana de Ingredientes.
- Mejora: en la mesa de herreria pon la Plantilla de Mejora, la pieza (base) y 1 Trofeo (material); la plantilla se consume
  y la Plantilla de Mejora en la ranura de plantilla. Sube la pieza un nivel.
- Bonus de set: se usa el nivel de la pieza mas baja; si falta una pieza, no hay bonus.
- Balance: edita las tablas en gear/SetBonus.java y gear/GearLevel.java.
- Regenerar assets: python3 tools/gen_assets.py y python3 tools/gen_textures.py

## Obtener el .jar para la carpeta mods
Opcion A (local): en la carpeta del proyecto ejecuta `gradle build`. El archivo queda en build/libs/jockball-0.1.0.jar
(no uses el que termina en -sources.jar).
Opcion B (sin instalar nada): sube el proyecto a un repositorio de GitHub; en la pestana Actions, abre la ejecucion
"Compilar JockBall" y descarga el artefacto "jockball-jar".
Para jugar necesitas ademas Fabric Loader y Fabric API 0.150.1+26.2 (o superior) en la carpeta mods.

## Fase 2 (jugadores enemigos y capitan)
Comandos de prueba (mundo con trucos):
  /summon jockball:lineman ~ ~ ~              (reserva: equipo nivel 1-3 al azar)
  /summon jockball:lineman ~ ~ ~ {starter:1}  (titular: equipo nivel 4, mas vida/dano/velocidad)
  /summon jockball:captain ~ ~ ~              (jefe: nivel 5, barra de jefe, suelta el Trofeo)
Posiciones: lineman, running_back, receiver, linebacker, safety, captain.
Balance de enemigos: entity/Position.java.  Regenerar pieles: python3 tools/gen_entities.py

## Cambios Fase 2.1
- Arreglada la barra del capitan duplicada al morir el jugador.
- Distintivos: tamano por posicion (liniero enorme, corredor bajito, capitan gigante), nombre de la posicion
  sobre la cabeza (siempre visible en titulares con estrella y en el capitan; en reservas al apuntarles).
- Receptor: salto aumentado (entity/Position.java, columna "salto").

## Fase 3a (estadio por comando)
Comando: /jockball stadium   -> construye el estadio con el centro del campo donde estas parado.
- Tamano 193 x 241, hasta 44 bloques de alto. REEMPLAZA todo lo que haya en esa zona. Mejor en un mundo plano.
- Tarda unos segundos (se construye por tandas). Al terminar aparecen los 53 jugadores.
- Los jugadores nacen dormidos y despiertan al acercarte (reservas 20 bloques, titulares/capitan 35).
  Los jugadores en Creativo no son atacados: prueba en Supervivencia.
- 12 cofres con loot en los 2 vestidores (loot_table jockball:chests/locker_room).
- Diseno: stadium/StadiumDesign.java (constantes arriba). Jugadores: stadium/StadiumRoster.java.

## Fase 3b (estadios naturales, barra, reinicio)
- Los estadios aparecen solos: cada region de 1024x1024 tiene 60% de probabilidad de un estadio; se construye
  cuando te acercas a menos de 240 bloques (stadium/StadiumSites.java: REGION, CHANCE).
- /jockball locate  -> coordenadas del estadio mas cercano (aunque no se haya generado aun).
- /jockball stadium -> sigue funcionando para construir uno donde estes.
- Barra roja "Jugadores restantes: X/53" mientras estas dentro de un estadio.
- Al vencer al Capitan: mensaje de victoria y el estadio se reinicia a los 30 min (cuando no haya jugadores dentro):
  se reconstruye todo, se rellenan los cofres y vuelven los 53 jugadores.
- Los estadios del mundo se guardan en jockball_stadiums.txt (carpeta del mundo).

## Fase 3c (tienda de aldea y habilidades por posicion)
Tienda: al entrar a una aldea se construye UNA tienda en su orilla, con el frente hacia el centro de la aldea,
con materiales segun el bioma (llanura, desierto, sabana, taiga). Adentro: 4 cofres con loot (chests/shop), alfombra,
mostrador de vallas (el vendedor no puede pasar; comercias por encima), puerta a la trastienda con cama,
alto horno, barril y mesa. El "Vendedor de Equipo" vende: Plantilla de Mejora (12 esmeraldas) y equipo nivel 1-3
(4-6 / 10-14 / 24-32 esmeraldas). Precios en shop/ShopBuilder.java; diseno en shop/ShopDesign.java.
Probar: /locate structure minecraft:village_plains  (y /tp), entrar a la aldea y esperar unos segundos.

Habilidades (entity/ai):
- Apoyador y Capitan: ChargeGoal (taclada tipo cabra: prepara, embiste, empuja, queda aturdido).
- Liniero y Capitan: StompGoal (pisoton: fauces del invocador en linea y en circulo).
- Receptor: salta mientras persigue (FootballPlayer.positionAbilities). Corredor: se desvia de lado de golpe.
Todos los numeros estan al inicio de cada clase.

## Fase 4 (equipo late game, loot, habilidades)
- El equipo NO da resistencia al empuje (ni las piezas ni el set). Nivel 1 = stats de netherite y de ahi sube.
- Bonus de set (gear/SetBonus.java, todo en tablas arriba): vida +2 corazones por nivel (24..40), fuerza, velocidad,
  armadura extra, saturacion y efectos: Resistencia I-III (niveles 3-5), Resistencia al fuego (4-5), Regeneracion I (5).
- F3+H sobre cualquier pieza muestra los bonus del set completo de su nivel (item/GearItem.java).
- Tienda: vende SOLO equipo nivel 1 por 64 esmeraldas + la pieza de netherite equivalente (casco, pechera->hombreras,
  pantalon->fundas, botas->tachos) y la Plantilla de Mejora por 64 esmeraldas + 1 lingote de netherite. (shop/ShopBuilder.java)
- Loot: cofres de tienda = cascos nivel 1 (1%), plantilla (3%), comida y recursos simples. Vestidores = tachos nivel 1 (2%),
  plantilla (3%), comida y recursos de late game (netherite, diamante, escombros, discos...). 
  Plantilla 10% en Ciudad Antigua, Ciudad del End y Minas; Warden, Dragon, Wither y Guardian Anciano 50% de soltar
  una pieza de nivel 1 (loot/LootInjector.java).
- Mobs: mas empuje sin tocar el dano (taclada 4.5, onda del pisoton 3.0 y radio 10, Levitacion IV 1 s), golpe del
  Safety = Ceguera 3 s, golpe del Apoyador = Lentitud III 1 s, el Receptor salta 3 bloques (y no sufre dano de caida),
  la hitbox sigue al tamano de cada posicion.
- Los generadores de tools/ ya NO se ejecutan solos (pisarian tus texturas): usa --force solo si quieres regenerar.

## Fase 5 (lo que faltaba del plan)
- Nuevos jugadores: QUARTERBACK (lanza balones), PATEADOR (mini-jefe, rafaga de 3 balones) y ENTRENADOR (mini-jefe:
  cada 8 s grita una jugada que da Fuerza y Velocidad a todo el equipo). Los 3 tienen barra de jefe propia y no sueltan nada.
  Roster de 53: 10 titulares + Capitan en el campo (el QB es uno de los titulares), entrenador en la banda, pateador en
  la zona de anotacion y 40 de reserva (gradas 18, pasillo 12, vestidores 10).
- Balon (item): clic derecho lo lanza (5 de dano + empuje). Receta: 4 cuero + 1 hilo -> 4 balones. (item/FootballItem.java)
- Capitan en 3 fases (entity/FootballPlayer.java, updatePhase): al 50% de vida MEDIO TIEMPO (llegan 4 titulares de
  refuerzo, barra azul) y al 25% ULTIMO CUARTO (+30% velocidad, habilidades a media espera, barra roja).
- Logros (data/jockball/advancement + Achievements.java): Equipo completo, Leyenda del campo (set nivel 5), Primer partido,
  Temporada regular (5), Playoffs (10), Campeon (20), Temporada perfecta (derrotar al Capitan sin recibir dano),
  Cambio de entrenador y Pateado.
- Sonidos: murmullo de multitud mientras estas dentro de un estadio y ovacion en las fases y la victoria; los jugadores
  ya no gruñen como zombis (golpe/muerte de jugador). Los OGG se generaron con ffmpeg y se pueden reemplazar por otros.
- Equipos con colores distintos: 5 paletas (rojo, azul, verde, morado, negro/naranja) segun la posicion del estadio.
- tools/gen_new_skins no existe como archivo: las pieles nuevas se hicieron con el mismo pintor de gen_entities.py.

## Fase 6 (ajustes)
- Maxiconvertor: 10 usos. Tabla: Trofeo 0.02%, pieza 4o set 0.03%, pieza 3er set 0.05%, Plantilla 1.5%; el resto
  Barrita de proteina / Manzana encantada / Bebida energetica (item/Maxiconvertor.java, metodo roll).
- Silbato: ya no afecta a jefes (capitan, pateador, entrenador, Wither, Dragon, Warden, Guardian Anciano).
- Reparacion: lingote de netherite en el yunque (data/jockball/tags/item/repairs_gear.json) y Reparacion (mending) ya funcionaba.
- Mapa de Estadio (item/StadiumMapItem.java): clic derecho -> mapa con la X del estadio mas cercano. Sale en cofres de la
  tienda (10%), mansiones (25%), ruinas submarinas grandes y barcos hundidos (15%) y lo venden los cartografos
  (24 esmeraldas + 1 brujula; shop/CartographerTrades.java). Los monumentos oceanicos de vanilla no tienen cofres.
- Barras de jefe: se quitan al instante al morir el jefe; se refrescan cada 5 ticks (alejarse, morir o reaparecer).
- Balon: mas dano de mobs (quarterback 6.5, pateador 8.5 por balon) y el que lanza el jugador SI daña a los enemigos.
  Pateador: de 5 a 10 balones en abanico (Multidisparo) cada 4 s.
- Entrenador: se esconde detras de un liniero (entity/ai/HideBehindGoal.java) o huye como el invocador.
- 1 pateador en cada zona de anotacion (53 jugadores: 11 en el campo + coach + 2 pateadores + 39 de reserva).
- 13 logros mas (23 en total).
- Colores de estadio por bioma: templado, calido, frio, selva/pantano, agua y montana/taiga (3-5 paletas cada uno).
