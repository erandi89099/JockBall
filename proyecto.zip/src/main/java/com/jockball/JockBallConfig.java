package com.jockball;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Opciones del mod en  config/jockball.properties  (se crea sola la primera vez; cambialas y reinicia el juego).
 */
public final class JockBallConfig {
    public static boolean naturalStadiums = true;   // los estadios aparecen solos al explorar
    public static double stadiumChance = 0.60;      // probabilidad de estadio por region de 1024x1024
    public static int resetMinutes = 30;            // minutos de juego hasta que un estadio ganado se reinicia
    public static boolean villageShops = true;      // las aldeas reciben su tienda de equipo
    public static double shopChance = 0.70;         // probabilidad de tienda por region de 512x512

    public static long resetTicks() {
        return resetMinutes * 60L * 20L;
    }

    public static void load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("jockball.properties");
        Properties p = new Properties();
        if (Files.exists(file)) {
            try (var in = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                p.load(in);
            } catch (IOException e) {
                JockBall.LOGGER.warn("No se pudo leer {}", file, e);
            }
        }
        naturalStadiums = Boolean.parseBoolean(p.getProperty("natural_stadiums", "true").trim());
        stadiumChance = clamp(parse(p, "stadium_chance", 0.60), 0.0, 1.0);
        resetMinutes = (int) Math.max(1, Math.round(parse(p, "stadium_reset_minutes", 30)));
        villageShops = Boolean.parseBoolean(p.getProperty("village_shops", "true").trim());
        shopChance = clamp(parse(p, "shop_chance", 0.70), 0.0, 1.0);

        String text = """
                # JockBall - configuracion (reinicia el juego para aplicar los cambios)

                # Los estadios aparecen solos al explorar (true/false). Con false solo existen los que crees con /jockball stadium
                natural_stadiums=%s

                # Probabilidad (0.0 a 1.0) de que cada region de 1024x1024 bloques tenga un estadio
                stadium_chance=%s

                # Minutos de juego que tarda un estadio en reiniciarse despues de vencer a su Capitan
                stadium_reset_minutes=%d

                # Las aldeas reciben una tienda de equipo (true/false)
                village_shops=%s

                # Probabilidad (0.0 a 1.0) de que cada region de 512x512 bloques tenga una tienda
                shop_chance=%s
                """.formatted(naturalStadiums, stadiumChance, resetMinutes, villageShops, shopChance);
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, text, StandardCharsets.UTF_8);
        } catch (IOException e) {
            JockBall.LOGGER.warn("No se pudo escribir {}", file, e);
        }
    }

    private static double parse(Properties p, String key, double fallback) {
        try {
            return Double.parseDouble(p.getProperty(key, String.valueOf(fallback)).trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private JockBallConfig() {}
}
