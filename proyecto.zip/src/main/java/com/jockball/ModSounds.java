package com.jockball;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;

/** Sonidos propios: murmullo de multitud (ambiente del estadio) y ovacion (fases del capitan y victoria). */
public final class ModSounds {
    public static final SoundEvent CROWD = register("crowd");
    public static final SoundEvent CHEER = register("cheer");

    private static SoundEvent register(String name) {
        Identifier id = JockBall.id(name);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    /** Reproduce un sonido en la posicion del jugador (lo oyen el y quien este a menos de 16 bloques). */
    public static void play(ServerPlayer player, SoundEvent sound, float volume) {
        player.level().playSound((Player) null, player.getX(), player.getY(), player.getZ(),
                sound, SoundSource.AMBIENT, volume, 1.0F);
    }

    /** Fuerza la carga de la clase (registra los sonidos). */
    public static void initialize() {}

    private ModSounds() {}
}
