package com.jockball;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

/** Sonidos propios: murmullo de multitud (ambiente del estadio) y ovacion (fases del capitan y victoria). */
public final class ModSounds {
    public static final SoundEvent CROWD = register("crowd");
    public static final SoundEvent CHEER = register("cheer");

    private static SoundEvent register(String name) {
        Identifier id = JockBall.id(name);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    /** Fuerza la carga de la clase (registra los sonidos). */
    public static void initialize() {}

    private ModSounds() {}
}
