package com.jockball.item;

import com.jockball.Achievements;
import com.jockball.stadium.StadiumSites;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.maps.MapDecorationTypes;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;

/**
 * Mapa de Estadio: al usarlo (clic derecho) se convierte en un mapa de verdad con una X roja sobre el estadio
 * mas cercano a ti (aunque aun no se haya generado: los sitios salen de la semilla del mundo). Solo en el Overworld.
 */
public class StadiumMapItem extends Item {
    public StadiumMapItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level instanceof ServerLevel serverLevel && player instanceof ServerPlayer sp) {
            if (serverLevel.dimension() != Level.OVERWORLD) {
                sp.sendSystemMessage(Component.translatable("jockball.map.overworld"));
                return InteractionResult.FAIL;
            }
            int[] site = StadiumSites.nearest(serverLevel.getSeed(), player.getBlockX(), player.getBlockZ());
            if (site == null) {
                sp.sendSystemMessage(Component.translatable("jockball.map.none"));
                return InteractionResult.FAIL;
            }
            ItemStack map = MapItem.create(serverLevel, site[0], site[1], (byte) 2, true, true);
            MapItem.renderBiomePreviewMap(serverLevel, map);
            MapItemSavedData.addTargetDecoration(map, new BlockPos(site[0], 64, site[1]), "+", MapDecorationTypes.RED_X);
            map.set(DataComponents.ITEM_NAME, Component.translatable("item.jockball.stadium_map.filled"));
            player.getItemInHand(hand).consume(1, player);
            if (!player.getInventory().add(map)) {
                player.drop(map, false);
            }
            Achievements.award(sp, "scout");
        }
        return InteractionResult.SUCCESS;
    }
}
