package com.jockball.item;

import com.jockball.gear.Fx;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

import java.util.List;

/** Silbato: al soplarlo, todos los enemigos a 5 bloques reciben Lentitud X por 3 segundos. Se consume. */
public class Whistle extends Item {
    private static final double RADIUS = 5.0;
    private static final int TICKS = 60;      // 3 segundos
    private static final int AMPLIFIER = 9;   // 9 = nivel X (10)

    public Whistle(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level instanceof ServerLevel serverLevel) {
            List<LivingEntity> enemies = serverLevel.getEntitiesOfClass(LivingEntity.class,
                    player.getBoundingBox().inflate(RADIUS),
                    e -> e != player && e.getType().getCategory() == MobCategory.MONSTER
                            && e.distanceTo(player) <= RADIUS);
            for (LivingEntity enemy : enemies) {
                enemy.addEffect(new MobEffectInstance(Fx.get("slowness"), TICKS, AMPLIFIER));
            }
            player.playSound(SoundEvents.ARROW_SHOOT, 1.0F, 2.0F);
            player.getItemInHand(hand).consume(1, player);
        }
        return InteractionResult.SUCCESS;
    }
}
