package com.jockball.item;

import com.jockball.gear.SetBonus;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;

import java.util.function.Consumer;

/** Pieza de equipo: con F3+H muestra los bonus del set completo de su nivel. */
public class GearItem extends Item {
    private final int level;

    public GearItem(Properties properties, int level) {
        super(properties);
        this.level = level;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, TooltipDisplay display,
                                Consumer<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, display, tooltip, flag);
        if (flag.isAdvanced()) { // solo con F3+H
            SetBonus.describe(level).forEach(tooltip);
        }
    }
}
