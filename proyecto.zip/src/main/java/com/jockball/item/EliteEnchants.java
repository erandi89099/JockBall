package com.jockball.item;

import com.jockball.JockBall;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;

/**
 * Encantamientos del Balon de Elite. Lealtad y Perforacion son PROPIOS (data/jockball/enchantment): los de vanilla
 * son del tridente y la ballesta y traerian consigo Impalador, Disparo multiple, etc. Filo, Irrompibilidad y
 * Reparacion son los de vanilla (el balon esta en sus etiquetas de objetos soportados).
 */
public final class EliteEnchants {
    public static final ResourceKey<Enchantment> LOYALTY =
            ResourceKey.create(Registries.ENCHANTMENT, JockBall.id("ball_loyalty"));
    public static final ResourceKey<Enchantment> PIERCING =
            ResourceKey.create(Registries.ENCHANTMENT, JockBall.id("ball_piercing"));

    public static int level(ServerLevel level, ItemStack stack, ResourceKey<Enchantment> key) {
        return level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).get(key)
                .map(holder -> EnchantmentHelper.getItemEnchantmentLevel(holder, stack))
                .orElse(0);
    }

    public static int sharpness(ServerLevel level, ItemStack stack) {
        return level(level, stack, Enchantments.SHARPNESS);
    }

    private EliteEnchants() {}
}
