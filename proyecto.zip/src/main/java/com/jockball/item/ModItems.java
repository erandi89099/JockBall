package com.jockball.item;

import com.jockball.JockBall;
import com.jockball.entity.ModEntities;
import com.jockball.entity.Position;
import com.jockball.gear.Fx;
import com.jockball.gear.GearLevel;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.world.item.consume_effects.ApplyStatusEffectsConsumeEffect;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public final class ModItems {
    /** Nombres de las 4 piezas, en el orden de ArmorType: casco, pecho, fundas, botas. */
    public static final String[] PIECE_NAMES = {"helmet", "shoulder_pads", "pants", "cleats"};
    private static final ArmorType[] PIECE_TYPES =
            {ArmorType.HELMET, ArmorType.CHESTPLATE, ArmorType.LEGGINGS, ArmorType.BOOTS};

    /** GEAR[nivel-1][pieza] */
    public static final Item[][] GEAR = new Item[GearLevel.MAX][4];
    /** Nivel (1-5) de cada pieza de JockBall. */
    public static final Map<Item, Integer> LEVEL_OF = new HashMap<>();

    public static final Item TROPHY = register("trophy", Item::new, new Item.Properties());
    /** Plantilla de herreria: se consume en cada mejora, igual que la de netherite. */
    public static final Item UPGRADE_TEMPLATE = register("upgrade_template", Item::new, new Item.Properties());

    /** Balon: se lanza con clic derecho (5 de dano + empuje). Receta: 4 cuero + 1 hilo -> 4 balones. */
    public static final Item FOOTBALL = register("football", FootballItem::new, new Item.Properties().stacksTo(16));

    /** Balon de Elite: 8 netherite + balon. Durable y encantable; solo se obtiene crafteandolo. */
    public static final Item ELITE_FOOTBALL = register("elite_football", EliteFootballItem::new,
            new Item.Properties().stacksTo(1).durability(2031).enchantable(15));

    /** Disco "Pass": musica original del mod (jukebox_song jockball:pass). Solo sale en los estadios. */
    public static final Item PASS_DISC = register("music_disc_pass", Item::new, new Item.Properties().stacksTo(1)
            .rarity(Rarity.RARE)
            .jukeboxPlayable(ResourceKey.create(Registries.JUKEBOX_SONG, JockBall.id("pass"))));

    /** Mapa de Estadio: clic derecho y se convierte en un mapa con la X del estadio mas cercano. */
    public static final Item STADIUM_MAP = register("stadium_map", StadiumMapItem::new, new Item.Properties().stacksTo(16));

    // ---- objetos de utilidad ----
    /** Silbato: consumible, stack de 64. Lentitud X a los enemigos a 5 bloques por 3 s (ver Whistle). */
    public static final Item WHISTLE = register("whistle", Whistle::new, new Item.Properties().stacksTo(64));
    /** Bebida energetica: Resistencia X por 5 s + Fuerza C (100) por 1 s. Stack de 16. */
    public static final Item ENERGY_DRINK = register("energy_drink", Item::new, energyDrinkProps());
    /** Barrita de proteina: Velocidad X 5 s, Regeneracion X 10 s, Fuerza V 20 s. Solo sale del Maxiconvertor. */
    public static final Item PROTEIN_BAR = register("protein_bar", Item::new, proteinBarProps());
    /** Maxiconvertor: convierte mobs pacificos en objetos al azar. Encantable (Reparacion e Irrompibilidad). */
    public static final Item MAXICONVERTOR = register("maxiconvertor", Maxiconvertor::new,
            new Item.Properties().durability(10).enchantable(15));

    private static Item.Properties energyDrinkProps() {
        Consumable drink = Consumable.builder()
                .onConsume(new ApplyStatusEffectsConsumeEffect(List.of(
                        new MobEffectInstance(Fx.get("resistance"), 100, 9),   // Resistencia X, 5 s
                        new MobEffectInstance(Fx.get("strength"), 20, 99))))   // Fuerza C (100), 1 s
                .build();
        return new Item.Properties().stacksTo(16).component(DataComponents.CONSUMABLE, drink);
    }

    private static Item.Properties proteinBarProps() {
        Consumable bar = Consumable.builder()
                .onConsume(new ApplyStatusEffectsConsumeEffect(List.of(
                        new MobEffectInstance(Fx.get("speed"), 100, 9),          // Velocidad X, 5 s
                        new MobEffectInstance(Fx.get("regeneration"), 200, 9),   // Regeneracion X, 10 s
                        new MobEffectInstance(Fx.get("strength"), 400, 4))))     // Fuerza V, 20 s
                .build();
        FoodProperties food = new FoodProperties.Builder().nutrition(4).saturationModifier(0.6F).alwaysEdible().build();
        return new Item.Properties().food(food, bar);
    }

    static {
        for (int level = 1; level <= GearLevel.MAX; level++) {
            ArmorMaterial material = GearLevel.material(level);
            final int lv = level;
            for (int p = 0; p < 4; p++) {
                Item item = register(
                        PIECE_NAMES[p] + "_l" + level,
                        props -> new GearItem(props, lv),
                        new Item.Properties()
                                .humanoidArmor(material, PIECE_TYPES[p])
                                .durability(PIECE_TYPES[p].getDurability(GearLevel.baseDurability(level))));
                GEAR[level - 1][p] = item;
                LEVEL_OF.put(item, level);
            }
        }
    }

    /** Objetos con una linea de descripcion siempre visible (clave item.jockball.<nombre>.desc).
     *  Es una funcion (no un campo) a proposito: los objetos de arriba se registran antes que cualquier campo de abajo. */
    /** Huevos de aparicion de cada jugador (solo creativo). Salen despiertos, como jugadores de reserva. */
    public static final Map<Position, Item> SPAWN_EGGS = new java.util.EnumMap<>(Position.class);

    static {
        for (Position pos : Position.values()) {
            SPAWN_EGGS.put(pos, register(pos.id + "_spawn_egg", SpawnEggItem::new,
                    new Item.Properties().spawnEgg(ModEntities.TYPES.get(pos))));
        }
    }

    private static boolean hasDescription(String name) {
        return switch (name) {
            case "trophy", "upgrade_template", "whistle", "football", "stadium_map",
                 "maxiconvertor", "energy_drink", "protein_bar", "elite_football" -> true;
            default -> false;
        };
    }

    private static Item register(String name, Function<Item.Properties, Item> factory, Item.Properties props) {
        if (hasDescription(name)) {
            props.component(DataComponents.LORE, new ItemLore(List.of(
                    Component.translatable("item.jockball." + name + ".desc").withStyle(ChatFormatting.GRAY))));
        }
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, JockBall.id(name));
        Item item = factory.apply(props.setId(key));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    /** Nivel de una pieza, o 0 si no es equipamiento de JockBall. */
    public static int levelOf(net.minecraft.world.item.ItemStack stack) {
        return LEVEL_OF.getOrDefault(stack.getItem(), 0);
    }

    public static void initialize() {
        // pestana propia en el creativo con TODO el mod
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB,
                ResourceKey.create(Registries.CREATIVE_MODE_TAB, JockBall.id("main")),
                FabricCreativeModeTab.builder()
                        .icon(() -> new ItemStack(GEAR[4][0]))
                        .title(Component.translatable("creativeTab.jockball"))
                        .displayItems((params, output) -> {
                            for (Item[] row : GEAR) {
                                for (Item item : row) output.accept(item);
                            }
                            output.accept(TROPHY);
                            output.accept(UPGRADE_TEMPLATE);
                            output.accept(WHISTLE);
                            output.accept(FOOTBALL);
                            output.accept(ELITE_FOOTBALL);
                            output.accept(PASS_DISC);
                            output.accept(STADIUM_MAP);
                            output.accept(MAXICONVERTOR);
                            output.accept(ENERGY_DRINK);
                            output.accept(PROTEIN_BAR);
                            SPAWN_EGGS.values().forEach(output::accept);
                        })
                        .build());
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(tab -> {
            for (Item[] row : GEAR) {
                for (Item item : row) {
                    tab.accept(item);
                }
            }
        });
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.SPAWN_EGGS).register(tab -> SPAWN_EGGS.values().forEach(tab::accept));
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS).register(tab -> {
            tab.accept(TROPHY);
            tab.accept(UPGRADE_TEMPLATE);
        });
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.FOOD_AND_DRINKS).register(tab -> {
            tab.accept(ENERGY_DRINK);
            tab.accept(PROTEIN_BAR);
        });
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(tab -> {
            tab.accept(WHISTLE);
            tab.accept(FOOTBALL);
            tab.accept(ELITE_FOOTBALL);
            tab.accept(STADIUM_MAP);
            tab.accept(MAXICONVERTOR);
        });
    }

    private ModItems() {}
}
