package com.jockball.item;

import com.jockball.Achievements;
import com.jockball.entity.EliteFootballProjectile;
import com.jockball.entity.ModEntities;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Balon de Elite: 8 lingotes de netherite alrededor de un balon. Solo se obtiene crafteandolo.
 * Clic derecho lo lanza (9 de dano + Filo); pierde 1 de durabilidad por lanzamiento y NO se gasta:
 * con Lealtad vuelve a tu mano, sin ella cae al suelo como objeto.
 * Encantable con Lealtad, Perforacion, Filo, Irrompibilidad y Reparacion.
 */
public class EliteFootballItem extends Item {
    private static final float BASE_DAMAGE = 9.0F;
    private static final float SPEED = 2.2F;

    public EliteFootballItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level instanceof ServerLevel serverLevel && player instanceof ServerPlayer sp) {
            ItemStack inHand = player.getItemInHand(hand);
            int loyalty = EliteEnchants.level(serverLevel, inHand, EliteEnchants.LOYALTY);
            int piercing = EliteEnchants.level(serverLevel, inHand, EliteEnchants.PIERCING);
            int sharp = EliteEnchants.sharpness(serverLevel, inHand);
            // Filo como en vanilla: +0.5 por nivel y +0.5 base
            float damage = BASE_DAMAGE + (sharp > 0 ? 0.5F * sharp + 0.5F : 0.0F);

            boolean creative = sp.getAbilities().instabuild;
            ItemStack thrown = inHand.copyWithCount(1);
            thrown.hurtAndBreak(1, serverLevel, sp, broken -> { }); // Irrompibilidad aplica sola

            EliteFootballProjectile ball = new EliteFootballProjectile(ModEntities.ELITE_FOOTBALL, serverLevel);
            ball.setOwner(sp);
            ball.setPos(player.getX(), player.getEyeY() - 0.1, player.getZ());
            ball.setItem(inHand.copyWithCount(1)); // asi se ve con el brillo de encantado
            ball.init(thrown, loyalty, piercing, damage, creative);
            ball.shootFromRotation(sp, sp.getXRot(), sp.getYRot(), 0.0F, SPEED, 1.0F);
            serverLevel.addFreshEntity(ball);

            if (!creative) {
                player.setItemInHand(hand, ItemStack.EMPTY);
            }
            player.playSound(SoundEvents.SNOWBALL_THROW, 0.6F, 0.4F);
            Achievements.award(sp, "elite");
        }
        return InteractionResult.SUCCESS;
    }
}
