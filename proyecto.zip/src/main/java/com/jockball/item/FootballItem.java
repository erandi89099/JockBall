package com.jockball.item;

import com.jockball.entity.FootballProjectile;
import com.jockball.entity.ModEntities;
import com.jockball.Achievements;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Balon de futbol americano: clic derecho para lanzarlo (hace dano y empuja; SI daña a los jugadores enemigos). Se craftea con cuero. */
public class FootballItem extends Item {
    private static final float DAMAGE = 6.0F;
    private static final float SPEED = 1.8F;

    public FootballItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level instanceof ServerLevel serverLevel) {
            FootballProjectile ball = new FootballProjectile(ModEntities.FOOTBALL, serverLevel);
            ball.setOwner(player);
            ball.setPos(player.getX(), player.getEyeY() - 0.1, player.getZ());
            ball.setItem(new ItemStack(ModItems.FOOTBALL));
            ball.setDamage(DAMAGE);
            ball.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, SPEED, 1.0F);
            serverLevel.addFreshEntity(ball);
            player.playSound(SoundEvents.SNOWBALL_THROW, 0.5F, 0.6F);
            player.getItemInHand(hand).consume(1, player);
            if (player instanceof ServerPlayer sp) Achievements.award(sp, "ball");
        }
        return InteractionResult.SUCCESS;
    }
}
