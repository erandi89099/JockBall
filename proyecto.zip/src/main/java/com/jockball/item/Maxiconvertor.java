package com.jockball.item;

import net.minecraft.core.particles.ParticleTypes;
import com.jockball.Achievements;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Maxiconvertor: clic derecho sobre un mob pacifico y lo convierte (el mob desaparece) en un objeto al azar:
 *   Barrita de proteina (~66%), Manzana encantada (~20%), Bebida energetica (~13%), Plantilla de mejora (1.5%),
 *   pieza del 3er set (0.05%), pieza del 4o set (0.03%) y Trofeo (0.02%).
 * No funciona con jugadores, aldeanos, mascotas/domables ni mobs con nombre. Gasta 1 de durabilidad (10 usos).
 */
public class Maxiconvertor extends Item {
    public Maxiconvertor(Properties properties) {
        super(properties);
    }

    private static boolean isPeaceful(LivingEntity target) {
        if (target instanceof Player || target instanceof OwnableEntity || target.hasCustomName()) return false;
        MobCategory c = target.getType().getCategory();
        return c == MobCategory.CREATURE || c == MobCategory.AMBIENT || c == MobCategory.WATER_CREATURE
                || c == MobCategory.WATER_AMBIENT || c == MobCategory.UNDERGROUND_WATER_CREATURE
                || c == MobCategory.AXOLOTLS;
    }

    /**
     * Tabla de probabilidades (acumuladas, de lo mas raro a lo mas comun). AJUSTA AQUI:
     *   Trofeo 0.02% | pieza del 4o set 0.03% | pieza del 3er set 0.05% | Plantilla de mejora 1.5%
     *   y el 98.4% restante: Barrita de proteina (2/3), Manzana encantada (1/5) y Bebida energetica (el resto).
     */
    private static ItemStack roll(LivingEntity target) {
        double r = target.getRandom().nextDouble() * 100.0;
        if (r < 0.02) return new ItemStack(ModItems.TROPHY);
        if (r < 0.05) return new ItemStack(ModItems.GEAR[3][target.getRandom().nextInt(4)]); // 4o set
        if (r < 0.10) return new ItemStack(ModItems.GEAR[2][target.getRandom().nextInt(4)]); // 3er set
        if (r < 1.60) return new ItemStack(ModItems.UPGRADE_TEMPLATE);
        double rest = (r - 1.60) / 98.4;
        if (rest < 0.667) return new ItemStack(ModItems.PROTEIN_BAR);
        if (rest < 0.867) return new ItemStack(Items.ENCHANTED_GOLDEN_APPLE);
        return new ItemStack(ModItems.ENERGY_DRINK);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target,
                                                  InteractionHand hand) {
        if (!isPeaceful(target)) return InteractionResult.PASS;
        if (player.level() instanceof ServerLevel level) {
            double x = target.getX(), y = target.getY(), z = target.getZ();
            ItemStack result = roll(target);
            target.playSound(SoundEvents.ENCHANTMENT_TABLE_USE, 1.0F, 1.0F);
            level.sendParticles(ParticleTypes.POOF, x, y + 0.5, z, 20, 0.3, 0.3, 0.3, 0.05);
            target.discard();
            level.addFreshEntity(new ItemEntity(level, x, y + 0.3, z, result));
            if (player instanceof ServerPlayer sp) Achievements.award(sp, "converter");
            stack.hurtAndBreak(1, player, hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
        }
        return InteractionResult.SUCCESS;
    }
}
