package com.jockball.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Maxiconvertor: clic derecho sobre un mob pacifico y lo convierte (el mob desaparece) en un objeto al azar:
 *   50% Barrita de proteina | 15% Plantilla de mejora | 15% Manzana encantada | 10% Bebida energetica
 *    5% pieza del 3er set   |  3% pieza del 4o set    |  2% Trofeo
 * No funciona con jugadores, aldeanos, mascotas/domables ni mobs con nombre. Gasta 1 de durabilidad.
 */
public class Maxiconvertor extends Item {
    public Maxiconvertor(Properties properties) {
        super(properties);
    }

    private static boolean isPeaceful(LivingEntity target) {
        if (target instanceof Player || target instanceof OwnableEntity || target.hasCustomName()) return false;
        MobCategory c = target.getType().getCategory();
        return c == MobCategory.CREATURE || c == MobCategory.AMBIENT || c == MobCategory.WATER_CREATURE
                || c == MobCategory.WATER_AMBIENT || c == MobCategory.UNDERGROUND_WATER_CREATURE
                || c == MobCategory.AXOLOTLS;
    }

    private static ItemStack roll(LivingEntity target) {
        int r = target.getRandom().nextInt(100);
        if (r < 50) return new ItemStack(ModItems.PROTEIN_BAR);
        if (r < 65) return new ItemStack(ModItems.UPGRADE_TEMPLATE);
        if (r < 80) return new ItemStack(Items.ENCHANTED_GOLDEN_APPLE);
        if (r < 90) return new ItemStack(ModItems.ENERGY_DRINK);
        if (r < 95) return new ItemStack(ModItems.GEAR[2][target.getRandom().nextInt(4)]); // 3er set
        if (r < 98) return new ItemStack(ModItems.GEAR[3][target.getRandom().nextInt(4)]); // 4o set
        return new ItemStack(ModItems.TROPHY);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target,
                                                  InteractionHand hand) {
        if (!isPeaceful(target)) return InteractionResult.PASS;
        if (player.level() instanceof ServerLevel level) {
            double x = target.getX(), y = target.getY(), z = target.getZ();
            ItemStack result = roll(target);
            target.playSound(SoundEvents.ENCHANTMENT_TABLE_USE, 1.0F, 1.0F);
            level.sendParticles(ParticleTypes.POOF, x, y + 0.5, z, 20, 0.3, 0.3, 0.3, 0.05);
            target.discard();
            level.addFreshEntity(new ItemEntity(level, x, y + 0.3, z, result));
            stack.hurtAndBreak(1, player, hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
        }
        return InteractionResult.SUCCESS;
    }
}
