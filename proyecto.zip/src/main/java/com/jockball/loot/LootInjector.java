package com.jockball.loot;

import com.jockball.item.ModItems;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;

import java.util.List;

/**
 * Anade nuestro botin a las tablas de loot de vanilla:
 *  - Plantilla de Mejora: 10% en Ciudad Antigua, Ciudad del End y Minas abandonadas.
 *  - Warden, Ender Dragon, Wither y Guardian Anciano: 50% de soltar UNA pieza de equipo viejo (nivel 1) al azar.
 * AJUSTA AQUI las probabilidades.
 */
public final class LootInjector {
    private static final float TEMPLATE_CHANCE = 0.10F;
    private static final float BOSS_CHANCE = 0.50F;

    private static ResourceKey<LootTable> table(String path) {
        return ResourceKey.create(Registries.LOOT_TABLE, Identifier.withDefaultNamespace(path));
    }

    public static void initialize() {
        List<ResourceKey<LootTable>> templateTables = List.of(
                table("chests/ancient_city"), table("chests/ancient_city_ice_box"),
                table("chests/end_city_treasure"), table("chests/abandoned_mineshaft"));
        List<ResourceKey<LootTable>> bossTables = List.of(
                table("entities/warden"), table("entities/ender_dragon"),
                table("entities/wither"), table("entities/elder_guardian"));

        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
            if (templateTables.contains(key)) {
                tableBuilder.withPool(LootPool.lootPool()
                        .setRolls(ConstantValue.exactly(1.0F))
                        .when(LootItemRandomChanceCondition.randomChance(TEMPLATE_CHANCE))
                        .add(LootItem.lootTableItem(ModItems.UPGRADE_TEMPLATE)));
            } else if (bossTables.contains(key)) {
                LootPool.Builder pool = LootPool.lootPool()
                        .setRolls(ConstantValue.exactly(1.0F))
                        .when(LootItemRandomChanceCondition.randomChance(BOSS_CHANCE));
                for (Item piece : ModItems.GEAR[0]) { // las 4 piezas de nivel 1, igual de probables
                    pool.add(LootItem.lootTableItem(piece));
                }
                tableBuilder.withPool(pool);
            }
        });
    }

    private LootInjector() {}
}
