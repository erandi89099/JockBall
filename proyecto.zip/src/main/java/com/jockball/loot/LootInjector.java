package com.jockball.loot;

import com.jockball.item.ModItems;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;

import java.util.List;

/**
 * Anade nuestro botin a las tablas de loot de vanilla:
 *  - Plantilla de Mejora: 10% en Ciudad Antigua, Ciudad del End y Minas abandonadas.
 *  - Warden, Ender Dragon, Wither y Guardian Anciano: 30% de soltar UNA pieza de equipo viejo (nivel 1) al azar.
 *  - Silbato: 15% y Bebida Energetica: 10% en los cofres de CUALQUIER estructura de vanilla.
 *  - Maxiconvertor: 1% de Warden y Guardian Anciano (el Capitan lo suelta desde su propia tabla, captain.json).
 * (Los cofres de la tienda y del estadio se editan en sus .json: data/jockball/loot_table/chests/.)
 * AJUSTA AQUI las probabilidades.
 */
public final class LootInjector {
    private static final float TEMPLATE_CHANCE = 0.10F;
    private static final float BOSS_PIECE_CHANCE = 0.30F;
    private static final float WHISTLE_CHANCE = 0.15F;
    private static final float DRINK_CHANCE = 0.10F;
    private static final float MAXICONVERTOR_CHANCE = 0.01F;

    private static ResourceKey<LootTable> table(String path) {
        return ResourceKey.create(Registries.LOOT_TABLE, Identifier.withDefaultNamespace(path));
    }

    private static LootPool.Builder chancePool(float chance, Item item) {
        return LootPool.lootPool()
                .setRolls(ConstantValue.exactly(1.0F))
                .when(LootItemRandomChanceCondition.randomChance(chance))
                .add(LootItem.lootTableItem(item));
    }

    /** Cofres de estructuras de vanilla (sin el cofre de bonificacion ni los dispensadores de trampa). */
    private static boolean isStructureChest(ResourceKey<LootTable> key) {
        String name = key.toString();
        return name.contains("minecraft:chests/")
                && !name.contains("spawn_bonus_chest")
                && !name.contains("dispenser");
    }

    public static void initialize() {
        List<ResourceKey<LootTable>> templateTables = List.of(
                table("chests/ancient_city"), table("chests/ancient_city_ice_box"),
                table("chests/end_city_treasure"), table("chests/abandoned_mineshaft"));
        List<ResourceKey<LootTable>> bossTables = List.of(
                table("entities/warden"), table("entities/ender_dragon"),
                table("entities/wither"), table("entities/elder_guardian"));
        List<ResourceKey<LootTable>> maxiTables = List.of(
                table("entities/warden"), table("entities/elder_guardian"));

        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
            if (templateTables.contains(key)) {
                tableBuilder.withPool(chancePool(TEMPLATE_CHANCE, ModItems.UPGRADE_TEMPLATE));
            }
            if (bossTables.contains(key)) {
                LootPool.Builder pool = LootPool.lootPool()
                        .setRolls(ConstantValue.exactly(1.0F))
                        .when(LootItemRandomChanceCondition.randomChance(BOSS_PIECE_CHANCE));
                for (Item piece : ModItems.GEAR[0]) { // las 4 piezas de nivel 1, igual de probables
                    pool.add(LootItem.lootTableItem(piece));
                }
                tableBuilder.withPool(pool);
            }
            if (maxiTables.contains(key)) {
                tableBuilder.withPool(chancePool(MAXICONVERTOR_CHANCE, ModItems.MAXICONVERTOR));
            }
            if (isStructureChest(key)) {
                tableBuilder.withPool(chancePool(WHISTLE_CHANCE, ModItems.WHISTLE));
                tableBuilder.withPool(chancePool(DRINK_CHANCE, ModItems.ENERGY_DRINK));
            }
        });
    }

    private LootInjector() {}
}
