package com.jockball;

import com.jockball.gear.SetBonus;
import com.jockball.entity.ModEntities;
import com.jockball.entity.NoJump;
import com.jockball.item.ModItems;
import com.jockball.loot.LootInjector;
import com.jockball.stadium.StadiumBuilder;
import com.jockball.shop.CartographerTrades;
import com.jockball.shop.ShopSites;
import com.jockball.stadium.StadiumBar;
import com.jockball.stadium.StadiumCommand;
import com.jockball.stadium.StadiumRegistry;
import com.jockball.stadium.StadiumSites;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JockBall implements ModInitializer {
    public static final String MOD_ID = "jockball";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModSounds.initialize();
        ModItems.initialize();
        SetBonus.initialize();
        ModEntities.initialize();
        NoJump.initialize();
        StadiumRegistry.initialize();
        StadiumBuilder.initialize();
        StadiumSites.initialize();
        StadiumBar.initialize();
        ShopSites.initialize();
        LootInjector.initialize();
        CartographerTrades.initialize();
        StadiumCommand.initialize();
        LOGGER.info("JockBall cargado: Fase 4 (equipo late game, loot y habilidades).");
    }
}
