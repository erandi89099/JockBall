package com.jockball;

import com.jockball.gear.SetBonus;
import com.jockball.entity.ModEntities;
import com.jockball.item.ModItems;
import com.jockball.stadium.StadiumBuilder;
import com.jockball.stadium.StadiumCommand;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JockBall implements ModInitializer {
    public static final String MOD_ID = "jockball";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModItems.initialize();
        SetBonus.initialize();
        ModEntities.initialize();
        StadiumBuilder.initialize();
        StadiumCommand.initialize();
        LOGGER.info("JockBall cargado: Fase 3a (estadio por comando).");
    }
}
