package com.jockball.stadium;

import com.jockball.JockBall;
import com.jockball.entity.FootballPlayer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Construye el estadio por tandas (~30 ms por tick). Pide los chunks por adelantado para que se generen
 * en segundo plano, y espera a que esten listos en vez de congelar el juego.
 * reset = true: reinicio de un estadio ya existente (limpia jugadores viejos y rellena los cofres).
 */
public final class StadiumBuilder {
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;
    private static final int LOOKAHEAD = 10;
    private static final ResourceKey<LootTable> LOCKER_LOOT =
            ResourceKey.create(Registries.LOOT_TABLE, JockBall.id("chests/locker_room"));
    private static final List<Job> JOBS = new ArrayList<>();

    public static boolean isBuilding() {
        return !JOBS.isEmpty();
    }

    /** oy = Y del bloque de superficie del campo (el bloque sobre el que pisas). */
    public static void start(ServerLevel level, int ox, int oy, int oz, boolean reset) {
        if (level.dimension() == Level.OVERWORLD) {
            StadiumRegistry.register(ox, oy, oz);
        }
        JOBS.add(new Job(level, ox, oy, oz, reset));
    }

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Iterator<Job> it = JOBS.iterator();
            while (it.hasNext()) {
                if (it.next().step()) {
                    it.remove();
                }
            }
        });
    }

    private static final class Job {
        final ServerLevel level;
        final int ox, oy, oz;
        final boolean reset;
        final StadiumDesign.Palette palette;
        final int cx0, cz0, chunksX, chunksZ, totalChunks;
        int chunkI = 0;
        int local = 0;
        int forcedUpTo = -1;
        int lastQuarter = 0;
        final BlockState[] column = new BlockState[StadiumDesign.HEIGHT];
        final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        Job(ServerLevel level, int ox, int oy, int oz, boolean reset) {
            this.level = level;
            this.ox = ox;
            this.oy = oy;
            this.oz = oz;
            this.reset = reset;
            this.palette = StadiumDesign.paletteFor(ox, oz);
            int minX = ox - StadiumDesign.HALF_X, maxX = ox + StadiumDesign.HALF_X;
            int minZ = oz - StadiumDesign.HALF_Z, maxZ = oz + StadiumDesign.HALF_Z;
            this.cx0 = Math.floorDiv(minX, 16);
            this.cz0 = Math.floorDiv(minZ, 16);
            this.chunksX = Math.floorDiv(maxX, 16) - cx0 + 1;
            this.chunksZ = Math.floorDiv(maxZ, 16) - cz0 + 1;
            this.totalChunks = chunksX * chunksZ;
        }

        int chunkX(int i) { return cx0 + i / chunksZ; }
        int chunkZ(int i) { return cz0 + i % chunksZ; }

        /** Devuelve true cuando termino. */
        boolean step() {
            // pedir por adelantado los siguientes chunks
            while (forcedUpTo < Math.min(totalChunks - 1, chunkI + LOOKAHEAD)) {
                forcedUpTo++;
                level.setChunkForced(chunkX(forcedUpTo), chunkZ(forcedUpTo), true);
            }
            long end = System.nanoTime() + 30_000_000L;
            while (chunkI < totalChunks && System.nanoTime() < end) {
                int cx = chunkX(chunkI), cz = chunkZ(chunkI);
                if (!level.hasChunk(cx, cz)) {
                    break; // aun se esta generando; seguimos en el proximo tick
                }
                if (local == 0 && reset) {
                    clearOldPlayers(cx, cz);
                }
                int wx = cx * 16 + (local & 15);
                int wz = cz * 16 + (local >> 4);
                placeColumn(wx, wz);
                local++;
                if (local == 256) {
                    local = 0;
                    level.setChunkForced(cx, cz, false);
                    chunkI++;
                }
            }
            int quarter = chunkI * 4 / totalChunks;
            if (quarter > lastQuarter && chunkI < totalChunks) {
                lastQuarter = quarter;
                if (!reset) message("Construyendo estadio... " + quarter * 25 + "%");
            }
            if (chunkI >= totalChunks) {
                StadiumRoster.spawn(level, ox, oy, oz);
                if (!reset) {
                    message("Estadio terminado. 53 jugadores en sus posiciones: 11 en el campo y 42 de reserva.");
                }
                return true;
            }
            return false;
        }

        void clearOldPlayers(int cx, int cz) {
            AABB box = new AABB(cx * 16, level.getMinY(), cz * 16, cx * 16 + 16, level.getMaxY(), cz * 16 + 16);
            for (FootballPlayer old : level.getEntitiesOfClass(FootballPlayer.class, box)) {
                old.discard();
            }
        }

        void placeColumn(int wx, int wz) {
            int dx = wx - ox, dz = wz - oz;
            if (!StadiumDesign.column(dx, dz, column, palette)) return;
            for (int i = 0; i < column.length; i++) {
                int y = oy + StadiumDesign.MIN_DY + i;
                pos.set(wx, y, wz);
                BlockState want = column[i];
                BlockState have = level.getBlockState(pos);
                if (want.is(Blocks.CHEST)) {
                    if (have != want) level.setBlock(pos, want, FLAGS);
                    if (level.getBlockEntity(pos) instanceof RandomizableContainerBlockEntity chest) {
                        if (reset) chest.clearContent();
                        chest.setLootTable(LOCKER_LOOT, level.getRandom().nextLong());
                    }
                    continue;
                }
                if (have != want) {
                    level.setBlock(pos, want, FLAGS);
                }
            }
            // cimientos: si debajo hay aire o agua (terreno bajo), rellenar hacia abajo hasta tocar suelo
            int y = oy + StadiumDesign.MIN_DY - 1;
            int depth = 0;
            BlockState dirt = Blocks.DIRT.defaultBlockState();
            while (y > level.getMinY() && depth < 48) {
                pos.set(wx, y, wz);
                BlockState below = level.getBlockState(pos);
                if (!(below.isAir() || !below.getFluidState().isEmpty())) break;
                level.setBlock(pos, dirt, FLAGS);
                y--;
                depth++;
            }
        }

        void message(String text) {
            for (ServerPlayer p : level.players()) {
                p.sendSystemMessage(Component.literal(text));
            }
        }
    }

    private StadiumBuilder() {}
}
