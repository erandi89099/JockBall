package com.jockball.stadium;

import com.jockball.JockBall;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootTable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Construye el estadio poco a poco (unos 30 ms por tick) para no congelar el juego. */
public final class StadiumBuilder {
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;
    private static final ResourceKey<LootTable> LOCKER_LOOT =
            ResourceKey.create(Registries.LOOT_TABLE, JockBall.id("chests/locker_room"));
    private static final List<Job> JOBS = new ArrayList<>();

    public static boolean isBuilding() {
        return !JOBS.isEmpty();
    }

    /** oy = Y del bloque de superficie del campo (el bloque sobre el que pisas). */
    public static void start(ServerLevel level, int ox, int oy, int oz) {
        JOBS.add(new Job(level, ox, oy, oz));
    }

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Iterator<Job> it = JOBS.iterator();
            while (it.hasNext()) {
                Job job = it.next();
                if (job.step()) {
                    it.remove();
                }
            }
        });
    }

    private static final class Job {
        final ServerLevel level;
        final int ox, oy, oz;
        final int cx0, cz0, chunksX, chunksZ;
        final long totalColumns;
        long index = 0;
        int lastPercent = -1;
        final BlockState[] column = new BlockState[StadiumDesign.HEIGHT];
        final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        Job(ServerLevel level, int ox, int oy, int oz) {
            this.level = level;
            this.ox = ox;
            this.oy = oy;
            this.oz = oz;
            int minX = ox - StadiumDesign.HALF_X, maxX = ox + StadiumDesign.HALF_X;
            int minZ = oz - StadiumDesign.HALF_Z, maxZ = oz + StadiumDesign.HALF_Z;
            this.cx0 = Math.floorDiv(minX, 16);
            this.cz0 = Math.floorDiv(minZ, 16);
            this.chunksX = Math.floorDiv(maxX, 16) - cx0 + 1;
            this.chunksZ = Math.floorDiv(maxZ, 16) - cz0 + 1;
            this.totalColumns = (long) chunksX * chunksZ * 256L;
        }

        /** Devuelve true cuando termino. */
        boolean step() {
            long end = System.nanoTime() + 30_000_000L;
            while (index < totalColumns && System.nanoTime() < end) {
                long chunkIdx = index / 256;
                int local = (int) (index % 256);
                index++;
                int cxi = (int) (chunkIdx / chunksZ);
                int czi = (int) (chunkIdx % chunksZ);
                int wx = (cx0 + cxi) * 16 + (local & 15);
                int wz = (cz0 + czi) * 16 + (local >> 4);
                placeColumn(wx, wz);
            }
            int percent = (int) (index * 100L / totalColumns);
            if (percent / 25 != lastPercent / 25 && percent < 100) {
                message("Construyendo estadio... " + percent + "%");
            }
            lastPercent = percent;
            if (index >= totalColumns) {
                StadiumRoster.spawn(level, ox, oy, oz);
                message("Estadio terminado. 53 jugadores en sus posiciones: 11 en el campo y 42 de reserva.");
                return true;
            }
            return false;
        }

        void placeColumn(int wx, int wz) {
            int dx = wx - ox, dz = wz - oz;
            if (!StadiumDesign.column(dx, dz, column)) return;
            for (int i = 0; i < column.length; i++) {
                int y = oy + StadiumDesign.MIN_DY + i;
                pos.set(wx, y, wz);
                BlockState want = column[i];
                if (level.getBlockState(pos) == want) continue;
                level.setBlock(pos, want, FLAGS);
                if (want.is(Blocks.CHEST)
                        && level.getBlockEntity(pos) instanceof RandomizableContainerBlockEntity chest) {
                    chest.setLootTable(LOCKER_LOOT, level.getRandom().nextLong());
                }
            }
        }

        void message(String text) {
            for (ServerPlayer p : level.players()) {
                p.sendSystemMessage(Component.literal(text));
            }
        }
    }

    private StadiumBuilder() {}
}
