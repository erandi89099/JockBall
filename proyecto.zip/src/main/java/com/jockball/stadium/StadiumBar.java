package com.jockball.stadium;

import com.jockball.Achievements;
import com.jockball.ModSounds;
import com.jockball.entity.FootballPlayer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.phys.AABB;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Barra roja tipo "Raid": "Jugadores restantes: X/53". Se muestra mientras estas dentro de un estadio.
 */
public final class StadiumBar {
    private static final Map<UUID, ServerBossEvent> BARS = new HashMap<>();

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % 20 != 0) return;

            // limpiar barras de jugadores que ya no estan conectados
            Iterator<Map.Entry<UUID, ServerBossEvent>> it = BARS.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, ServerBossEvent> e = it.next();
                if (server.getPlayerList().getPlayer(e.getKey()) == null) {
                    e.getValue().removeAllPlayers();
                    it.remove();
                }
            }

            for (ServerLevel level : server.getAllLevels()) {
                for (ServerPlayer player : level.players()) {
                    update(level, player);
                }
            }
        });
    }

    /** Ahorra trabajo: en el Overworld solo se busca si hay un estadio registrado a menos de ~300 bloques. */
    private static boolean mayBeNearStadium(ServerLevel level, ServerPlayer player) {
        if (level.dimension() != net.minecraft.world.level.Level.OVERWORLD) return true; // estadios por comando en otras dimensiones
        for (StadiumRegistry.Entry e : StadiumRegistry.entries()) {
            if (Math.abs(player.getBlockX() - e.ox) < 300 && Math.abs(player.getBlockZ() - e.oz) < 330) return true;
        }
        return false;
    }

    private static void update(ServerLevel level, ServerPlayer player) {
        ServerBossEvent bar = BARS.get(player.getUUID());
        FootballPlayer anchor = null;
        if (player.isAlive() && mayBeNearStadium(level, player)) {
            // buscar un jugador enemigo cercano que diga a que estadio pertenece
            List<FootballPlayer> near = level.getEntitiesOfClass(
                    FootballPlayer.class, player.getBoundingBox().inflate(140.0, 90.0, 140.0), FootballPlayer::hasHome);
            for (FootballPlayer fp : near) {
                if (Math.abs(player.getBlockX() - fp.getHomeX()) <= StadiumDesign.HALF_X + 4
                        && Math.abs(player.getBlockZ() - fp.getHomeZ()) <= StadiumDesign.HALF_Z + 4) {
                    anchor = fp;
                    break;
                }
            }
        }
        if (anchor == null) {
            if (bar != null) bar.removePlayer(player);
            return;
        }
        int hx = anchor.getHomeX(), hy = anchor.getHomeY(), hz = anchor.getHomeZ();
        int total = Math.max(1, anchor.getHomeTotal());
        AABB box = new AABB(hx - StadiumDesign.HALF_X, hy - 30, hz - StadiumDesign.HALF_Z,
                hx + StadiumDesign.HALF_X + 1, hy + 80, hz + StadiumDesign.HALF_Z + 1);
        int remaining = 0;
        for (FootballPlayer fp : level.getEntitiesOfClass(FootballPlayer.class, box)) {
            if (fp.isAlive() && fp.hasHome() && fp.getHomeX() == hx && fp.getHomeZ() == hz) remaining++;
        }
        remaining = Math.min(remaining, total);

        if (bar == null) {
            bar = new ServerBossEvent(UUID.randomUUID(), Component.empty(),
                    BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_10);
            BARS.put(player.getUUID(), bar);
        }
        bar.setName(Component.translatable("jockball.remaining", remaining, total));
        bar.setProgress(remaining / (float) total);
        bar.addPlayer(player);
        // ambiente del estadio: murmullo de multitud (dura 12 s; se repite mientras estes dentro)
        if ((level.getGameTime() / 20) % 12 == 0) {
            ModSounds.play(player, ModSounds.CROWD, 1.0F);
            Achievements.award(player, "stadium");
        }
    }

    private StadiumBar() {}
}
