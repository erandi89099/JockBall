package com.jockball.stadium;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.Arrays;
import java.util.Random;

/**
 * Aparicion natural: el mundo se divide en regiones de 1024x1024 bloques. Cada region tiene (con 60% de
 * probabilidad) UN sitio fijo para un estadio, calculado de la semilla del mundo. El estadio se construye
 * cuando un jugador se acerca a menos de 240 bloques. AJUSTA AQUI la frecuencia.
 */
public final class StadiumSites {
    public static final boolean ENABLED = true;
    public static final int REGION = 1024;
    private static final double CHANCE = 0.60;
    private static final int MARGIN = 300;
    private static final int TRIGGER = 240;

    /** Devuelve {x, z} del sitio de la region, o null si esa region no tiene estadio. */
    public static int[] siteFor(long seed, int rx, int rz) {
        Random r = new Random(seed ^ (rx * 341873128712L) ^ (rz * 132897987541L) ^ 0x5DEECE66DL);
        r.nextInt();
        if (r.nextDouble() >= CHANCE) return null;
        int x = rx * REGION + MARGIN + r.nextInt(REGION - 2 * MARGIN);
        int z = rz * REGION + MARGIN + r.nextInt(REGION - 2 * MARGIN);
        return new int[]{x, z};
    }

    /** Sitio mas cercano (busca en las regiones vecinas), o null. */
    public static int[] nearest(long seed, int px, int pz) {
        int rx0 = Math.floorDiv(px, REGION), rz0 = Math.floorDiv(pz, REGION);
        int[] best = null;
        double bestD = Double.MAX_VALUE;
        for (int drx = -3; drx <= 3; drx++) {
            for (int drz = -3; drz <= 3; drz++) {
                int[] s = siteFor(seed, rx0 + drx, rz0 + drz);
                if (s == null) continue;
                double d = Math.hypot(s[0] - px, s[1] - pz);
                if (d < bestD) {
                    bestD = d;
                    best = s;
                }
            }
        }
        return best;
    }

    /** Altura de suelo estable: mediana de 9 muestras (evita que un arbol o un hoyo decidan). */
    private static int groundY(ServerLevel level, int x, int z) {
        int[] h = new int[9];
        int i = 0;
        for (int dx = -40; dx <= 40; dx += 40) {
            for (int dz = -40; dz <= 40; dz += 40) {
                h[i++] = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x + dx, z + dz) - 1;
            }
        }
        Arrays.sort(h);
        int y = Math.max(h[4], 63); // nunca por debajo del nivel del mar
        int max = level.getMaxY() - StadiumDesign.MAX_DY - 2;
        return Math.min(y, max);
    }

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!ENABLED || server.getTickCount() % 40 != 0) return;
            ServerLevel overworld = server.overworld();
            long seed = overworld.getSeed();

            // ---- aparicion natural ----
            if (!StadiumBuilder.isBuilding()) {
                outer:
                for (ServerPlayer player : overworld.players()) {
                    int rx0 = Math.floorDiv(player.getBlockX(), REGION);
                    int rz0 = Math.floorDiv(player.getBlockZ(), REGION);
                    for (int drx = -1; drx <= 1; drx++) {
                        for (int drz = -1; drz <= 1; drz++) {
                            int rx = rx0 + drx, rz = rz0 + drz;
                            if (StadiumRegistry.isRegionDone(rx, rz)) continue;
                            int[] site = siteFor(seed, rx, rz);
                            if (site == null) {
                                StadiumRegistry.markRegionDone(rx, rz);
                                continue;
                            }
                            double d = Math.hypot(site[0] - player.getBlockX(), site[1] - player.getBlockZ());
                            if (d > TRIGGER) continue;
                            StadiumRegistry.markRegionDone(rx, rz);
                            StadiumBuilder.start(overworld, site[0], groundY(overworld, site[0], site[1]), site[1], false);
                            break outer;
                        }
                    }
                }
            }

            // ---- reinicio de estadios ganados ----
            if (server.getTickCount() % 200 == 0 && !StadiumBuilder.isBuilding()) {
                long now = overworld.getGameTime();
                for (StadiumRegistry.Entry e : StadiumRegistry.entries()) {
                    if (!e.cleared || now < e.resetAt) continue;
                    boolean occupied = false;
                    for (ServerPlayer p : overworld.players()) {
                        if (Math.abs(p.getBlockX() - e.ox) <= StadiumDesign.HALF_X + 48
                                && Math.abs(p.getBlockZ() - e.oz) <= StadiumDesign.HALF_Z + 48) {
                            occupied = true;
                            break;
                        }
                    }
                    if (occupied) continue;
                    StadiumRegistry.markReset(e);
                    StadiumBuilder.start(overworld, e.ox, e.oy, e.oz, true);
                    break;
                }
            }
        });
    }

    private StadiumSites() {}
}
