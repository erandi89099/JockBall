package com.jockball.stadium;

import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.Arrays;

/**
 * Diseno del estadio como FUNCION PURA: dado (dx, dz) relativo al centro del campo, rellena la columna
 * de bloques de abajo a arriba. Sin acceso al mundo, para poder reutilizarla tal cual en la generacion natural.
 *
 * Ejes: el campo es largo en Z (120 bloques) y ancho en X (53). dy = 0 es la superficie del campo.
 * Tamano total: 193 x 241 bloques, altura hasta +44.
 *
 * AJUSTES RAPIDOS: las constantes de abajo (filas, colores, tamano de tunel y vestidor).
 */
public final class StadiumDesign {
    public static final int MIN_DY = -6;
    public static final int MAX_DY = 44;
    public static final int HEIGHT = MAX_DY - MIN_DY + 1;
    public static final int HALF_X = 96;
    public static final int HALF_Z = 120;

    // rectangulo redondeado que rodea el campo (borde interior de las gradas)
    private static final int HX = 41, HZ = 65;
    private static final double CORNER = 22.0;
    // distancias hacia afuera desde ese borde
    private static final double WALL_END = 1.0;       // muro de publicidad
    private static final double STANDS_END = 45.0;    // 22 filas de 2 bloques
    private static final double CONCOURSE_END = 53.0; // pasillo superior
    private static final double FACADE_END = 55.0;    // fachada exterior
    private static final int CONCOURSE_Y = 24;
    private static final int FACADE_Y = 32;

    private static BlockState b(Block block) { return block.defaultBlockState(); }

    /** Busca un bloque por su nombre de juego (no depende de como se llame en el codigo de Minecraft). */
    private static BlockState named(String id) {
        return BuiltInRegistries.BLOCK.getValue(Identifier.withDefaultNamespace(id)).defaultBlockState();
    }

    private static final BlockState AIR = b(Blocks.AIR);
    private static final BlockState DIRT = b(Blocks.DIRT);
    private static final BlockState GRASS = b(Blocks.GRASS_BLOCK);
    private static final BlockState MOSS = b(Blocks.MOSS_BLOCK);
    private static final BlockState WHITE = named("white_concrete");
    private static final BlockState RED = named("red_concrete");
    private static final BlockState BLUE = named("blue_concrete");
    private static final BlockState YELLOW = named("yellow_concrete");

    /** Colores de un equipo: asientos (2 tonos), zonas de anotacion (local y visitante) y logo central. */
    public record Palette(BlockState seatA, BlockState seatB, BlockState endHome, BlockState endAway,
                          BlockState logoOuter, BlockState logoInner) {}

    private static final Palette[] PALETTES = {
            new Palette(named("red_concrete"), WHITE, named("red_concrete"), named("blue_concrete"), YELLOW, named("red_concrete")),
            new Palette(named("blue_concrete"), WHITE, named("blue_concrete"), named("orange_concrete"), YELLOW, named("blue_concrete")),
            new Palette(named("green_concrete"), WHITE, named("green_concrete"), YELLOW, WHITE, named("green_concrete")),
            new Palette(named("purple_concrete"), WHITE, named("purple_concrete"), named("orange_concrete"), YELLOW, named("purple_concrete")),
            new Palette(named("black_concrete"), named("orange_concrete"), named("black_concrete"), named("orange_concrete"), WHITE, named("black_concrete")),
    };

    /** Cada estadio tiene su equipo (colores) segun la posicion de su centro: siempre el mismo. */
    public static Palette paletteFor(int ox, int oz) {
        return PALETTES[Math.floorMod(ox * 73856093 ^ oz * 19349663, PALETTES.length)];
    }
    private static final BlockState GRAY = named("gray_concrete");
    private static final BlockState LIGHT_GRAY = named("light_gray_concrete");
    private static final BlockState BRICKS = b(Blocks.STONE_BRICKS);
    private static final BlockState BRICK_WALL = b(Blocks.STONE_BRICK_WALL);
    private static final BlockState POLISHED = b(Blocks.POLISHED_ANDESITE);
    private static final BlockState LANTERN = b(Blocks.SEA_LANTERN);
    private static final BlockState GLASS = named("black_stained_glass");
    private static final BlockState BENCH = b(Blocks.SPRUCE_SLAB);

    public static BlockState chest(Direction facing) {
        return Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, facing);
    }

    /** Distancia hacia afuera desde el rectangulo redondeado (negativa = dentro, sobre el campo). */
    public static double sdf(int dx, int dz) {
        double qx = Math.abs(dx) - (HX - CORNER);
        double qz = Math.abs(dz) - (HZ - CORNER);
        double ox = Math.max(qx, 0), oz = Math.max(qz, 0);
        return Math.sqrt(ox * ox + oz * oz) + Math.min(Math.max(qx, qz), 0) - CORNER;
    }

    /** Altura (dy) de la superficie transitable en esa columna, o Integer.MIN_VALUE si esta fuera. */
    public static int surfaceY(int dx, int dz) {
        double s = sdf(dx, dz);
        if (s < 0) return 0;
        if (s < WALL_END) return 2;
        if (s < STANDS_END) return 3 + (int) ((s - 1) / 2);
        if (s < CONCOURSE_END) return CONCOURSE_Y;
        if (s < FACADE_END) return FACADE_Y;
        return Integer.MIN_VALUE;
    }

    private static BlockState fieldSurface(int dx, int dz, Palette pal) {
        int ax = Math.abs(dx), az = Math.abs(dz);
        if (ax <= 26 && az <= 60) {
            double r = Math.hypot(dx, dz);
            if (r <= 2.5) return pal.logoInner();      // logo central
            if (r <= 5.5) return pal.logoOuter();
            if (ax == 26 || az == 60) return WHITE;   // lineas de banda y de fondo
            if (az <= 50 && dz % 5 == 0) return WHITE; // yardas (incluye la linea de gol)
            if (az > 50) return dz > 0 ? pal.endHome() : pal.endAway();  // zonas de anotacion
            return ((dz + 50) / 5) % 2 == 0 ? GRASS : MOSS; // franjas de cesped
        }
        return GRASS; // zona entre el campo y las gradas
    }

    private static BlockState seat(int dx, int dz, Palette pal) {
        double a = (Math.atan2(dz, dx) + Math.PI) / (2 * Math.PI) * 24.0;
        int sector = (int) Math.floor(a) % 24;
        double frac = a - Math.floor(a);
        double r = Math.hypot(dx, dz);
        if (frac * (2 * Math.PI * r / 24.0) < 1.0) return BRICKS; // pasillo entre secciones
        return sector % 2 == 0 ? pal.seatA() : pal.seatB();
    }

    private static void set(BlockState[] out, int y, BlockState state) {
        int i = y - MIN_DY;
        if (i >= 0 && i < out.length) out[i] = state;
    }

    private static boolean tower(int dx, int dz, int px, int pz) {
        return dx == px && dz == pz;
    }

    /**
     * Rellena `out` (tamano HEIGHT, indice 0 = MIN_DY) con la columna de bloques.
     * Devuelve false si la columna esta fuera del estadio (no se debe tocar).
     */
    public static boolean column(int dx, int dz, BlockState[] out, Palette pal) {
        double s = sdf(dx, dz);
        if (s >= FACADE_END) return false;
        Arrays.fill(out, AIR);
        int ax = Math.abs(dx), az = Math.abs(dz);

        int top;
        BlockState topState;
        if (s < 0) { top = 0; topState = fieldSurface(dx, dz, pal); }
        else if (s < WALL_END) { top = 2; topState = WHITE; }
        else if (s < STANDS_END) { top = 3 + (int) ((s - 1) / 2); topState = seat(dx, dz, pal); }
        else if (s < CONCOURSE_END) { top = CONCOURSE_Y; topState = POLISHED; }
        else { top = FACADE_Y; topState = BRICKS; }

        for (int y = MIN_DY; y <= top; y++) {
            set(out, y, y < 0 ? DIRT : (y == top ? topState : GRAY));
        }
        if (s >= 0 && s < WALL_END) {
            set(out, 1, pal.seatA());
            set(out, 2, WHITE);
        }
        if (s >= CONCOURSE_END) {                       // fachada: ventanas y parapeto
            if (((dx + dz) & 3) == 0) {
                for (int y = 26; y <= 29; y++) set(out, y, GLASS);
            }
            set(out, FACADE_Y + 1, BRICK_WALL);
        }

        // ---- tuneles hacia los vestidores (a cada lado del campo, sobre el eje X=0) ----
        if (az >= 65 && az <= 86 && ax <= 3 && s >= 0) {
            if (ax <= 2) set(out, 0, POLISHED);
            for (int y = 1; y <= 5; y++) set(out, y, ax == 3 ? BRICKS : AIR);
            set(out, 6, BRICKS);
        }
        // ---- vestidor ----
        if (az >= 87 && az <= 103 && ax <= 11) {
            set(out, 0, POLISHED);
            for (int y = 1; y <= 6; y++) set(out, y, AIR);
            if (dx % 6 == 0 && az % 6 == 0) set(out, 6, LANTERN);
            if (ax == 7 && az >= 90 && az <= 100) set(out, 1, BENCH);
            if (az == 103 && (ax == 3 || ax == 6 || ax == 9)) {
                set(out, 1, chest(dz > 0 ? Direction.NORTH : Direction.SOUTH));
            }
        }

        // ---- techo en los lados largos ----
        if (az <= 46 && s >= 18 && s < FACADE_END) {
            set(out, 34, LIGHT_GRAY);
            set(out, 35, WHITE);
            if (s < 52 && dz % 8 == 0 && ((int) s) % 8 == 2) set(out, 33, LANTERN);
        }

        // ---- torres de luces en las 4 esquinas ----
        int[][] towers = {{60, 88}, {-60, 88}, {60, -88}, {-60, -88}};
        for (int[] t : towers) {
            if (tower(dx, dz, t[0], t[1])) {
                for (int y = top + 1; y <= 40; y++) set(out, y, BRICK_WALL);
            }
            if (Math.abs(dx - t[0]) <= 1 && Math.abs(dz - t[1]) <= 1) {
                set(out, 41, LANTERN);
                set(out, 42, LANTERN);
            }
        }

        // ---- postes de gol ----
        if (az == 60 && ax <= 3 && s < 0) {
            if (ax == 0) for (int y = 1; y <= 6; y++) set(out, y, YELLOW);
            set(out, 7, YELLOW);
            if (ax == 3) for (int y = 8; y <= 14; y++) set(out, y, YELLOW);
        }
        return true;
    }

    private StadiumDesign() {}
}
