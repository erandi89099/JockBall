package com.jockball.stadium;

import com.jockball.JockBall;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Memoria de estadios del mundo (se guarda en jockball_stadiums.txt dentro de la carpeta del mundo):
 * que regiones ya se procesaron, y que estadios estan "ganados" esperando reiniciarse.
 * Solo se registran estadios del Overworld.
 */
public final class StadiumRegistry {
    public static final long RESET_TICKS = 36000L; // 30 minutos de juego tras vencer al capitan

    public static final class Entry {
        public final int ox, oy, oz;
        public boolean cleared;
        public long resetAt;

        Entry(int ox, int oy, int oz) {
            this.ox = ox;
            this.oy = oy;
            this.oz = oz;
        }
    }

    private static final List<Entry> ENTRIES = new ArrayList<>();
    private static final Set<Long> REGIONS = new HashSet<>();
    private static final Set<Long> VILLAGES = new HashSet<>();
    private static Path file;

    public static long regionKey(int rx, int rz) {
        return ((long) rx << 32) ^ (rz & 0xFFFFFFFFL);
    }

    public static boolean isRegionDone(int rx, int rz) {
        return REGIONS.contains(regionKey(rx, rz));
    }

    public static void markRegionDone(int rx, int rz) {
        REGIONS.add(regionKey(rx, rz));
        save();
    }

    public static boolean isVillageDone(long key) {
        return VILLAGES.contains(key);
    }

    public static void markVillageDone(long key) {
        VILLAGES.add(key);
        save();
    }

    public static List<Entry> entries() {
        return ENTRIES;
    }

    public static Entry find(int ox, int oz) {
        for (Entry e : ENTRIES) {
            if (e.ox == ox && e.oz == oz) return e;
        }
        return null;
    }

    public static void register(int ox, int oy, int oz) {
        if (find(ox, oz) == null) {
            ENTRIES.add(new Entry(ox, oy, oz));
            save();
        }
    }

    public static void markCleared(int ox, int oz, long gameTime) {
        Entry e = find(ox, oz);
        if (e != null && !e.cleared) {
            e.cleared = true;
            e.resetAt = gameTime + RESET_TICKS;
            save();
        }
    }

    public static void markReset(Entry e) {
        e.cleared = false;
        save();
    }

    public static void initialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(StadiumRegistry::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> save());
    }

    private static void load(MinecraftServer server) {
        ENTRIES.clear();
        REGIONS.clear();
        VILLAGES.clear();
        file = server.getWorldPath(LevelResource.ROOT).resolve("jockball_stadiums.txt");
        if (!Files.exists(file)) return;
        try {
            for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
                String[] p = line.trim().split(" ");
                if (p.length == 3 && p[0].equals("R")) {
                    REGIONS.add(regionKey(Integer.parseInt(p[1]), Integer.parseInt(p[2])));
                } else if (p.length == 2 && p[0].equals("V")) {
                    VILLAGES.add(Long.parseLong(p[1]));
                } else if (p.length == 6 && p[0].equals("E")) {
                    Entry e = new Entry(Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]));
                    e.cleared = p[4].equals("1");
                    e.resetAt = Long.parseLong(p[5]);
                    ENTRIES.add(e);
                }
            }
        } catch (IOException | NumberFormatException ex) {
            JockBall.LOGGER.warn("No se pudo leer jockball_stadiums.txt", ex);
        }
    }

    private static void save() {
        if (file == null) return;
        List<String> lines = new ArrayList<>();
        for (Entry e : ENTRIES) {
            lines.add("E " + e.ox + " " + e.oy + " " + e.oz + " " + (e.cleared ? 1 : 0) + " " + e.resetAt);
        }
        // las regiones se guardan como (rx rz) reconstruidos de la clave
        for (long key : REGIONS) {
            lines.add("R " + (int) (key >> 32) + " " + (int) key);
        }
        for (long v : VILLAGES) {
            lines.add("V " + v);
        }
        try {
            Files.write(file, lines, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            JockBall.LOGGER.warn("No se pudo guardar jockball_stadiums.txt", ex);
        }
    }

    private StadiumRegistry() {}
}
