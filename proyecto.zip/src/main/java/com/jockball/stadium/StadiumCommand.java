package com.jockball.stadium;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentUtils;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import com.jockball.shop.ShopSites;

/**
 * /jockball stadium : construye el estadio con el centro del campo donde estas parado.
 * /jockball locate [shop] : coordenadas del estadio (o tienda) mas cercano.
 * /jockball shop : construye una tienda 20 bloques frente a ti.
 */
public final class StadiumCommand {
    public static void initialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("jockball")
                        .then(Commands.literal("stadium").executes(ctx -> {
                            CommandSourceStack source = ctx.getSource();
                            ServerPlayer player = source.getPlayerOrException();
                            ServerLevel level = source.getLevel();
                            if (StadiumBuilder.isBuilding()) {
                                source.sendFailure(Component.literal("Ya hay un estadio en construccion."));
                                return 0;
                            }
                            int ox = player.blockPosition().getX();
                            int oy = player.blockPosition().getY() - 1;
                            int oz = player.blockPosition().getZ();
                            if (oy + StadiumDesign.MIN_DY < level.getMinY()
                                    || oy + StadiumDesign.MAX_DY > level.getMaxY()) {
                                source.sendFailure(Component.literal("Altura no valida para construir aqui."));
                                return 0;
                            }
                            StadiumBuilder.start(level, ox, oy, oz, false);
                            source.sendSuccess(() -> Component.literal(
                                    "Construyendo estadio de 193 x 241 bloques. Puede tardar unos segundos; "
                                            + "se reemplaza todo lo que haya en esa zona."), false);
                            return 1;
                        }))
                        .then(Commands.literal("locate")
                                .executes(ctx -> locateStadium(ctx.getSource()))
                                .then(Commands.literal("stadium").executes(ctx -> locateStadium(ctx.getSource())))
                                .then(Commands.literal("shop").executes(ctx -> locateShop(ctx.getSource()))))
                        .then(Commands.literal("shop").executes(ctx -> {
                            CommandSourceStack source = ctx.getSource();
                            ServerPlayer player = source.getPlayerOrException();
                            String error = ShopSites.buildInFront(source.getLevel(), player);
                            if (error != null) {
                                source.sendFailure(Component.literal(error));
                                return 0;
                            }
                            source.sendSuccess(() -> Component.literal("Tienda construida frente a ti."), false);
                            return 1;
                        }))));
    }

    /** Coordenadas clicables como las del /locate de vanilla: al pulsarlas se escribe el /tp en el chat. */
    private static Component coords(int x, int z) {
        return ComponentUtils.wrapInSquareBrackets(Component.translatable("chat.coordinates", x, "~", z))
                .withStyle(style -> style
                        .withColor(ChatFormatting.GREEN)
                        .withClickEvent(new ClickEvent.SuggestCommand("/tp @s " + x + " ~ " + z))
                        .withHoverEvent(new HoverEvent.ShowText(Component.translatable("chat.coordinates.tooltip"))));
    }

    private static int locateStadium(CommandSourceStack source) {
        int px = (int) source.getPosition().x, pz = (int) source.getPosition().z;
        int[] site = StadiumSites.nearest(source.getServer().overworld().getSeed(), px, pz);
        if (site == null) {
            source.sendFailure(Component.translatable("jockball.locate.none.stadium"));
            return 0;
        }
        int dist = (int) Math.hypot(site[0] - px, site[1] - pz);
        source.sendSuccess(() -> Component.translatable("jockball.locate.stadium", coords(site[0], site[1]), dist), false);
        return 1;
    }

    private static int locateShop(CommandSourceStack source) {
        int px = (int) source.getPosition().x, pz = (int) source.getPosition().z;
        int[] site = ShopSites.nearest(source.getServer().overworld().getSeed(), px, pz);
        if (site == null) {
            source.sendFailure(Component.translatable("jockball.locate.none.shop"));
            return 0;
        }
        int dist = (int) Math.hypot(site[0] - px, site[1] - pz);
        source.sendSuccess(() -> Component.translatable("jockball.locate.shop", coords(site[0], site[1]), dist), false);
        return 1;
    }

    private StadiumCommand() {}
}
