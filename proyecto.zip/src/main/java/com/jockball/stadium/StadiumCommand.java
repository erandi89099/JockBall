package com.jockball.stadium;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/** /jockball stadium : construye el estadio con el centro del campo donde estas parado. */
public final class StadiumCommand {
    public static void initialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("jockball")
                        .then(Commands.literal("stadium").executes(ctx -> {
                            CommandSourceStack source = ctx.getSource();
                            ServerPlayer player = source.getPlayerOrException();
                            ServerLevel level = source.getLevel();
                            if (StadiumBuilder.isBuilding()) {
                                source.sendFailure(Component.literal("Ya hay un estadio en construccion."));
                                return 0;
                            }
                            int ox = player.blockPosition().getX();
                            int oy = player.blockPosition().getY() - 1;
                            int oz = player.blockPosition().getZ();
                            if (oy + StadiumDesign.MIN_DY < level.getMinY()
                                    || oy + StadiumDesign.MAX_DY > level.getMaxY()) {
                                source.sendFailure(Component.literal("Altura no valida para construir aqui."));
                                return 0;
                            }
                            StadiumBuilder.start(level, ox, oy, oz);
                            source.sendSuccess(() -> Component.literal(
                                    "Construyendo estadio de 193 x 241 bloques. Puede tardar unos segundos; "
                                            + "se reemplaza todo lo que haya en esa zona."), false);
                            return 1;
                        }))));
    }

    private StadiumCommand() {}
}
