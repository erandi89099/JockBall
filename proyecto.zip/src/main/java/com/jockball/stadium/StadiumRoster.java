package com.jockball.stadium;

import com.jockball.entity.FootballPlayer;
import com.jockball.entity.ModEntities;
import com.jockball.entity.Position;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;

/**
 * Coloca los 53 jugadores: 10 titulares + el capitan en el campo (11) y 42 de reserva
 * repartidos entre gradas (20), vestidores (10) y el pasillo superior (12).
 * Todos nacen "dormidos" y despiertan cuando te acercas.
 */
public final class StadiumRoster {
    private static final int STARTER_WAKE = 35;
    private static final int RESERVE_WAKE = 20;

    public static void spawn(ServerLevel level, int ox, int oy, int oz) {
        RandomSource random = level.getRandom();

        // ---- campo: formacion defensiva en la mitad +Z ----
        field(level, ox, oy, oz, Position.LINEMAN, -6, 8);
        field(level, ox, oy, oz, Position.LINEMAN, -2, 8);
        field(level, ox, oy, oz, Position.LINEMAN, 2, 8);
        field(level, ox, oy, oz, Position.LINEMAN, 6, 8);
        field(level, ox, oy, oz, Position.LINEBACKER, -5, 14);
        field(level, ox, oy, oz, Position.LINEBACKER, 5, 14);
        field(level, ox, oy, oz, Position.SAFETY, -10, 24);
        field(level, ox, oy, oz, Position.SAFETY, 10, 24);
        field(level, ox, oy, oz, Position.RUNNING_BACK, 0, 20);
        field(level, ox, oy, oz, Position.RECEIVER, -18, 12);
        FootballPlayer captain = make(level, Position.CAPTAIN, ox, oy + 1, oz, 0, 17);
        captain.setDormant(STARTER_WAKE);
        level.addFreshEntity(captain);

        // ---- reserva en las gradas (20) ----
        int placed = 0, tries = 0;
        while (placed < 20 && tries++ < 2000) {
            int dx = random.nextInt(2 * 95 + 1) - 95;
            int dz = random.nextInt(2 * 119 + 1) - 119;
            double s = StadiumDesign.sdf(dx, dz);
            if (s < 4 || s >= 44 || (Math.abs(dx) <= 4 && Math.abs(dz) >= 64)) continue;
            reserve(level, random, ox, oy + StadiumDesign.surfaceY(dx, dz) + 1, oz, dx, dz);
            placed++;
        }
        // ---- reserva en el pasillo superior (12) ----
        placed = 0;
        tries = 0;
        while (placed < 12 && tries++ < 2000) {
            int dx = random.nextInt(2 * 95 + 1) - 95;
            int dz = random.nextInt(2 * 119 + 1) - 119;
            double s = StadiumDesign.sdf(dx, dz);
            if (s < 46 || s >= 52) continue;
            reserve(level, random, ox, oy + StadiumDesign.surfaceY(dx, dz) + 1, oz, dx, dz);
            placed++;
        }
        // ---- reserva en los vestidores (5 por lado) ----
        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < 5; i++) {
                int dx = random.nextInt(17) - 8;
                int dz = side * (89 + random.nextInt(13));
                reserve(level, random, ox, oy + 1, oz, dx, dz);
            }
        }
    }

    private static void field(ServerLevel level, int ox, int oy, int oz, Position pos, int dx, int dz) {
        FootballPlayer p = make(level, pos, ox, oy + 1, oz, dx, dz);
        p.setStarter(true);
        p.setDormant(STARTER_WAKE);
        level.addFreshEntity(p);
    }

    private static void reserve(ServerLevel level, RandomSource random, int ox, int y, int oz, int dx, int dz) {
        Position[] pool = {Position.LINEMAN, Position.LINEMAN, Position.LINEMAN, Position.LINEBACKER,
                Position.LINEBACKER, Position.RUNNING_BACK, Position.RECEIVER, Position.SAFETY};
        FootballPlayer p = make(level, pool[random.nextInt(pool.length)], ox, y, oz, dx, dz);
        p.setDormant(RESERVE_WAKE);
        level.addFreshEntity(p);
    }

    private static FootballPlayer make(ServerLevel level, Position pos, int ox, int y, int oz, int dx, int dz) {
        FootballPlayer p = new FootballPlayer(ModEntities.TYPES.get(pos), level);
        level.getChunk(Math.floorDiv(ox + dx, 16), Math.floorDiv(oz + dz, 16)); // asegura que el chunk este cargado
        p.setPos(ox + dx + 0.5, y, oz + dz + 0.5);
        p.setYRot(level.getRandom().nextFloat() * 360.0F);
        return p;
    }

    private StadiumRoster() {}
}
