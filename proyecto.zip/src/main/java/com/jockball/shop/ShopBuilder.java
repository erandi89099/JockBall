package com.jockball.shop;

import com.jockball.JockBall;
import com.jockball.item.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.entity.npc.villager.VillagerData;
import net.minecraft.world.entity.npc.villager.VillagerProfession;
import net.minecraft.world.entity.npc.villager.VillagerType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootTable;

/** Construye la tienda de una vez (son ~3000 bloques) y coloca al vendedor. */
public final class ShopBuilder {
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;
    private static final ResourceKey<LootTable> SHOP_LOOT =
            ResourceKey.create(Registries.LOOT_TABLE, JockBall.id("chests/shop"));
    private static final Rotation[] ROTATIONS =
            {Rotation.NONE, Rotation.CLOCKWISE_90, Rotation.CLOCKWISE_180, Rotation.COUNTERCLOCKWISE_90};

    // centro local de la tienda
    private static final int CENTER_X = 8, CENTER_Z = 6;

    /** Gira un vector local (u, v) segun k: 0 = frente al norte, 1 = este, 2 = sur, 3 = oeste. */
    private static int[] rotate(int u, int v, int k) {
        return switch (k) {
            case 0 -> new int[]{u, v};
            case 1 -> new int[]{-v, u};
            case 2 -> new int[]{-u, -v};
            default -> new int[]{v, -u};
        };
    }

    /** Devuelve false si los chunks aun no estan cargados (se reintenta luego). */
    public static boolean build(ServerLevel level, int cx, int cz, int y0, int k, ShopDesign.Style style) {
        for (int dx = -1; dx <= 1; dx += 2) {
            for (int dz = -1; dz <= 1; dz += 2) {
                if (!level.hasChunk(Math.floorDiv(cx + dx * 13, 16), Math.floorDiv(cz + dz * 13, 16))) return false;
            }
        }
        Rotation rot = ROTATIONS[k];
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        BlockState dirt = Blocks.DIRT.defaultBlockState();

        for (int lx = -1; lx <= 17; lx++) {
            for (int lz = -2; lz <= 15; lz++) {
                int[] r = rotate(lx - CENTER_X, lz - CENTER_Z, k);
                int wx = cx + r[0], wz = cz + r[1];
                for (int ly = 0; ly <= 9; ly++) {
                    BlockState state = ShopDesign.at(style, lx, ly, lz);
                    if (state == null) continue;
                    state = state.rotate(rot);
                    pos.set(wx, y0 + ly, wz);
                    level.setBlock(pos, state, FLAGS);
                    if (state.is(Blocks.CHEST)
                            && level.getBlockEntity(pos) instanceof RandomizableContainerBlockEntity chest) {
                        chest.setLootTable(SHOP_LOOT, level.getRandom().nextLong());
                    }
                }
                // cimientos bajo el edificio
                if (lx >= 0 && lx <= 16 && lz >= 0 && lz <= 14) {
                    int y = y0 - 1, depth = 0;
                    while (y > level.getMinY() && depth < 14) {
                        pos.set(wx, y, wz);
                        BlockState below = level.getBlockState(pos);
                        if (!(below.isAir() || !below.getFluidState().isEmpty())) break;
                        level.setBlock(pos, dirt, FLAGS);
                        y--;
                        depth++;
                    }
                }
            }
        }
        // vendedor: detras del mostrador, en la zona z 7..8
        int[] v = rotate(5 - CENTER_X, 8 - CENTER_Z, k);
        spawnSeller(level, cx + v[0], y0 + 1, cz + v[1], style);
        return true;
    }

    private static ResourceKey<VillagerType> typeFor(ShopDesign.Style style) {
        return switch (style) {
            case DESERT -> VillagerType.DESERT;
            case SAVANNA -> VillagerType.SAVANNA;
            case TAIGA -> VillagerType.TAIGA;
            default -> VillagerType.PLAINS;
        };
    }

    private static void spawnSeller(ServerLevel level, int x, int y, int z, ShopDesign.Style style) {
        @SuppressWarnings("unchecked")
        EntityType<Villager> villagerType = (EntityType<Villager>) BuiltInRegistries.ENTITY_TYPE
                .getValue(Identifier.withDefaultNamespace("villager"));
        Villager villager = new Villager(villagerType, level);
        villager.setPos(x + 0.5, y, z + 0.5);
        Holder<VillagerType> type = BuiltInRegistries.VILLAGER_TYPE.getOrThrow(typeFor(style));
        Holder<VillagerProfession> job = BuiltInRegistries.VILLAGER_PROFESSION.getOrThrow(VillagerProfession.ARMORER);
        villager.setVillagerData(new VillagerData(type, job, 5)); // nivel maximo: no sube mas
        villager.getOffers().clear();                              // fuera las ofertas de armero normal
        // ---- ofertas ----
        villager.getOffers().add(new MerchantOffer(new ItemCost(Items.EMERALD, 12),
                new ItemStack(ModItems.UPGRADE_TEMPLATE), 4, 5, 0.05F));
        int[][] cost = {{4, 6, 5, 4}, {10, 14, 12, 10}, {24, 32, 28, 24}}; // nivel 1, 2, 3 x (casco, hombreras, fundas, tachos)
        int[] uses = {8, 4, 2};
        for (int level0 = 0; level0 < 3; level0++) {
            for (int p = 0; p < 4; p++) {
                Item piece = ModItems.GEAR[level0][p];
                villager.getOffers().add(new MerchantOffer(new ItemCost(Items.EMERALD, cost[level0][p]),
                        new ItemStack(piece), uses[level0], 5 + level0 * 5, 0.05F));
            }
        }
        villager.setCustomName(Component.translatable("jockball.shopkeeper"));
        villager.setPersistenceRequired();
        level.addFreshEntity(villager);
    }

    private ShopBuilder() {}
}
