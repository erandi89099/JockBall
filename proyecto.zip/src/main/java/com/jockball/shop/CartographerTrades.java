package com.jockball.shop;

import com.jockball.item.ModItems;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.entity.npc.villager.VillagerProfession;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.MerchantOffer;

import java.util.Optional;

/**
 * Los cartografos venden el Mapa de Estadio. Las ofertas de aldeanos son por datos en la 26.x, asi que en vez de
 * tocar sus tablas, cada 10 s revisamos los cartografos cercanos a un jugador y les anadimos la oferta si no la tienen.
 * AJUSTA AQUI el precio.
 */
public final class CartographerTrades {
    private static final int EMERALDS = 24;   // + 1 brujula
    private static final int MAX_USES = 3;

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % 200 != 0) return;
            for (ServerLevel level : server.getAllLevels()) {
                for (ServerPlayer player : level.players()) {
                    for (Villager villager : level.getEntitiesOfClass(Villager.class,
                            player.getBoundingBox().inflate(48.0),
                            v -> v.getVillagerData().profession().is(VillagerProfession.CARTOGRAPHER))) {
                        boolean has = false;
                        for (MerchantOffer offer : villager.getOffers()) {
                            if (offer.getResult().is(ModItems.STADIUM_MAP)) {
                                has = true;
                                break;
                            }
                        }
                        if (!has) {
                            villager.getOffers().add(new MerchantOffer(new ItemCost(Items.EMERALD, EMERALDS),
                                    Optional.of(new ItemCost(Items.COMPASS, 1)),
                                    new ItemStack(ModItems.STADIUM_MAP), MAX_USES, 20, 0.05F));
                        }
                    }
                }
            }
        });
    }

    private CartographerTrades() {}
}
