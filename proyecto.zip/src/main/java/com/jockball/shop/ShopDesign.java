package com.jockball.shop;

import com.jockball.stadium.StadiumDesign;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

import java.util.HashMap;
import java.util.Map;

/**
 * Tienda de equipo para aldeas. Funcion pura (lx, ly, lz) -> bloque, igual que el estadio.
 * Planta de 17 x 15: local x 0..16 (ancho), z 0..14 (fondo). El FRENTE esta en z = 0 (toldos en z = -1).
 *   z 1..5  : sala de ventas (alfombra, cofres con loot, luces)
 *   z 6     : mostrador (vallas: el aldeano no puede pasar, pero tu puedes comerciar por encima)
 *   z 7..8  : zona del vendedor
 *   z 9     : tabique con puerta
 *   z 10..13: trastienda donde vive (cama, alto horno, barril, mesa de trabajo)
 * ly = 0 es el piso (reemplaza el bloque de suelo).
 */
public final class ShopDesign {
    public enum Style {
        //            piso                 pared                 pilar                    acento                  borde               techo               valla            puerta
        PLAINS("oak_planks", "oak_planks", "cobblestone", "spruce_planks", "cobblestone", "oak_planks", "spruce_fence", "oak_door"),
        DESERT("smooth_sandstone", "sandstone", "cut_sandstone", "brown_terracotta", "smooth_sandstone", "smooth_sandstone", "acacia_fence", "acacia_door"),
        SAVANNA("acacia_planks", "acacia_planks", "stripped_acacia_log", "dark_oak_planks", "acacia_planks", "acacia_planks", "acacia_fence", "acacia_door"),
        TAIGA("spruce_planks", "spruce_planks", "cobblestone", "dark_oak_planks", "cobblestone", "spruce_planks", "spruce_fence", "spruce_door");

        final String floor, wall, pillar, accent, trim, roof, fence, door;

        Style(String floor, String wall, String pillar, String accent, String trim, String roof, String fence, String door) {
            this.floor = floor;
            this.wall = wall;
            this.pillar = pillar;
            this.accent = accent;
            this.trim = trim;
            this.roof = roof;
            this.fence = fence;
            this.door = door;
        }
    }

    private static final Map<String, BlockState> CACHE = new HashMap<>();

    private static BlockState named(String id) {
        return CACHE.computeIfAbsent(id,
                k -> BuiltInRegistries.BLOCK.getValue(Identifier.withDefaultNamespace(k)).defaultBlockState());
    }

    private static final BlockState AIR = named("air");
    private static final BlockState GLASS = named("glass");
    private static final BlockState WHITE = named("white_terracotta");
    private static final BlockState BROWN = named("brown_terracotta");
    private static final BlockState CARPET = named("red_carpet");

    private static BlockState door(Style s, DoubleBlockHalf half) {
        return named(s.door).setValue(DoorBlock.HALF, half);
    }

    private static BlockState lantern(boolean hanging) {
        return named("lantern").setValue(LanternBlock.HANGING, hanging);
    }

    private static BlockState sign(int lx, int ly) {
        boolean brown = switch (ly) {
            case 7 -> lx >= 7 && lx <= 9;
            case 6 -> lx != 8;
            default -> lx >= 7 && lx <= 9; // ly 5
        };
        return brown ? BROWN : WHITE;
    }

    /** null = no tocar ese bloque. */
    public static BlockState at(Style s, int lx, int ly, int lz) {
        boolean inBuilding = lx >= 0 && lx <= 16 && lz >= 0 && lz <= 14;

        // toldos al frente
        if (lz == -1 && lx >= 0 && lx <= 16) {
            if (ly == 5 && ((lx >= 1 && lx <= 5) || (lx >= 11 && lx <= 15))) return named(s.accent);
            if (ly == 4 && lx >= 6 && lx <= 10) return named(s.accent);
            return ly >= 1 ? AIR : null;
        }
        if (!inBuilding) return ly >= 1 ? AIR : null; // limpia el margen (arboles, etc.)
        if (ly < 0) return null;

        // ---- fachada ----
        if (lz == 0 && ly >= 1 && ly <= 7) {
            if (lx <= 1 || lx == 5 || lx == 11 || lx >= 15) return ly <= 6 ? named(s.pillar) : named(s.trim);
            if ((lx >= 2 && lx <= 4) || (lx >= 12 && lx <= 14)) {
                if (ly == 1) return named(s.wall);
                if (ly <= 4) return GLASS;
                if (ly == 5) return named(s.accent);
                return ly == 6 ? named(s.wall) : named(s.trim);
            }
            // entrada (lx 6..10)
            if (ly <= 2) return lx == 8 ? door(s, ly == 1 ? DoubleBlockHalf.LOWER : DoubleBlockHalf.UPPER) : GLASS;
            if (ly == 3) return GLASS;
            if (ly == 4) return named(s.accent);
            return sign(lx, ly); // cartel con balon
        }

        if (ly == 0) return named(s.floor);
        if (ly == 6) return named(s.roof);
        boolean perimeter = lx == 0 || lx == 16 || lz == 0 || lz == 14;
        if (ly == 7) return perimeter ? named(s.trim) : AIR;
        if (ly >= 8) return AIR;

        // ---- muros laterales y trasero ----
        if (perimeter) {
            if ((lx == 0 || lx == 16) && lz >= 3 && lz <= 5 && ly >= 2 && ly <= 3) return GLASS;
            if (lz == 14 && lx >= 7 && lx <= 9 && ly >= 2 && ly <= 3) return GLASS;
            return named(s.wall);
        }
        // ---- tabique con puerta ----
        if (lz == 9) {
            if (lx == 8 && ly == 1) return door(s, DoubleBlockHalf.LOWER);
            if (lx == 8 && ly == 2) return door(s, DoubleBlockHalf.UPPER);
            return named(s.wall);
        }

        // ---- interior ----
        if (lz == 6) { // mostrador
            if (ly == 1) {
                return named(s.fence).setValue(FenceBlock.EAST, true).setValue(FenceBlock.WEST, true);
            }
            if (ly == 2 && (lx == 3 || lx == 13)) return lantern(false);
        }
        if (ly == 1 && lx >= 6 && lx <= 10 && lz >= 1 && lz <= 5) return CARPET;
        if (ly == 1 && (lz == 2 || lz == 3)) {
            if (lx == 1) return StadiumDesign.chest(Direction.EAST);
            if (lx == 15) return StadiumDesign.chest(Direction.WEST);
        }
        if (ly == 5 && ((lx == 4 && lz == 3) || (lx == 12 && lz == 3) || (lx == 8 && lz == 4)
                || (lx == 8 && lz == 12) || (lx == 8 && lz == 7))) {
            return lantern(true);
        }
        // trastienda
        if (ly == 1 && lx == 2 && lz == 11) {
            return named("red_bed").setValue(BedBlock.FACING, Direction.SOUTH).setValue(BedBlock.PART, BedPart.FOOT);
        }
        if (ly == 1 && lx == 2 && lz == 12) {
            return named("red_bed").setValue(BedBlock.FACING, Direction.SOUTH).setValue(BedBlock.PART, BedPart.HEAD);
        }
        if (ly == 1 && lx == 14 && lz == 11) return named("blast_furnace");
        if (ly == 1 && lx == 14 && lz == 12) return named("barrel");
        if (ly == 1 && lx == 13 && lz == 13) return named("crafting_table");
        return AIR;
    }

    private ShopDesign() {}
}
