package com.jockball.shop;

import com.jockball.stadium.StadiumDesign;
import com.jockball.stadium.StadiumRegistry;
import com.jockball.stadium.StadiumSites;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Tiendas de equipo como ESTRUCTURA INDEPENDIENTE (ya no dependen de las aldeas).
 *
 * El mundo se divide en regiones de REGION x REGION bloques. Cada region tiene (con probabilidad CHANCE)
 * UN sitio fijo para una tienda, calculado de la semilla del mundo. Cuando un jugador se acerca a menos de
 * TRIGGER bloques, se busca terreno plano cerca del sitio (hasta SEARCH bloques) y se construye, con el frente
 * mirando hacia el jugador. Materiales segun el bioma. No se construye encima de un estadio.
 *
 * AJUSTA AQUI la frecuencia (REGION y CHANCE) y que tan plano debe ser el terreno (MAX_SLOPE).
 */
public final class ShopSites {
    public static final int REGION = 512;      // tamano de la region (mas chico = mas tiendas)
    private static final double CHANCE = 0.70;  // probabilidad de que una region tenga tienda
    private static final int MARGIN = 48;       // la tienda no nace pegada al borde de la region
    private static final int TRIGGER = 96;      // distancia del jugador al sitio para construir
    private static final int SEARCH = 60;       // hasta donde busca terreno plano alrededor del sitio
    private static final int STEP = 12;         // separacion entre candidatos de la busqueda
    private static final int MAX_SLOPE = 5;     // diferencia maxima de altura bajo la tienda
    private static final int STADIUM_CLEARANCE = 30; // distancia minima a un estadio

    /** Devuelve {x, z} del sitio de la region, o null si esa region no tiene tienda. */
    public static int[] siteFor(long seed, int rx, int rz) {
        Random r = new Random(seed ^ (rx * 668265263L) ^ (rz * 374761393L) ^ 0x2545F4914F6CDD1DL);
        r.nextInt();
        if (r.nextDouble() >= CHANCE) return null;
        int x = rx * REGION + MARGIN + r.nextInt(REGION - 2 * MARGIN);
        int z = rz * REGION + MARGIN + r.nextInt(REGION - 2 * MARGIN);
        return new int[]{x, z};
    }

    /** Sitio mas cercano (busca en las regiones vecinas), o null. */
    public static int[] nearest(long seed, int px, int pz) {
        int rx0 = Math.floorDiv(px, REGION), rz0 = Math.floorDiv(pz, REGION);
        int[] best = null;
        double bestD = Double.MAX_VALUE;
        for (int drx = -3; drx <= 3; drx++) {
            for (int drz = -3; drz <= 3; drz++) {
                int[] s = siteFor(seed, rx0 + drx, rz0 + drz);
                if (s == null) continue;
                double d = Math.hypot(s[0] - px, s[1] - pz);
                if (d < bestD) {
                    bestD = d;
                    best = s;
                }
            }
        }
        return best;
    }

    private static ShopDesign.Style styleFor(ServerLevel level, BlockPos pos) {
        Holder<Biome> biome = level.getBiome(pos);
        if (biome.is(Biomes.DESERT) || biome.is(Biomes.BADLANDS) || biome.is(Biomes.ERODED_BADLANDS)
                || biome.is(Biomes.WOODED_BADLANDS)) {
            return ShopDesign.Style.DESERT;
        }
        if (biome.is(Biomes.SAVANNA) || biome.is(Biomes.SAVANNA_PLATEAU) || biome.is(Biomes.WINDSWEPT_SAVANNA)) {
            return ShopDesign.Style.SAVANNA;
        }
        if (biome.is(Biomes.TAIGA) || biome.is(Biomes.SNOWY_TAIGA) || biome.is(Biomes.SNOWY_PLAINS)
                || biome.is(Biomes.OLD_GROWTH_PINE_TAIGA) || biome.is(Biomes.OLD_GROWTH_SPRUCE_TAIGA)) {
            return ShopDesign.Style.TAIGA;
        }
        return ShopDesign.Style.PLAINS;
    }

    private static boolean loaded(ServerLevel level, int x, int z) {
        return level.hasChunk(Math.floorDiv(x, 16), Math.floorDiv(z, 16));
    }

    /** Todos los chunks que toca la tienda (27 x 27 alrededor del centro) estan cargados. */
    private static boolean areaLoaded(ServerLevel level, int cx, int cz) {
        for (int dx = -13; dx <= 13; dx += 13) {
            for (int dz = -13; dz <= 13; dz += 13) {
                if (!loaded(level, cx + dx, cz + dz)) return false;
            }
        }
        return true;
    }

    /**
     * Altura del suelo bajo la tienda, o null si el terreno no sirve (agua o muy irregular).
     * Usa el mapa de altura que IGNORA hojas y plantas, asi los arboles y el pasto no la arruinan
     * (antes usaba uno que los contaba, y en bosques, taigas y sabanas siempre fallaba).
     */
    private static Integer groundY(ServerLevel level, int cx, int cz) {
        int[] h = new int[9];
        int i = 0;
        for (int dx = -8; dx <= 8; dx += 8) {
            for (int dz = -8; dz <= 8; dz += 8) {
                int x = cx + dx, z = cz + dz;
                int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
                if (!level.getBlockState(new BlockPos(x, y, z)).getFluidState().isEmpty()) return null;
                h[i++] = y;
            }
        }
        Arrays.sort(h);
        if (h[8] - h[0] > MAX_SLOPE) return null;
        int y0 = h[4]; // mediana
        if (y0 < level.getMinY() + 8 || y0 + 12 >= level.getMaxY()) return null;
        return y0;
    }

    /** true si (x, z) cae dentro de un estadio (natural, ya construido o por comando) o muy cerca. */
    private static boolean nearStadium(long seed, int x, int z) {
        int rx0 = Math.floorDiv(x, StadiumSites.REGION), rz0 = Math.floorDiv(z, StadiumSites.REGION);
        for (int drx = -1; drx <= 1; drx++) {
            for (int drz = -1; drz <= 1; drz++) {
                int[] s = StadiumSites.siteFor(seed, rx0 + drx, rz0 + drz);
                if (s != null && insideStadium(x, z, s[0], s[1])) return true;
            }
        }
        for (StadiumRegistry.Entry e : StadiumRegistry.entries()) {
            if (insideStadium(x, z, e.ox, e.oz)) return true;
        }
        return false;
    }

    private static boolean insideStadium(int x, int z, int ox, int oz) {
        return Math.abs(x - ox) <= StadiumDesign.HALF_X + STADIUM_CLEARANCE
                && Math.abs(z - oz) <= StadiumDesign.HALF_Z + STADIUM_CLEARANCE;
    }

    /** Orientacion (0 = frente al norte, 1 = este, 2 = sur, 3 = oeste): el frente mira hacia (tx, tz). */
    private static int facing(int cx, int cz, int tx, int tz) {
        int dx = tx - cx, dz = tz - cz;
        if (Math.abs(dx) > Math.abs(dz)) return dx > 0 ? 1 : 3;
        return dz > 0 ? 2 : 0;
    }

    /** Candidatos alrededor del sitio, del mas cercano al mas lejano: el sitio y anillos cuadrados cada STEP. */
    private static List<int[]> candidates() {
        List<int[]> list = new ArrayList<>();
        list.add(new int[]{0, 0});
        for (int r = STEP; r <= SEARCH; r += STEP) {
            for (int dx = -r; dx <= r; dx += STEP) {
                for (int dz = -r; dz <= r; dz += STEP) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) == r) list.add(new int[]{dx, dz});
                }
            }
        }
        return list;
    }

    private enum Result { BUILT, NONE, WAIT }

    private static Result tryBuild(ServerLevel level, long seed, int sx, int sz, int px, int pz) {
        boolean waiting = false;
        for (int[] o : candidates()) {
            int cx = sx + o[0], cz = sz + o[1];
            if (!areaLoaded(level, cx, cz)) {
                waiting = true; // faltan chunks: se reintenta cuando el jugador se acerque
                continue;
            }
            if (nearStadium(seed, cx, cz)) continue;
            Integer y = groundY(level, cx, cz);
            if (y == null) continue;
            ShopDesign.Style style = styleFor(level, new BlockPos(cx, y, cz));
            if (ShopBuilder.build(level, cx, cz, y, facing(cx, cz, px, pz), style)) {
                return Result.BUILT;
            }
            waiting = true;
        }
        return waiting ? Result.WAIT : Result.NONE; // NONE: ningun lugar sirve en esta region, no insistir
    }

    /** Para el comando /jockball shop: construye una tienda 20 bloques frente al jugador. Devuelve null si salio bien. */
    public static String buildInFront(ServerLevel level, ServerPlayer player) {
        Direction d = player.getDirection();
        int cx = player.getBlockX() + d.getStepX() * 20;
        int cz = player.getBlockZ() + d.getStepZ() * 20;
        if (!areaLoaded(level, cx, cz)) return "Esa zona aun no esta cargada; acercate y reintenta.";
        Integer y = groundY(level, cx, cz);
        if (y == null) return "Terreno no apto (agua o muy irregular). Prueba en otro sitio.";
        boolean ok = ShopBuilder.build(level, cx, cz, y, facing(cx, cz, player.getBlockX(), player.getBlockZ()),
                styleFor(level, new BlockPos(cx, y, cz)));
        return ok ? null : "No se pudo construir (chunks sin cargar).";
    }

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % 100 != 0) return;
            ServerLevel level = server.overworld();
            long seed = level.getSeed();
            for (ServerPlayer player : level.players()) {
                int px = player.getBlockX(), pz = player.getBlockZ();
                int rx0 = Math.floorDiv(px, REGION), rz0 = Math.floorDiv(pz, REGION);
                for (int drx = -1; drx <= 1; drx++) {
                    for (int drz = -1; drz <= 1; drz++) {
                        int rx = rx0 + drx, rz = rz0 + drz;
                        if (StadiumRegistry.isShopRegionDone(rx, rz)) continue;
                        int[] site = siteFor(seed, rx, rz);
                        if (site == null) {
                            StadiumRegistry.markShopRegionDone(rx, rz);
                            continue;
                        }
                        if (Math.hypot(site[0] - px, site[1] - pz) > TRIGGER) continue;
                        Result result = tryBuild(level, seed, site[0], site[1], px, pz);
                        if (result != Result.WAIT) {
                            StadiumRegistry.markShopRegionDone(rx, rz);
                        }
                    }
                }
            }
        });
    }

    private ShopSites() {}
}
