package com.jockball.shop;

import com.jockball.stadium.StadiumRegistry;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.StructureTags;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructureStart;

import java.util.Arrays;

/**
 * Cuando entras a una aldea, construye una tienda en su orilla (una sola vez por aldea), con el frente
 * mirando al centro de la aldea. Materiales segun el bioma. AJUSTA AQUI la distancia a la aldea.
 */
public final class ShopSites {
    private static final int GAP = 14; // distancia entre el borde de la aldea y el centro de la tienda

    private static ShopDesign.Style styleFor(ServerLevel level, BlockPos pos) {
        Holder<Biome> biome = level.getBiome(pos);
        if (biome.is(Biomes.DESERT)) return ShopDesign.Style.DESERT;
        if (biome.is(Biomes.SAVANNA) || biome.is(Biomes.SAVANNA_PLATEAU) || biome.is(Biomes.WINDSWEPT_SAVANNA)) {
            return ShopDesign.Style.SAVANNA;
        }
        if (biome.is(Biomes.TAIGA) || biome.is(Biomes.SNOWY_TAIGA) || biome.is(Biomes.SNOWY_PLAINS)
                || biome.is(Biomes.OLD_GROWTH_PINE_TAIGA) || biome.is(Biomes.OLD_GROWTH_SPRUCE_TAIGA)) {
            return ShopDesign.Style.TAIGA;
        }
        return ShopDesign.Style.PLAINS;
    }

    /** Altura del bloque de suelo (mediana de 5 muestras), o -1 si el terreno no sirve (agua o muy irregular). */
    private static int groundY(ServerLevel level, int x, int z) {
        int[][] offs = {{0, 0}, {8, 8}, {-8, 8}, {8, -8}, {-8, -8}};
        int[] h = new int[5];
        for (int i = 0; i < 5; i++) {
            h[i] = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x + offs[i][0], z + offs[i][1]) - 1;
        }
        int[] sorted = h.clone();
        Arrays.sort(sorted);
        if (sorted[4] - sorted[0] > 6) return -1;
        int y = sorted[2];
        BlockPos top = new BlockPos(x, y, z);
        if (!level.getBlockState(top).getFluidState().isEmpty()) return -1;
        return y;
    }

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % 100 != 0) return;
            ServerLevel level = server.overworld();
            for (ServerPlayer player : level.players()) {
                StructureStart start = level.structureManager()
                        .getStructureWithPieceAt(player.blockPosition(), StructureTags.VILLAGE);
                if (start == null || !start.isValid()) continue;
                BoundingBox box = start.getBoundingBox();
                long key = ((long) box.minX() << 32) ^ (box.minZ() & 0xFFFFFFFFL);
                if (StadiumRegistry.isVillageDone(key)) continue;

                int bx = (box.minX() + box.maxX()) / 2, bz = (box.minZ() + box.maxZ()) / 2;
                // candidatos: este, oeste, sur, norte
                int[][] cand = {
                        {box.maxX() + GAP, bz}, {box.minX() - GAP, bz},
                        {bx, box.maxZ() + GAP}, {bx, box.minZ() - GAP}};
                boolean built = false, anyUnloaded = false;
                for (int[] c : cand) {
                    int y = groundY(level, c[0], c[1]);
                    if (y < 0) continue;
                    int dx = bx - c[0], dz = bz - c[1];
                    int k;
                    if (Math.abs(dx) > Math.abs(dz)) k = dx > 0 ? 1 : 3;
                    else k = dz > 0 ? 2 : 0;
                    ShopDesign.Style style = styleFor(level, new BlockPos(c[0], y, c[1]));
                    if (ShopBuilder.build(level, c[0], c[1], y, k, style)) {
                        built = true;
                        break;
                    }
                    anyUnloaded = true;
                }
                if (built || !anyUnloaded) {
                    StadiumRegistry.markVillageDone(key); // construida, o ningun lado sirve: no insistir
                }
            }
        });
    }

    private ShopSites() {}
}
