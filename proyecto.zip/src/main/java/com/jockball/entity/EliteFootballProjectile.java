package com.jockball.entity;

import com.jockball.item.ModItems;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;

/**
 * Balon de Elite lanzado. Lleva consigo la pieza (con sus encantamientos y durabilidad):
 *  - Perforacion N: atraviesa N enemigos extra antes de detenerse.
 *  - Lealtad N: al detenerse vuelve volando a tu mano (mas rapido con mas nivel). Sin Lealtad cae como objeto.
 *  - Filo: ya viene sumado al dano por el objeto al lanzarlo.
 */
public class EliteFootballProjectile extends FootballProjectile {
    private static final int MAX_FLIGHT_TICKS = 200;
    /** Sincronizado con el cliente: mientras vuelve, ambos lados lo mueven a mano (sin colisiones). */
    private static final EntityDataAccessor<Boolean> RETURNING =
            SynchedEntityData.defineId(EliteFootballProjectile.class, EntityDataSerializers.BOOLEAN);

    private ItemStack stack = ItemStack.EMPTY;
    private int loyalty;
    private int piercing;
    private boolean creative;
    private final Set<Integer> alreadyHit = new HashSet<>();

    public EliteFootballProjectile(EntityType<? extends EliteFootballProjectile> type, Level level) {
        super(type, level);
    }

    public void init(ItemStack stack, int loyalty, int piercing, float damage, boolean creative) {
        this.stack = stack;
        this.loyalty = loyalty;
        this.piercing = piercing;
        this.creative = creative;
        this.setDamage(damage);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(RETURNING, false);
    }

    private boolean isReturning() {
        return this.entityData.get(RETURNING);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.ELITE_FOOTBALL;
    }

    @Override
    protected boolean discardOnHit() {
        return false;
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        if (isReturning() || alreadyHit.contains(entity.getId())) return false;
        return super.canHitEntity(entity);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        alreadyHit.add(result.getEntity().getId());
        super.onHitEntity(result); // dano + empuje
        if (piercing > 0) {
            piercing--;            // atraviesa y sigue
        } else {
            finish();
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        if (isReturning()) return;
        super.onHitBlock(result);
        finish();
    }

    /** Fin del vuelo: vuelve con Lealtad o cae al suelo. */
    private void finish() {
        if (isReturning() || this.level().isClientSide()) return;
        Entity owner = this.getOwner();
        if (loyalty > 0 && owner != null && owner.isAlive() && !stack.isEmpty()) {
            this.entityData.set(RETURNING, true);
            this.noPhysics = true;
            this.setNoGravity(true);
            Vec3 to = owner.getEyePosition().subtract(this.position()).normalize();
            this.setDeltaMovement(to.scale(0.6));
        } else {
            dropAndDiscard();
        }
    }

    private void dropAndDiscard() {
        if (!stack.isEmpty() && !creative && this.level() instanceof ServerLevel serverLevel) {
            this.spawnAtLocation(serverLevel, stack);
        }
        this.discard();
    }

    @Override
    public void tick() {
        if (isReturning()) {
            returningTick();
            return;
        }
        if (!this.level().isClientSide() && this.tickCount > MAX_FLIGHT_TICKS) {
            finish();
            if (isReturning()) return;
        }
        super.tick();
    }

    /**
     * Vuelta con Lealtad. NO se llama a super.tick(): el movimiento de los proyectiles de Minecraft coloca la bola
     * en el punto de impacto con el primer bloque que encuentre, asi que un bloque de por medio la dejaba trabada.
     * Aqui se mueve sumando la velocidad a mano, atravesando bloques, tanto en el servidor como en el cliente.
     */
    private void returningTick() {
        Entity owner = this.getOwner();
        if (!this.level().isClientSide()) {
            if (owner == null || !owner.isAlive()) {
                dropAndDiscard();
                return;
            }
            Vec3 to = owner.getEyePosition().subtract(this.position());
            if (to.length() < 1.8) {
                if (owner instanceof Player player && !creative && !stack.isEmpty()) {
                    if (!player.getInventory().add(stack)) {
                        player.drop(stack, false);
                    }
                }
                this.discard();
                return;
            }
            this.setDeltaMovement(this.getDeltaMovement().scale(0.95)
                    .add(to.normalize().scale(0.05 * loyalty + 0.04)));
            this.hasImpulse = true; // para que el cliente reciba la velocidad
        }
        Vec3 v = this.getDeltaMovement();
        this.setPos(this.getX() + v.x, this.getY() + v.y, this.getZ() + v.z);
    }
}
