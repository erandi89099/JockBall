package com.jockball.entity.ai;

import com.jockball.JockBall;
import com.jockball.entity.FootballPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.projectile.EvokerFangs;

import java.util.EnumSet;
import java.util.List;

/**
 * Pisoton (liniero y capitan): levanta el brazo, golpea el suelo y salen las fauces del invocador
 * en linea hacia el objetivo y en circulo alrededor. ADEMAS, una onda de choque saca volando a los que
 * esten cerca: los empuja hacia atras y les da Levitacion IV durante 1 segundo.
 * AJUSTA AQUI: alcance de la linea, fauces, tiempos, enfriamiento y la onda de choque.
 */
public class StompGoal extends Goal {
    private static final int WINDUP = 26;
    private static final int COOLDOWN = 140;
    private static final int LINE_FANGS = 8;      // fauces en la linea
    private static final double LINE_STEP = 1.6;  // separacion entre fauces
    private static final int RING_FANGS = 8;
    private static final double RING_RADIUS = 2.3;

    // ---- onda de choque ----
    private static final double WAVE_RADIUS = 10.0;    // bloques a la redonda (antes 6)
    private static final double WAVE_KNOCKBACK = 3.0;  // empuje hacia atras (antes 1.5; la taclada usa 4.5)
    private static final int LEVITATION_TICKS = 20;    // 20 ticks = 1 segundo
    private static final int LEVITATION_AMP = 3;       // 3 = Levitacion IV
    /** Fraccion del dano normal del mob que hace la onda (el golpe es lo que sincroniza el empuje). */
    private static final double WAVE_DAMAGE = 0.5;
    private static final Identifier WAVE_DMG_ID = JockBall.id("stomp_wave_damage");

    private final FootballPlayer mob;
    private int timer;
    private int nextUse;
    private boolean active;

    public StompGoal(FootballPlayer mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity target = mob.getTarget();
        if (target == null || !target.isAlive() || mob.tickCount < nextUse || !mob.onGround()) return false;
        double d = mob.distanceTo(target);
        return d >= 2.5 && d <= 10.0 && mob.hasLineOfSight(target);
    }

    @Override
    public boolean canContinueToUse() {
        return active;
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void start() {
        active = true;
        timer = WINDUP;
        mob.getNavigation().stop();
    }

    @Override
    public void stop() {
        active = false;
        nextUse = mob.tickCount + (int) (COOLDOWN * mob.cooldownScale());
    }

    @Override
    public void tick() {
        LivingEntity target = mob.getTarget();
        mob.getNavigation().stop();
        if (target != null) mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (timer % 7 == 0) mob.swing(InteractionHand.MAIN_HAND); // levanta el brazo
        if (--timer > 0) return;

        if (mob.level() instanceof ServerLevel level) {
            double dirX, dirZ;
            if (target != null) {
                dirX = target.getX() - mob.getX();
                dirZ = target.getZ() - mob.getZ();
            } else {
                dirX = 0;
                dirZ = 1;
            }
            double len = Math.sqrt(dirX * dirX + dirZ * dirZ);
            if (len < 0.01) len = 1.0;
            dirX /= len;
            dirZ /= len;
            float yaw = (float) (Math.atan2(dirZ, dirX) * 57.29578F) - 90.0F;

            for (int i = 1; i <= LINE_FANGS; i++) {
                spawnFang(level, mob.getX() + dirX * i * LINE_STEP, mob.getZ() + dirZ * i * LINE_STEP, yaw, i * 2);
            }
            for (int i = 0; i < RING_FANGS; i++) {
                double a = i * (Math.PI * 2 / RING_FANGS);
                spawnFang(level, mob.getX() + Math.cos(a) * RING_RADIUS, mob.getZ() + Math.sin(a) * RING_RADIUS, yaw, 0);
            }
            shockwave(level);
            mob.playSound(SoundEvents.ANVIL_LAND, 1.0F, 0.6F);
        }
        active = false;
    }

    /** Onda de choque: empuja hacia atras y levanta (Levitacion IV, 1 s) a todo lo que este cerca. */
    private void shockwave(ServerLevel level) {
        AttributeInstance dmg = mob.getAttribute(Attributes.ATTACK_DAMAGE);
        if (dmg != null) {
            dmg.addOrUpdateTransientModifier(new AttributeModifier(
                    WAVE_DMG_ID, WAVE_DAMAGE - 1.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        List<LivingEntity> victims = level.getEntitiesOfClass(LivingEntity.class,
                mob.getBoundingBox().inflate(WAVE_RADIUS, 2.5, WAVE_RADIUS),
                e -> e != mob && !(e instanceof FootballPlayer) && e.distanceTo(mob) <= WAVE_RADIUS);
        for (LivingEntity victim : victims) {
            // el golpe real sincroniza el empuje con el jugador; luego va el empuje radial y la levitacion
            if (mob.doHurtTarget(level, victim)) {
                Knock.push(victim, WAVE_KNOCKBACK, victim.getX() - mob.getX(), victim.getZ() - mob.getZ());
                victim.addEffect(new MobEffectInstance(MobEffects.LEVITATION, LEVITATION_TICKS, LEVITATION_AMP));
            }
        }
        if (dmg != null) {
            dmg.removeModifier(WAVE_DMG_ID);
        }
    }

    private void spawnFang(ServerLevel level, double x, double z, float yaw, int delay) {
        double y = groundY(level, x, z);
        level.addFreshEntity(new EvokerFangs(level, x, y, z, yaw, delay, mob));
    }

    /** Busca el suelo cerca de la altura del jugador. */
    private double groundY(ServerLevel level, double x, double z) {
        int startY = (int) Math.floor(mob.getY()) + 2;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int y = startY; y >= startY - 6; y--) {
            p.set((int) Math.floor(x), y, (int) Math.floor(z));
            boolean airHere = level.getBlockState(p).getCollisionShape(level, p).isEmpty();
            p.set((int) Math.floor(x), y - 1, (int) Math.floor(z));
            boolean solidBelow = !level.getBlockState(p).getCollisionShape(level, p).isEmpty();
            if (airHere && solidBelow) return y;
        }
        return mob.getY();
    }
}
