package com.jockball.entity.ai;

import com.jockball.entity.FootballPlayer;
import com.jockball.entity.Position;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/**
 * El entrenador se esconde: se coloca DETRAS de un liniero despierto, con el liniero entre el y tu.
 * Se recalcula cada pocos ticks, asi que si te mueves, el cambia de lado. Si no hay linieros cerca,
 * este objetivo no se activa y huye a distancia (AvoidEntityGoal, como el invocador).
 */
public class HideBehindGoal extends Goal {
    private static final double TRIGGER = 22.0;   // empieza a esconderse si estas a menos de esto
    private static final double COVER_RANGE = 28.0;
    private static final double BEHIND = 2.6;     // cuanto detras del liniero se pone

    private final FootballPlayer mob;
    private FootballPlayer cover;
    private int recalc;

    public HideBehindGoal(FootballPlayer mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    private FootballPlayer findCover() {
        List<FootballPlayer> linemen = mob.level().getEntitiesOfClass(FootballPlayer.class,
                mob.getBoundingBox().inflate(COVER_RANGE),
                f -> f != mob && f.isAlive() && !f.isDormant() && f.getFootballPosition() == Position.LINEMAN);
        return linemen.stream().min(Comparator.comparingDouble(mob::distanceToSqr)).orElse(null);
    }

    @Override
    public boolean canUse() {
        LivingEntity target = mob.getTarget();
        if (target == null || !target.isAlive() || mob.distanceTo(target) > TRIGGER) return false;
        cover = findCover();
        return cover != null;
    }

    @Override
    public boolean canContinueToUse() {
        LivingEntity target = mob.getTarget();
        return target != null && target.isAlive() && cover != null && cover.isAlive()
                && mob.distanceTo(target) < TRIGGER + 4.0;
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void start() {
        recalc = 0;
    }

    @Override
    public void tick() {
        LivingEntity target = mob.getTarget();
        if (target == null || cover == null) return;
        if (--recalc > 0) return;
        recalc = 8;
        Vec3 away = new Vec3(cover.getX() - target.getX(), 0.0, cover.getZ() - target.getZ());
        if (away.lengthSqr() < 0.01) away = new Vec3(1.0, 0.0, 0.0);
        away = away.normalize().scale(BEHIND);
        mob.getNavigation().moveTo(cover.getX() + away.x, cover.getY(), cover.getZ() + away.z, 1.3);
    }
}
