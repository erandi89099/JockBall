package com.jockball.entity.ai;

import com.jockball.JockBall;
import com.jockball.entity.FootballPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;
import java.util.List;

/**
 * Taclada tipo cabra (apoyador y capitan): se agacha y bufa (preparacion), embiste en linea recta
 * y, si conecta, golpea con fuerza y empuja MUY lejos; despues queda aturdido un momento.
 * AJUSTA AQUI: distancias, velocidad (SPEED), tiempos, enfriamiento, y la POTENCIA de la taclada
 * (DAMAGE_MULT y KNOCKBACK).
 */
public class ChargeGoal extends Goal {
    private static final double SPEED = 0.55;     // bloques por tick durante la embestida
    private static final int WINDUP = 20;         // ticks de preparacion
    private static final int CHARGE = 24;         // ticks maximos de embestida
    private static final int STUN = 30;           // ticks aturdido
    private static final int COOLDOWN = 120;      // ticks hasta poder repetir

    /** Multiplicador del dano de la taclada. 3.0 = +200% (x3). Pon 4.0 para +300%. */
    private static final double DAMAGE_MULT = 3.0;
    /** Fuerza del empuje de la taclada. Antes era ~1.0; 3.0 = +200%. Pon 4.0 para +300%. */
    private static final double KNOCKBACK = 3.0;

    private static final Identifier DMG_ID = JockBall.id("charge_damage");

    private final FootballPlayer mob;
    private int phase;            // 0 = libre, 1 = preparando, 2 = embistiendo, 3 = aturdido
    private int timer;
    private int nextUse;
    private double dirX, dirZ;

    public ChargeGoal(FootballPlayer mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity target = mob.getTarget();
        if (target == null || !target.isAlive() || mob.tickCount < nextUse || !mob.onGround()) return false;
        double d = mob.distanceTo(target);
        return d >= 4.0 && d <= 14.0 && mob.hasLineOfSight(target);
    }

    @Override
    public boolean canContinueToUse() {
        return phase != 0;
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void start() {
        phase = 1;
        timer = WINDUP;
        mob.getNavigation().stop();
        mob.playSound(SoundEvents.RAVAGER_ROAR, 0.8F, 1.3F);
    }

    @Override
    public void stop() {
        phase = 0;
        nextUse = mob.tickCount + COOLDOWN;
    }

    @Override
    public void tick() {
        LivingEntity target = mob.getTarget();
        if (phase == 1) {
            mob.getNavigation().stop();
            if (target != null) mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
            if (--timer <= 0) {
                if (target == null) {
                    phase = 0;
                    return;
                }
                double dx = target.getX() - mob.getX(), dz = target.getZ() - mob.getZ();
                double len = Math.sqrt(dx * dx + dz * dz);
                if (len < 0.01) len = 1.0;
                dirX = dx / len;
                dirZ = dz / len;
                phase = 2;
                timer = CHARGE;
            }
        } else if (phase == 2) {
            mob.setDeltaMovement(dirX * SPEED, mob.getDeltaMovement().y, dirZ * SPEED);
            if (mob.level() instanceof ServerLevel serverLevel) {
                List<LivingEntity> victims = serverLevel.getEntitiesOfClass(LivingEntity.class,
                        mob.getBoundingBox().inflate(0.5, 0.2, 0.5),
                        e -> e != mob && !(e instanceof FootballPlayer));
                if (!victims.isEmpty()) {
                    // dano x DAMAGE_MULT solo durante el golpe de taclada
                    AttributeInstance dmg = mob.getAttribute(Attributes.ATTACK_DAMAGE);
                    if (dmg != null) {
                        dmg.addOrUpdateTransientModifier(new AttributeModifier(
                                DMG_ID, DAMAGE_MULT - 1.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
                    }
                    for (LivingEntity victim : victims) {
                        // el golpe real sincroniza al jugador; el empuje va en la direccion de la embestida
                        if (mob.doHurtTarget(serverLevel, victim)) {
                            victim.knockback(KNOCKBACK, -dirX, -dirZ);
                        }
                    }
                    if (dmg != null) {
                        dmg.removeModifier(DMG_ID);
                    }
                    mob.playSound(SoundEvents.ANVIL_LAND, 0.6F, 1.4F);
                    phase = 3;
                    timer = STUN;
                    return;
                }
            }
            if (mob.horizontalCollision || --timer <= 0) {
                phase = 3;
                timer = STUN;
            }
        } else if (phase == 3) {
            mob.getNavigation().stop();
            if (--timer <= 0) {
                phase = 0;
            }
        }
    }
}
