package com.jockball.entity.ai;

import com.jockball.entity.FootballPlayer;
import net.minecraft.server.level.ServerLevel;
import com.jockball.JockBall;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/**
 * Taclada tipo cabra (apoyador y capitan): se agacha y bufa (preparacion), embiste en linea recta
 * y, si conecta, golpea con fuerza y empuja lejos; despues queda aturdido un momento.
 * AJUSTA AQUI: distancias, velocidad (SPEED), tiempos y enfriamiento.
 */
public class ChargeGoal extends Goal {
    private static final double SPEED = 0.55;     // bloques por tick durante la embestida
    private static final int WINDUP = 20;         // ticks de preparacion
    private static final int CHARGE = 24;         // ticks maximos de embestida
    private static final int STUN = 30;           // ticks aturdido
    private static final int COOLDOWN = 120;      // ticks hasta poder repetir
    private static final double KNOCKBACK = 2.0;   // retroceso extra del golpe de embestida
    private static final Identifier KB_ID = JockBall.id("charge_knockback");

    private final FootballPlayer mob;
    private int phase;            // 0 = libre, 1 = preparando, 2 = embistiendo, 3 = aturdido
    private int timer;
    private int nextUse;
    private double dirX, dirZ;

    public ChargeGoal(FootballPlayer mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity target = mob.getTarget();
        if (target == null || !target.isAlive() || mob.tickCount < nextUse || !mob.onGround()) return false;
        double d = mob.distanceTo(target);
        return d >= 4.0 && d <= 14.0 && mob.hasLineOfSight(target);
    }

    @Override
    public boolean canContinueToUse() {
        return phase != 0;
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void start() {
        phase = 1;
        timer = WINDUP;
        mob.getNavigation().stop();
        mob.playSound(SoundEvents.RAVAGER_ROAR, 0.8F, 1.3F);
    }

    @Override
    public void stop() {
        phase = 0;
        nextUse = mob.tickCount + COOLDOWN;
    }

    @Override
    public void tick() {
        LivingEntity target = mob.getTarget();
        if (phase == 1) {
            mob.getNavigation().stop();
            if (target != null) mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
            if (--timer <= 0) {
                if (target == null) {
                    phase = 0;
                    return;
                }
                double dx = target.getX() - mob.getX(), dz = target.getZ() - mob.getZ();
                double len = Math.sqrt(dx * dx + dz * dz);
                if (len < 0.01) len = 1.0;
                dirX = dx / len;
                dirZ = dz / len;
                phase = 2;
                timer = CHARGE;
            }
        } else if (phase == 2) {
            mob.setDeltaMovement(dirX * SPEED, mob.getDeltaMovement().y, dirZ * SPEED);
            if (mob.level() instanceof ServerLevel serverLevel) {
                for (LivingEntity victim : serverLevel.getEntitiesOfClass(LivingEntity.class,
                        mob.getBoundingBox().inflate(0.5, 0.2, 0.5), e -> e != mob && !(e instanceof FootballPlayer))) {
                    AttributeInstance kb = mob.getAttribute(Attributes.ATTACK_KNOCKBACK);
                    if (kb != null) {
                        kb.addOrUpdateTransientModifier(
                                new AttributeModifier(KB_ID, KNOCKBACK, AttributeModifier.Operation.ADD_VALUE));
                    }
                    mob.doHurtTarget(serverLevel, victim); // el golpe ya empuja; con el extra sale volando
                    if (kb != null) {
                        kb.removeModifier(KB_ID);
                    }
                    mob.playSound(SoundEvents.ANVIL_LAND, 0.6F, 1.4F);
                    phase = 3;
                    timer = STUN;
                    return;
                }
            }
            if (mob.horizontalCollision || --timer <= 0) {
                phase = 3;
                timer = STUN;
            }
        } else if (phase == 3) {
            mob.getNavigation().stop();
            if (--timer <= 0) {
                phase = 0;
            }
        }
    }
}
