package com.jockball.entity.ai;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;

/**
 * Empuje propio (en 26.2 el knockback() de vanilla pide mas parametros). Imita al de vanilla:
 * respeta la resistencia al empuje y da un salto corto si estaba en el suelo.
 * Se llama justo despues de doHurtTarget, que es lo que sincroniza el movimiento con el jugador.
 * (dx, dz) = direccion HACIA DONDE sale empujado.
 */
public final class Knock {
    public static void push(LivingEntity victim, double strength, double dx, double dz) {
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.0E-4) {
            dx = 1.0;
            dz = 0.0;
            len = 1.0;
        }
        double s = strength * (1.0 - victim.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE));
        if (s <= 0.0) return;
        Vec3 v = victim.getDeltaMovement();
        double vy = victim.onGround() ? Math.min(0.4, v.y / 2.0 + s) : v.y;
        victim.setDeltaMovement(v.x / 2.0 + dx / len * s, vy, v.z / 2.0 + dz / len * s);
    }

    private Knock() {}
}
