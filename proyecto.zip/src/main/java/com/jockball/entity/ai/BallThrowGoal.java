package com.jockball.entity.ai;

import com.jockball.entity.FootballPlayer;
import com.jockball.entity.FootballProjectile;
import com.jockball.entity.ModEntities;
import com.jockball.item.ModItems;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.item.ItemStack;

import java.util.EnumSet;

/**
 * Lanzamiento de balones a distancia (quarterback: un pase; pateador: de 5 a 10 balones en abanico, como el
 * encantamiento Multidisparo). Se prepara un momento
 * (queda quieto mirandote) y lanza con un poco de arco. Solo a distancia media: de cerca pelea normal.
 */
public class BallThrowGoal extends Goal {
    private static final int WINDUP = 14;
    private static final double MIN_RANGE = 5.0, MAX_RANGE = 22.0;

    private final FootballPlayer mob;
    private static final double FAN_STEP = 6.0;      // grados entre balones
    private static final double FAN_MAX = 55.0;      // el abanico nunca pasa de +-27.5 grados

    private final int cooldown, minBalls, maxBalls;
    private final float speed, damage, spread;
    private int timer;
    private int nextUse;
    private boolean active;

    public BallThrowGoal(FootballPlayer mob, int cooldown, int minBalls, int maxBalls, float speed, float damage,
                         float spread) {
        this.mob = mob;
        this.cooldown = cooldown;
        this.minBalls = minBalls;
        this.maxBalls = maxBalls;
        this.speed = speed;
        this.damage = damage;
        this.spread = spread;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity target = mob.getTarget();
        if (target == null || !target.isAlive() || mob.tickCount < nextUse) return false;
        double d = mob.distanceTo(target);
        return d >= MIN_RANGE && d <= MAX_RANGE && mob.hasLineOfSight(target);
    }

    @Override
    public boolean canContinueToUse() {
        return active;
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void start() {
        active = true;
        timer = WINDUP;
        mob.getNavigation().stop();
    }

    @Override
    public void stop() {
        active = false;
        nextUse = mob.tickCount + (int) (cooldown * mob.cooldownScale());
    }

    @Override
    public void tick() {
        LivingEntity target = mob.getTarget();
        mob.getNavigation().stop();
        if (target == null) {
            active = false;
            return;
        }
        mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (--timer > 0) return;

        if (mob.level() instanceof ServerLevel level) {
            double dx = target.getX() - mob.getX();
            double dy = target.getY(0.33) - mob.getEyeY();
            double dz = target.getZ() - mob.getZ();
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            int balls = minBalls + mob.getRandom().nextInt(maxBalls - minBalls + 1);
            double step = balls > 1 ? Math.min(FAN_STEP, FAN_MAX / (balls - 1)) : 0.0;
            double base = Math.atan2(dz, dx);
            for (int i = 0; i < balls; i++) {
                double angle = base + Math.toRadians((i - (balls - 1) / 2.0) * step);
                FootballProjectile ball = new FootballProjectile(ModEntities.FOOTBALL, level);
                ball.setOwner(mob);
                ball.setPos(mob.getX(), mob.getEyeY() - 0.2, mob.getZ());
                ball.setItem(new ItemStack(ModItems.FOOTBALL));
                ball.setDamage(damage);
                ball.shoot(Math.cos(angle) * horizontal, dy + horizontal * 0.12, Math.sin(angle) * horizontal,
                        speed, spread); // algo de arco
                level.addFreshEntity(ball);
            }
            mob.playSound(SoundEvents.SNOWBALL_THROW, 1.0F, 0.5F);
        }
        active = false;
    }
}
