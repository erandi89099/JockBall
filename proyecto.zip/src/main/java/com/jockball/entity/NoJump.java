package com.jockball.entity;

import com.jockball.JockBall;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Quita la capacidad de saltar durante un rato (golpe del corredor): baja la fuerza de salto a 0.
 * Es un modificador temporal que se retira solo al pasar el tiempo.
 */
public final class NoJump {
    private static final Identifier ID = JockBall.id("no_jump");
    private static final Map<LivingEntity, Integer> EXPIRY = new IdentityHashMap<>();

    public static void apply(ServerLevel level, LivingEntity victim, int ticks) {
        AttributeInstance jump = victim.getAttribute(Attributes.JUMP_STRENGTH);
        if (jump == null) return;
        jump.addOrUpdateTransientModifier(new AttributeModifier(ID, -2.0, AttributeModifier.Operation.ADD_VALUE));
        EXPIRY.put(victim, level.getServer().getTickCount() + ticks);
    }

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (EXPIRY.isEmpty()) return;
            int now = server.getTickCount();
            Iterator<Map.Entry<LivingEntity, Integer>> it = EXPIRY.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<LivingEntity, Integer> e = it.next();
                LivingEntity victim = e.getKey();
                if (victim.isRemoved() || now >= e.getValue()) {
                    AttributeInstance jump = victim.getAttribute(Attributes.JUMP_STRENGTH);
                    if (jump != null) jump.removeModifier(ID);
                    it.remove();
                }
            }
        });
    }

    private NoJump() {}
}
