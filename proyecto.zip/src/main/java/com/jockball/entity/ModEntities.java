package com.jockball.entity;

import com.jockball.JockBall;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import com.jockball.Achievements;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import java.util.EnumMap;
import java.util.Map;

public final class ModEntities {
    public static final Map<Position, EntityType<FootballPlayer>> TYPES = new EnumMap<>(Position.class);

    public static final EntityType<FootballProjectile> FOOTBALL;
    public static final EntityType<EliteFootballProjectile> ELITE_FOOTBALL;

    static {
        ResourceKey<EntityType<?>> ballKey = ResourceKey.create(Registries.ENTITY_TYPE, JockBall.id("football"));
        FOOTBALL = Registry.register(BuiltInRegistries.ENTITY_TYPE, ballKey, EntityType.Builder
                .<FootballProjectile>of(FootballProjectile::new, MobCategory.MISC)
                .sized(0.3F, 0.3F)
                .clientTrackingRange(4)
                .updateInterval(10)
                .build(ballKey));
        ResourceKey<EntityType<?>> eliteKey = ResourceKey.create(Registries.ENTITY_TYPE, JockBall.id("elite_football"));
        ELITE_FOOTBALL = Registry.register(BuiltInRegistries.ENTITY_TYPE, eliteKey, EntityType.Builder
                .<EliteFootballProjectile>of(EliteFootballProjectile::new, MobCategory.MISC)
                .sized(0.4F, 0.4F)
                .clientTrackingRange(6)
                .updateInterval(2)
                .build(eliteKey));
        for (Position pos : Position.values()) {
            ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, JockBall.id(pos.id));
            EntityType<FootballPlayer> type = EntityType.Builder
                    .<FootballPlayer>of(FootballPlayer::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F)
                    .build(key);
            TYPES.put(pos, Registry.register(BuiltInRegistries.ENTITY_TYPE, key, type));
        }
    }

    public static void initialize() {
        // los jugadores no se hacen dano entre si (fauces, embestidas...)
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof FootballPlayer && source.getEntity() instanceof FootballPlayer) return false;
            // para el logro "sin recibir dano": anota a quien recibe golpes de un estadio
            if (entity instanceof ServerPlayer player && source.getEntity() instanceof FootballPlayer fp && fp.hasHome()) {
                Achievements.markHurt(fp.getHomeX(), fp.getHomeZ(), player.getUUID());
            }
            return true;
        });
        for (Map.Entry<Position, EntityType<FootballPlayer>> e : TYPES.entrySet()) {
            FabricDefaultAttributeRegistry.register(e.getValue(), e.getKey().attributes());
        }
    }

    private ModEntities() {}
}
