package com.jockball.entity;

import com.jockball.JockBall;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import java.util.EnumMap;
import java.util.Map;

public final class ModEntities {
    public static final Map<Position, EntityType<FootballPlayer>> TYPES = new EnumMap<>(Position.class);

    static {
        for (Position pos : Position.values()) {
            ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, JockBall.id(pos.id));
            EntityType<FootballPlayer> type = EntityType.Builder
                    .<FootballPlayer>of(FootballPlayer::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F)
                    .build(key);
            TYPES.put(pos, Registry.register(BuiltInRegistries.ENTITY_TYPE, key, type));
        }
    }

    public static void initialize() {
        for (Map.Entry<Position, EntityType<FootballPlayer>> e : TYPES.entrySet()) {
            FabricDefaultAttributeRegistry.register(e.getValue(), e.getKey().attributes());
        }
    }

    private ModEntities() {}
}
