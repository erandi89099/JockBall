package com.jockball.entity;

import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.monster.zombie.Zombie;

/**
 * Posiciones de juego y sus estadisticas BASE (de reserva).
 * Los titulares reciben un multiplicador extra (ver FootballPlayer).
 * TODO el balance de enemigos esta aqui.
 */
public enum Position {
    //               id            vida  dano  veloc  armad  empuje  salto  tamano  color nombre
    LINEMAN("lineman",             34,    5,   0.20,   4,    0.6,   0.42,  1.20,  ChatFormatting.RED),          // liniero: lento, enorme y tanque
    RUNNING_BACK("running_back",   24,    4,   0.30,   1,    0.1,   0.42,  0.95,  ChatFormatting.GOLD),         // corredor: rapido y bajito
    RECEIVER("receiver",           20,    3,   0.34,   0,    0.0,   0.62,  1.05,  ChatFormatting.AQUA),         // receptor: rapidisimo, salta mucho
    LINEBACKER("linebacker",       30,    6,   0.25,   3,    0.3,   0.42,  1.10,  ChatFormatting.DARK_PURPLE),  // apoyador: fuerte y resistente
    SAFETY("safety",               26,    4,   0.28,   2,    0.2,   0.42,  1.00,  ChatFormatting.DARK_AQUA),    // safety: equilibrado
    CAPTAIN("captain",            250,   12,   0.32,  15,    0.8,   0.42,  1.30,  ChatFormatting.YELLOW);       // capitan: jefe

    public final String id;
    public final ChatFormatting color;
    private final double health, attack, speed, armor, knockbackRes, jump, scale;

    Position(String id, double health, double attack, double speed, double armor, double knockbackRes,
             double jump, double scale, ChatFormatting color) {
        this.id = id;
        this.health = health;
        this.attack = attack;
        this.speed = speed;
        this.armor = armor;
        this.knockbackRes = knockbackRes;
        this.jump = jump;
        this.scale = scale;
        this.color = color;
    }

    public boolean isCaptain() {
        return this == CAPTAIN;
    }

    public static Position byId(String id) {
        for (Position p : values()) {
            if (p.id.equals(id)) return p;
        }
        return LINEMAN;
    }

    public AttributeSupplier.Builder attributes() {
        AttributeSupplier.Builder b = Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, health)
                .add(Attributes.ATTACK_DAMAGE, attack)
                .add(Attributes.MOVEMENT_SPEED, speed)
                .add(Attributes.ARMOR, armor)
                .add(Attributes.KNOCKBACK_RESISTANCE, knockbackRes)
                .add(Attributes.FOLLOW_RANGE, 40.0)
                .add(Attributes.JUMP_STRENGTH, jump)
                .add(Attributes.SCALE, scale);
        if (isCaptain()) {
            b.add(Attributes.ARMOR_TOUGHNESS, 8.0);
            b.add(Attributes.MAX_ABSORPTION, 20.0);
        }
        return b;
    }
}
