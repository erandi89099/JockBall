package com.jockball.entity;

import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.monster.zombie.Zombie;

/**
 * Posiciones de juego y sus estadisticas BASE (de reserva).
 * Los titulares reciben un multiplicador extra (ver FootballPlayer).
 * TODO el balance de enemigos esta aqui.
 */
public enum Position {
    //               id            vida  dano  veloc  armad  resEmp  salto  tamano  color nombre                  empuje
    LINEMAN("lineman",             34,    5,   0.20,   4,    0.6,   0.42,  1.20,  ChatFormatting.RED,          1.5),  // liniero: lento, enorme y tanque
    RUNNING_BACK("running_back",   24,    4,   0.30,   1,    0.1,   0.42,  0.95,  ChatFormatting.GOLD,         0.8),  // corredor: rapido y bajito
    RECEIVER("receiver",           20,    3,   0.34,   0,    0.0,   0.70,  1.05,  ChatFormatting.AQUA,         0.8),  // receptor: rapidisimo, salta 3 bloques
    LINEBACKER("linebacker",       30,    6,   0.25,   3,    0.3,   0.42,  1.10,  ChatFormatting.DARK_PURPLE,  1.5),  // apoyador: fuerte, golpe que ralentiza
    SAFETY("safety",               26,    4,   0.28,   2,    0.2,   0.42,  1.00,  ChatFormatting.DARK_AQUA,    1.2),  // safety: golpe que ciega
    CAPTAIN("captain",            250,   12,   0.32,  15,    0.8,   0.42,  1.30,  ChatFormatting.YELLOW,       2.5),  // capitan: jefe (3 fases)
    QUARTERBACK("quarterback",     22,    3,   0.26,   0,    0.1,   0.42,  1.00,  ChatFormatting.GREEN,        0.5),  // quarterback: lanza balones
    KICKER("kicker",               70,    4,   0.27,   2,    0.2,   0.42,  1.10,  ChatFormatting.LIGHT_PURPLE, 1.0),  // pateador: MINI-JEFE, rafaga de balones
    COACH("coach",                 90,    6,   0.24,   4,    0.5,   0.42,  1.15,  ChatFormatting.DARK_GREEN,   1.5);  // entrenador: MINI-JEFE, potencia al equipo

    public final String id;
    public final ChatFormatting color;
    private final double health, attack, speed, armor, knockbackRes, jump, scale, knock;

    Position(String id, double health, double attack, double speed, double armor, double knockbackRes,
             double jump, double scale, ChatFormatting color, double knock) {
        this.id = id;
        this.health = health;
        this.attack = attack;
        this.speed = speed;
        this.armor = armor;
        this.knockbackRes = knockbackRes;
        this.jump = jump;
        this.scale = scale;
        this.color = color;
        this.knock = knock;
    }

    /** Jefe o mini-jefe: tiene barra de jefe propia. */
    public boolean isBoss() {
        return this == CAPTAIN || this == KICKER || this == COACH;
    }

    public boolean isRanged() {
        return this == QUARTERBACK || this == KICKER;
    }

    public boolean isCaptain() {
        return this == CAPTAIN;
    }

    public static Position byId(String id) {
        for (Position p : values()) {
            if (p.id.equals(id)) return p;
        }
        return LINEMAN;
    }

    public AttributeSupplier.Builder attributes() {
        AttributeSupplier.Builder b = Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, health)
                .add(Attributes.ATTACK_DAMAGE, attack)
                .add(Attributes.MOVEMENT_SPEED, speed)
                .add(Attributes.ARMOR, armor)
                .add(Attributes.KNOCKBACK_RESISTANCE, knockbackRes)
                .add(Attributes.FOLLOW_RANGE, 40.0)
                .add(Attributes.ATTACK_KNOCKBACK, knock)   // empuje de cada golpe normal (sin tocar el dano)
                .add(Attributes.JUMP_STRENGTH, jump)
                .add(Attributes.SCALE, scale);
        if (this == RECEIVER || this == CAPTAIN) {
            // salta 3 bloques (el Capitan en su ultimo cuarto): sin esto cada salto le haria dano de caida
            b.add(Attributes.SAFE_FALL_DISTANCE, 10.0);
        }
        if (isCaptain()) {
            b.add(Attributes.ARMOR_TOUGHNESS, 8.0);
            b.add(Attributes.MAX_ABSORPTION, 20.0);
        }
        return b;
    }
}
