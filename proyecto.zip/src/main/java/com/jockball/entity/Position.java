package com.jockball.entity;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.monster.zombie.Zombie;

/**
 * Posiciones de juego y sus estadisticas BASE (de reserva).
 * Los titulares reciben un multiplicador extra (ver FootballPlayer).
 * TODO el balance de enemigos esta aqui.
 */
public enum Position {
    //               id             vida  dano  veloc  armad  resist.empuje
    LINEMAN("lineman",             34,    5,   0.20,   4,    0.6),   // liniero: lento y tanque
    RUNNING_BACK("running_back",   24,    4,   0.30,   1,    0.1),   // corredor: rapido
    RECEIVER("receiver",           20,    3,   0.34,   0,    0.0),   // receptor: rapidisimo y fragil
    LINEBACKER("linebacker",       30,    6,   0.25,   3,    0.3),   // apoyador: fuerte y resistente
    SAFETY("safety",               26,    4,   0.28,   2,    0.2),   // safety: equilibrado
    CAPTAIN("captain",            250,   12,   0.32,  15,    0.8);   // capitan: jefe

    public final String id;
    private final double health, attack, speed, armor, knockbackRes;

    Position(String id, double health, double attack, double speed, double armor, double knockbackRes) {
        this.id = id;
        this.health = health;
        this.attack = attack;
        this.speed = speed;
        this.armor = armor;
        this.knockbackRes = knockbackRes;
    }

    public boolean isCaptain() {
        return this == CAPTAIN;
    }

    public static Position byId(String id) {
        for (Position p : values()) {
            if (p.id.equals(id)) return p;
        }
        return LINEMAN;
    }

    public AttributeSupplier.Builder attributes() {
        AttributeSupplier.Builder b = Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, health)
                .add(Attributes.ATTACK_DAMAGE, attack)
                .add(Attributes.MOVEMENT_SPEED, speed)
                .add(Attributes.ARMOR, armor)
                .add(Attributes.KNOCKBACK_RESISTANCE, knockbackRes)
                .add(Attributes.FOLLOW_RANGE, 40.0);
        if (isCaptain()) {
            b.add(Attributes.ARMOR_TOUGHNESS, 8.0);
            b.add(Attributes.MAX_ABSORPTION, 20.0);
        }
        return b;
    }
}
