package com.jockball.entity;

import com.jockball.entity.ai.Knock;
import com.jockball.item.ModItems;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** El balon: lo lanzan el quarterback, el pateador y el jugador. Atraviesa a los jugadores enemigos. */
public class FootballProjectile extends ThrowableItemProjectile {
    private float damage = 4.0F;

    public FootballProjectile(EntityType<? extends FootballProjectile> type, Level level) {
        super(type, level);
    }

    public void setDamage(float damage) {
        this.damage = damage;
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.FOOTBALL;
    }

    /** El balon no golpea a los jugadores del equipo enemigo (ni al que lo lanzo). */
    @Override
    protected boolean canHitEntity(Entity entity) {
        return !(entity instanceof FootballPlayer) && super.canHitEntity(entity);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity target = result.getEntity();
        if (this.level() instanceof ServerLevel serverLevel) {
            boolean hurt = target.hurtServer(serverLevel, this.damageSources().thrown(this, this.getOwner()), damage);
            if (hurt && target instanceof LivingEntity victim) {
                Vec3 v = this.getDeltaMovement();
                Knock.push(victim, 1.0, v.x, v.z);
            }
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide()) {
            this.discard();
        }
    }
}
