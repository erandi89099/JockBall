package com.jockball.entity;

import com.jockball.JockBall;
import com.jockball.gear.GearLevel;
import com.jockball.item.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.core.Holder;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Jugador enemigo. Fase 2: reutiliza el cuerpo y la IA del zombi (ataca, abre puertas, sigue al jugador)
 * pero sin quemarse al sol, sin bebes y sin drops. Mas adelante se reemplaza por una IA propia.
 *
 * Reserva: equipo nivel 1-3 al azar. Titular ({starter:1}): equipo nivel 4 y mas vida/dano/velocidad.
 * Capitan: equipo nivel 5 completo, absorcion 20, barra de jefe y es el unico que suelta el Trofeo.
 */
public class FootballPlayer extends Zombie {
    private static final Identifier ID_STARTER_HP = JockBall.id("starter_health");
    private static final Identifier ID_STARTER_ATK = JockBall.id("starter_attack");
    private static final Identifier ID_STARTER_SPD = JockBall.id("starter_speed");

    private final Position position;
    private boolean starter;
    private int gearLevel;
    private boolean equipped;
    private ServerBossEvent bossEvent;

    public FootballPlayer(EntityType<? extends FootballPlayer> type, Level level) {
        super(type, level);
        String path = BuiltInRegistries.ENTITY_TYPE.getKey(type).getPath();
        this.position = Position.byId(path);
        this.setPersistenceRequired(); // los jugadores del estadio no desaparecen solos
        if (position.isCaptain()) {
            this.bossEvent = new ServerBossEvent(
                    UUID.randomUUID(),
                    Component.translatable("entity.jockball.captain"),
                    BossEvent.BossBarColor.YELLOW,
                    BossEvent.BossBarOverlay.PROGRESS);
        }
    }

    public Position getFootballPosition() {
        return position;
    }

    public void setStarter(boolean starter) {
        this.starter = starter;
    }

    // ----- cosas de zombi que NO queremos -----
    @Override
    protected boolean isSunSensitive() {
        return false;
    }

    @Override
    public boolean isBaby() {
        return false;
    }

    // ----- equipo y estadisticas (se aplica una sola vez, en el servidor) -----
    private void boost(Holder<Attribute> attr, Identifier id, double amount) {
        AttributeInstance inst = this.getAttribute(attr);
        if (inst != null) {
            inst.addOrReplacePermanentModifier(
                    new AttributeModifier(id, amount, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
        }
    }

    private void equipOnce() {
        int level;
        if (position.isCaptain()) {
            level = 5;
        } else if (starter) {
            level = 4;
        } else {
            level = gearLevel > 0 ? gearLevel : 1 + this.random.nextInt(3);
        }
        gearLevel = level;

        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (int p = 0; p < 4; p++) {
            this.setItemSlot(slots[p], new ItemStack(ModItems.GEAR[level - 1][p]));
            this.setDropChance(slots[p], 0.0F);
        }
        // sin armas de zombi y nada de drops de equipo
        this.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        this.setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        this.setDropChance(EquipmentSlot.OFFHAND, 0.0F);

        if (starter && !position.isCaptain()) {
            boost(Attributes.MAX_HEALTH, ID_STARTER_HP, 0.5);   // +50% vida
            boost(Attributes.ATTACK_DAMAGE, ID_STARTER_ATK, 0.25); // +25% dano
            boost(Attributes.MOVEMENT_SPEED, ID_STARTER_SPD, 0.10); // +10% velocidad
        }
        // distintivo: nombre de la posicion (titulares y capitan lo muestran siempre)
        var name = Component.translatable("entity.jockball." + position.id).withStyle(position.color);
        if (starter && !position.isCaptain()) {
            name = Component.literal("★ ").withStyle(ChatFormatting.WHITE).append(name);
        }
        this.setCustomName(name);
        this.setCustomNameVisible(starter || position.isCaptain());

        this.setHealth(this.getMaxHealth());
        if (position.isCaptain()) {
            this.setAbsorptionAmount(20.0F);
        }
        equipped = true;
    }

    // ----- ciclo del servidor -----
    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) return;

        if (!equipped) {
            equipOnce();
        }

        if (bossEvent != null && this.level() instanceof ServerLevel serverLevel) {
            bossEvent.setProgress(Math.max(0.0F, this.getHealth() / this.getMaxHealth()));
            if (this.tickCount % 10 == 0) {
                // jugadores vivos y cercanos; cualquier otro (muerto, desconectado, lejos) sale de la barra
                Set<ServerPlayer> nearby = new HashSet<>();
                for (ServerPlayer player : serverLevel.players()) {
                    if (player.isAlive() && !player.isRemoved() && player.distanceToSqr(this) < 64.0 * 64.0) {
                        nearby.add(player);
                    }
                }
                for (ServerPlayer old : new ArrayList<>(bossEvent.getPlayers())) {
                    if (!nearby.contains(old)) {
                        bossEvent.removePlayer(old);
                    }
                }
                for (ServerPlayer player : nearby) {
                    bossEvent.addPlayer(player);
                }
            }
        }
    }

    @Override
    public void remove(RemovalReason reason) {
        if (bossEvent != null) {
            bossEvent.removeAllPlayers();
        }
        super.remove(reason);
    }

    // ----- guardado -----
    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putInt("starter", starter ? 1 : 0);
        output.putInt("gear_level", gearLevel);
        output.putInt("equipped", equipped ? 1 : 0);
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        this.starter = input.getInt("starter").orElse(0) == 1;
        this.gearLevel = input.getInt("gear_level").orElse(0);
        this.equipped = input.getInt("equipped").orElse(0) == 1;
    }
}
