package com.jockball.entity;

import com.jockball.JockBall;
import com.jockball.gear.GearLevel;
import com.jockball.entity.ai.ChargeGoal;
import com.jockball.entity.ai.StompGoal;
import com.jockball.gear.Fx;
import com.jockball.item.ModItems;
import com.jockball.stadium.StadiumDesign;
import com.jockball.stadium.StadiumRegistry;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.core.Holder;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Jugador enemigo. Fase 2: reutiliza el cuerpo y la IA del zombi (ataca, abre puertas, sigue al jugador)
 * pero sin quemarse al sol, sin bebes y sin drops. Mas adelante se reemplaza por una IA propia.
 *
 * Reserva: equipo nivel 1-3 al azar. Titular ({starter:1}): equipo nivel 4 y mas vida/dano/velocidad.
 * Capitan: equipo nivel 5 completo, absorcion 20, barra de jefe y es el unico que suelta el Trofeo.
 */
public class FootballPlayer extends Zombie {
    private static final Identifier ID_STARTER_HP = JockBall.id("starter_health");
    private static final Identifier ID_STARTER_ATK = JockBall.id("starter_attack");
    private static final Identifier ID_STARTER_SPD = JockBall.id("starter_speed");

    private final Position position;
    private boolean starter;
    private int gearLevel;
    private boolean equipped;
    private boolean dormant;
    private int homeX, homeY, homeZ, homeTotal;
    private int wakeRange;
    private ServerBossEvent bossEvent;
    private int nextJuke;

    public FootballPlayer(EntityType<? extends FootballPlayer> type, Level level) {
        super(type, level);
        String path = BuiltInRegistries.ENTITY_TYPE.getKey(type).getPath();
        this.position = Position.byId(path);
        this.setPersistenceRequired(); // los jugadores del estadio no desaparecen solos
        this.refreshDimensions();      // la hitbox sigue al tamano (atributo SCALE) desde el primer momento
        if (position.isCaptain()) {
            this.bossEvent = new ServerBossEvent(
                    UUID.randomUUID(),
                    Component.translatable("entity.jockball.captain"),
                    BossEvent.BossBarColor.YELLOW,
                    BossEvent.BossBarOverlay.PROGRESS);
        }
    }

    public Position getFootballPosition() {
        return position;
    }

    public void setStarter(boolean starter) {
        this.starter = starter;
    }

    /** Queda quieto (sin IA) hasta que un jugador se acerque a `range` bloques. */
    public void setDormant(int range) {
        this.dormant = true;
        this.wakeRange = range;
        this.setNoAi(true);
    }

    /** Marca a que estadio pertenece (centro del campo) y cuantos jugadores tenia al empezar. */
    public void setHome(int x, int y, int z, int total) {
        this.homeX = x;
        this.homeY = y;
        this.homeZ = z;
        this.homeTotal = total;
    }

    public boolean hasHome() { return homeTotal > 0; }
    public int getHomeX() { return homeX; }
    public int getHomeY() { return homeY; }
    public int getHomeZ() { return homeZ; }
    public int getHomeTotal() { return homeTotal; }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (position.isCaptain() && hasHome() && this.level() instanceof ServerLevel sl) {
            StadiumRegistry.markCleared(homeX, homeZ, sl.getGameTime());
            for (ServerPlayer p : sl.players()) {
                if (Math.abs(p.getBlockX() - homeX) <= StadiumDesign.HALF_X + 4
                        && Math.abs(p.getBlockZ() - homeZ) <= StadiumDesign.HALF_Z + 4) {
                    p.sendSystemMessage(Component.translatable("jockball.victory"));
                }
            }
        }
    }

    public boolean isDormant() {
        return dormant;
    }

    private void wake() {
        this.dormant = false;
        this.setNoAi(false);
    }

    // ----- habilidades por posicion -----
    @Override
    protected void registerGoals() {
        super.registerGoals();
        // OJO: esto se llama desde el constructor de Mob, antes de asignar `position`; la sacamos del tipo.
        Position pos = Position.byId(BuiltInRegistries.ENTITY_TYPE.getKey(this.getType()).getPath());
        if (pos == Position.LINEBACKER || pos == Position.CAPTAIN) {
            this.goalSelector.addGoal(1, new ChargeGoal(this)); // taclada tipo cabra
        }
        if (pos == Position.LINEMAN || pos == Position.CAPTAIN) {
            this.goalSelector.addGoal(1, new StompGoal(this));  // pisoton con fauces
        }
    }

    /** Golpe normal: safety CIEGA 3 s | apoyador LENTITUD III 5 s | corredor NO SALTAR 5 s | receptor NAUSEAS 5 s. */
    @Override
    public boolean doHurtTarget(ServerLevel level, Entity target) {
        boolean hit = super.doHurtTarget(level, target);
        if (hit && target instanceof LivingEntity victim) {
            if (position == Position.SAFETY) {
                victim.addEffect(new MobEffectInstance(Fx.get("blindness"), 60, 0));
            } else if (position == Position.LINEBACKER) {
                victim.addEffect(new MobEffectInstance(Fx.get("slowness"), 100, 2));     // Lentitud III, 5 s
            } else if (position == Position.RUNNING_BACK) {
                NoJump.apply(level, victim, 100);                                         // no puedes saltar, 5 s
            } else if (position == Position.RECEIVER) {
                victim.addEffect(new MobEffectInstance(Fx.get("nausea"), 100, 0));       // Nauseas, 5 s
            }
        }
        return hit;
    }

    private void positionAbilities() {
        LivingEntity target = this.getTarget();
        if (target == null || !target.isAlive() || dormant) return;
        double dist = this.distanceTo(target);

        // receptor: va saltando mientras te persigue
        if (position == Position.RECEIVER && this.onGround() && this.tickCount % 12 == 0 && dist < 20.0 && dist > 1.5) {
            this.getJumpControl().jump();
        }
        // corredor: escurridizo, se desvia de lado de golpe
        if (position == Position.RUNNING_BACK && this.onGround() && this.tickCount >= nextJuke && dist > 2.5 && dist < 9.0) {
            Vec3 to = new Vec3(target.getX() - this.getX(), 0, target.getZ() - this.getZ()).normalize();
            double side = this.random.nextBoolean() ? 1.0 : -1.0;
            this.setDeltaMovement(-to.z * side * 0.55 + to.x * 0.15, 0.25, to.x * side * 0.55 + to.z * 0.15);
            nextJuke = this.tickCount + 30 + this.random.nextInt(30);
        }
    }

    // ----- cosas de zombi que NO queremos -----
    @Override
    protected boolean isSunSensitive() {
        return false;
    }

    @Override
    public boolean isBaby() {
        return false;
    }

    // ----- equipo y estadisticas (se aplica una sola vez, en el servidor) -----
    private void boost(Holder<Attribute> attr, Identifier id, double amount) {
        AttributeInstance inst = this.getAttribute(attr);
        if (inst != null) {
            inst.addOrReplacePermanentModifier(
                    new AttributeModifier(id, amount, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
        }
    }

    private void equipOnce() {
        int level;
        if (position.isCaptain()) {
            level = 5;
        } else if (starter) {
            level = 4;
        } else {
            level = gearLevel > 0 ? gearLevel : 1 + this.random.nextInt(3);
        }
        gearLevel = level;

        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (int p = 0; p < 4; p++) {
            this.setItemSlot(slots[p], new ItemStack(ModItems.GEAR[level - 1][p]));
            this.setDropChance(slots[p], 0.0F);
        }
        // sin armas de zombi y nada de drops de equipo
        this.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        this.setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        this.setDropChance(EquipmentSlot.OFFHAND, 0.0F);

        if (starter && !position.isCaptain()) {
            boost(Attributes.MAX_HEALTH, ID_STARTER_HP, 0.5);   // +50% vida
            boost(Attributes.ATTACK_DAMAGE, ID_STARTER_ATK, 0.25); // +25% dano
            boost(Attributes.MOVEMENT_SPEED, ID_STARTER_SPD, 0.10); // +10% velocidad
        }
        // distintivo: nombre de la posicion (titulares y capitan lo muestran siempre)
        var name = Component.translatable("entity.jockball." + position.id).withStyle(position.color);
        if (starter && !position.isCaptain()) {
            name = Component.literal("★ ").withStyle(ChatFormatting.WHITE).append(name);
        }
        this.setCustomName(name);
        this.setCustomNameVisible(starter || position.isCaptain());

        this.refreshDimensions();
        this.setHealth(this.getMaxHealth());
        if (position.isCaptain()) {
            this.setAbsorptionAmount(20.0F);
        }
        equipped = true;
    }

    // ----- ciclo del servidor -----
    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) return;

        if (!equipped) {
            equipOnce();
        }

        positionAbilities();

        if (dormant && this.tickCount % 10 == 0 && this.level() instanceof ServerLevel wakeLevel) {
            var near = wakeLevel.getNearestPlayer(this, wakeRange);
            if (near != null && !near.isSpectator()) {
                wake();
                // al despertar uno, despiertan sus companeros cercanos
                for (FootballPlayer other : wakeLevel.getEntitiesOfClass(
                        FootballPlayer.class, this.getBoundingBox().inflate(25.0), FootballPlayer::isDormant)) {
                    other.wake();
                }
            }
        }

        if (bossEvent != null && this.level() instanceof ServerLevel serverLevel) {
            bossEvent.setProgress(Math.max(0.0F, this.getHealth() / this.getMaxHealth()));
            if (this.tickCount % 10 == 0) {
                // jugadores vivos y cercanos; cualquier otro (muerto, desconectado, lejos) sale de la barra
                Set<ServerPlayer> nearby = new HashSet<>();
                for (ServerPlayer player : serverLevel.players()) {
                    if (player.isAlive() && !player.isRemoved() && player.distanceToSqr(this) < 64.0 * 64.0) {
                        nearby.add(player);
                    }
                }
                for (ServerPlayer old : new ArrayList<>(bossEvent.getPlayers())) {
                    if (!nearby.contains(old)) {
                        bossEvent.removePlayer(old);
                    }
                }
                for (ServerPlayer player : nearby) {
                    bossEvent.addPlayer(player);
                }
            }
        }
    }

    @Override
    public void remove(RemovalReason reason) {
        if (bossEvent != null) {
            bossEvent.removeAllPlayers();
        }
        super.remove(reason);
    }

    // ----- guardado -----
    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putInt("starter", starter ? 1 : 0);
        output.putInt("gear_level", gearLevel);
        output.putInt("equipped", equipped ? 1 : 0);
        output.putInt("dormant", dormant ? 1 : 0);
        output.putInt("wake_range", wakeRange);
        output.putInt("home_x", homeX);
        output.putInt("home_y", homeY);
        output.putInt("home_z", homeZ);
        output.putInt("home_total", homeTotal);
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        this.starter = input.getInt("starter").orElse(0) == 1;
        this.gearLevel = input.getInt("gear_level").orElse(0);
        this.equipped = input.getInt("equipped").orElse(0) == 1;
        this.dormant = input.getInt("dormant").orElse(0) == 1;
        this.wakeRange = input.getInt("wake_range").orElse(0);
        this.homeX = input.getInt("home_x").orElse(0);
        this.homeY = input.getInt("home_y").orElse(0);
        this.homeZ = input.getInt("home_z").orElse(0);
        this.homeTotal = input.getInt("home_total").orElse(0);
    }
}
