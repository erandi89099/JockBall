package com.jockball.entity;

/**
 * Acciones que se animan en el cliente (modelo propio). El servidor las anuncia con FootballPlayer.setAction y el
 * cliente calcula el progreso con los ticks restantes. Las duraciones DEBEN coincidir con las de las habilidades.
 */
public final class Actions {
    public static final int NONE = 0;
    public static final int STOMP_WINDUP = 1;   // pisoton: sube los brazos
    public static final int STOMP_SLAM = 2;     // pisoton: golpe al suelo
    public static final int CHARGE_WINDUP = 3;  // taclada: se agacha y escarba
    public static final int CHARGING = 4;       // taclada: embistiendo
    public static final int STUNNED = 5;        // taclada: aturdido
    public static final int THROW_WINDUP = 6;   // balon: arma el brazo / pierna
    public static final int THROW_FOLLOW = 7;   // balon: lanza / patea
    public static final int SHOUT = 8;          // entrenador: grita una jugada
    public static final int ROAR = 9;           // capitan: cambio de fase

    public static int duration(int action) {
        return switch (action) {
            case STOMP_WINDUP -> 26;
            case STOMP_SLAM -> 8;
            case CHARGE_WINDUP -> 20;
            case CHARGING -> 24;
            case STUNNED -> 30;
            case THROW_WINDUP -> 14;
            case THROW_FOLLOW -> 8;
            case SHOUT -> 24;
            case ROAR -> 30;
            default -> 1;
        };
    }

    private Actions() {}
}
