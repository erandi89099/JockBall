package com.jockball.gear;

import com.jockball.JockBall;
import com.jockball.item.ModItems;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * Bonus por set completo. El nivel efectivo es el de la pieza MAS BAJA; si falta una pieza, es 0.
 * (Con 3 piezas nivel 4 y una nivel 3 -> bonus de nivel 3.)
 *
 * Cada nivel da: vida extra, fuerza, velocidad, armadura extra, saturacion, y desbloquea efectos:
 *   nivel 3+ Resistencia (I, II, III)  |  nivel 4+ Resistencia al fuego  |  nivel 5 Regeneracion I.
 * El equipo NO da resistencia al empuje (ni las piezas ni el set).
 *
 * El texto que se ve con F3+H en cada pieza sale de describe(), asi siempre coincide con estos numeros.
 */
public final class SetBonus {
    // Indice 0 = nivel 1 ... indice 4 = nivel 5.  AJUSTA AQUI EL BALANCE.
    private static final double HEALTH_PER_LEVEL = 4.0;                           // +2 corazones por nivel (24 .. 40 de vida)
    private static final double[] STRENGTH = {1.5, 3.0, 5.0, 7.5, 10.0};          // dano de ataque extra
    private static final double[] BONUS_ARMOR = {1.0, 2.0, 3.0, 4.0, 5.0};        // puntos de armadura extra
    private static final double[] SPEED = {0.04, 0.08, 0.13, 0.19, 0.26};         // +% velocidad (0.26 = +26%)
    private static final float[] SATURATION = {0.5f, 1.0f, 2.0f, 3.0f, 5.0f};     // saturacion repuesta cada 2 s
    private static final int[] RESISTANCE_AMP = {-1, -1, 0, 1, 2};                // efecto Resistencia (-1 = ninguno)
    private static final int FIRE_RESISTANCE_FROM = 4;
    private static final int REGENERATION_FROM = 5;

    private static final Identifier ID_HP = JockBall.id("set_health");
    private static final Identifier ID_STR = JockBall.id("set_strength");
    private static final Identifier ID_ARM = JockBall.id("set_armor");
    private static final Identifier ID_SPD = JockBall.id("set_speed");

    private static final EquipmentSlot[] SLOTS =
            {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    /** Nivel efectivo del set que lleva puesto el jugador (0-5). */
    public static int effectiveLevel(Player player) {
        int min = Integer.MAX_VALUE;
        for (EquipmentSlot slot : SLOTS) {
            min = Math.min(min, ModItems.levelOf(player.getItemBySlot(slot)));
        }
        return min == Integer.MAX_VALUE ? 0 : min;
    }

    private static void apply(Player player, Holder<Attribute> attr, Identifier id, double value,
                              AttributeModifier.Operation op) {
        AttributeInstance inst = player.getAttribute(attr);
        if (inst == null) return;
        if (value == 0.0) {
            inst.removeModifier(id);
        } else {
            inst.addOrUpdateTransientModifier(new AttributeModifier(id, value, op));
        }
    }

    private static void effect(ServerPlayer player, String id, int amplifier) {
        // 40 ticks y se renueva cada 10: oculto, sin particulas ni icono
        player.addEffect(new MobEffectInstance(Fx.get(id), 40, amplifier, true, false, false));
    }

    private static void update(ServerPlayer player, boolean feedSaturation) {
        int level = effectiveLevel(player);
        int i = level - 1;
        boolean on = level > 0;

        // vida: modificador PERMANENTE (se guarda con el jugador) para que al reconectar no se pierda ni se
        // regale curacion. Al subir el maximo tambien se cura esa diferencia.
        AttributeInstance hp = player.getAttribute(Attributes.MAX_HEALTH);
        if (hp != null && player.isAlive()) {
            AttributeModifier old = hp.getModifier(ID_HP);
            double before = old == null ? 0.0 : old.amount();
            double after = on ? HEALTH_PER_LEVEL * level : 0.0;
            if (after != before) {
                float current = player.getHealth();
                if (after == 0.0) {
                    hp.removeModifier(ID_HP);
                } else {
                    hp.addOrReplacePermanentModifier(new AttributeModifier(ID_HP, after, AttributeModifier.Operation.ADD_VALUE));
                }
                if (after > before) {
                    player.setHealth(Math.min(current + (float) (after - before), player.getMaxHealth()));
                }
            }
        }
        apply(player, Attributes.ATTACK_DAMAGE, ID_STR, on ? STRENGTH[i] : 0, AttributeModifier.Operation.ADD_VALUE);
        apply(player, Attributes.ARMOR, ID_ARM, on ? BONUS_ARMOR[i] : 0, AttributeModifier.Operation.ADD_VALUE);
        apply(player, Attributes.MOVEMENT_SPEED, ID_SPD, on ? SPEED[i] : 0, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);

        if (on) {
            if (RESISTANCE_AMP[i] >= 0) effect(player, "resistance", RESISTANCE_AMP[i]);
            if (level >= FIRE_RESISTANCE_FROM) effect(player, "fire_resistance", 0);
            if (level >= REGENERATION_FROM) effect(player, "regeneration", 0);
            if (feedSaturation) {
                player.getFoodData().eat(0, SATURATION[i]);
                com.jockball.Achievements.award(player, "first_set");
                if (level >= 2) com.jockball.Achievements.award(player, "set_2");
                if (level >= 3) com.jockball.Achievements.award(player, "set_3");
                if (level >= 4) com.jockball.Achievements.award(player, "set_4");
                if (level >= 5) com.jockball.Achievements.award(player, "max_set");
            }
        }
    }

    // ------------------------------------------------------------------ tooltip (F3+H)

    private static String num(double v) {
        return v == Math.rint(v) ? String.valueOf((long) v) : String.format("%.1f", v);
    }

    private static String roman(int n) {
        return switch (n) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            default -> "V";
        };
    }

    /** Lineas que se muestran con F3+H en las piezas de ese nivel. */
    public static List<Component> describe(int level) {
        int i = level - 1;
        List<Component> lines = new ArrayList<>();
        lines.add(Component.translatable("jockball.tooltip.header", level).withStyle(ChatFormatting.GOLD));
        double hp = HEALTH_PER_LEVEL * level;
        lines.add(Component.translatable("jockball.tooltip.health", num(hp), num(hp / 2), num(20 + hp),
                num((20 + hp) / 2)).withStyle(ChatFormatting.RED));
        lines.add(Component.translatable("jockball.tooltip.strength", num(STRENGTH[i])).withStyle(ChatFormatting.DARK_RED));
        lines.add(Component.translatable("jockball.tooltip.speed", num(Math.round(SPEED[i] * 100))).withStyle(ChatFormatting.AQUA));
        lines.add(Component.translatable("jockball.tooltip.armor", num(BONUS_ARMOR[i])).withStyle(ChatFormatting.BLUE));
        lines.add(Component.translatable("jockball.tooltip.saturation", num(SATURATION[i])).withStyle(ChatFormatting.GREEN));
        if (RESISTANCE_AMP[i] >= 0) {
            lines.add(Component.translatable("jockball.tooltip.resistance", roman(RESISTANCE_AMP[i] + 1))
                    .withStyle(ChatFormatting.LIGHT_PURPLE));
        }
        if (level >= FIRE_RESISTANCE_FROM) {
            lines.add(Component.translatable("jockball.tooltip.fire").withStyle(ChatFormatting.GOLD));
        }
        if (level >= REGENERATION_FROM) {
            lines.add(Component.translatable("jockball.tooltip.regeneration").withStyle(ChatFormatting.LIGHT_PURPLE));
        }
        lines.add(Component.translatable("jockball.tooltip.note").withStyle(ChatFormatting.GRAY));
        return lines;
    }

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int tick = server.getTickCount();
            if (tick % 10 != 0) return;
            boolean feed = tick % 40 == 0;
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                update(player, feed);
            }
        });
    }

    private SetBonus() {}
}
