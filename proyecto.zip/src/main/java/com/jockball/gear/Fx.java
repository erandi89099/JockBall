package com.jockball.gear;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.effect.MobEffect;

import java.util.HashMap;
import java.util.Map;

/** Busca efectos por su nombre de juego ("slowness", "resistance"...), sin depender del nombre en el codigo. */
public final class Fx {
    private static final Map<String, Holder<MobEffect>> CACHE = new HashMap<>();

    public static Holder<MobEffect> get(String id) {
        return CACHE.computeIfAbsent(id, k -> BuiltInRegistries.MOB_EFFECT.getOrThrow(
                ResourceKey.create(Registries.MOB_EFFECT, Identifier.withDefaultNamespace(k))));
    }

    private Fx() {}
}
