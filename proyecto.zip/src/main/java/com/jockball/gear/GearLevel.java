package com.jockball.gear;

import com.jockball.JockBall;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

import java.util.Map;

/**
 * Los 5 niveles de equipamiento. TODO el balance esta en esta tabla y en SetBonus:
 * si quieres cambiar numeros, es aqui.
 */
public final class GearLevel {
    public static final int MAX = 5;

    public static final TagKey<Item> REPAIRS_GEAR =
            TagKey.create(Registries.ITEM, JockBall.id("repairs_gear"));

    // Durabilidad base por nivel (multiplicador vanilla: cuero 5, hierro 15, diamante 33, netherite 37).
    // El nivel 1 es NETHERITE (37) y de ahi sube.
    private static final int[] DURABILITY = {37, 42, 48, 55, 65};
    // Defensa propia de cada pieza: {casco, pecho, fundas, tachos}.
    // Nivel 1 = netherite exacto (3/8/6/3 = 20). Ojo: el maximo de armadura del juego es 30, y el bonus de set
    // (SetBonus.BONUS_ARMOR: +1..+5) se suma encima. Por eso los totales base son 20/21/22/23/25 -> con bonus
    // quedan 21/23/25/27/30 y el nivel 5 llega justo al tope sin desperdiciar nada.
    private static final int[][] DEFENSE = {{3, 8, 6, 3}, {3, 9, 6, 3}, {3, 9, 7, 3}, {4, 9, 7, 3}, {4, 10, 8, 3}};
    // Dureza por pieza (netherite = 3). El tope del juego es 20 en total, o sea 5 por pieza: el nivel 5 lo alcanza.
    private static final float[] TOUGHNESS = {3.0f, 3.5f, 4.0f, 4.5f, 5.0f};
    // El equipo NO da resistencia al empuje (el netherite vanilla da 0.1 por pieza; aqui se quito a proposito).
    private static final float KNOCKBACK_RES = 0.0f;
    // Encantabilidad (netherite = 15, diamante = 10). Mas alto = mejores encantamientos en la mesa.
    private static final int[] ENCHANT = {15, 16, 17, 18, 20};

    private static Holder<SoundEvent> sound(int level) {
        return switch (level) {
            case 1 -> SoundEvents.ARMOR_EQUIP_LEATHER;
            case 2 -> SoundEvents.ARMOR_EQUIP_CHAIN;
            case 3 -> SoundEvents.ARMOR_EQUIP_IRON;
            case 4 -> SoundEvents.ARMOR_EQUIP_DIAMOND;
            default -> SoundEvents.ARMOR_EQUIP_NETHERITE;
        };
    }

    public static int baseDurability(int level) {
        return DURABILITY[level - 1];
    }

    public static ArmorMaterial material(int level) {
        int[] d = DEFENSE[level - 1];
        ResourceKey<EquipmentAsset> assetKey =
                ResourceKey.create(EquipmentAssets.ROOT_ID, JockBall.id("level_" + level));
        return new ArmorMaterial(
                baseDurability(level),
                Map.of(
                        ArmorType.HELMET, d[0],
                        ArmorType.CHESTPLATE, d[1],
                        ArmorType.LEGGINGS, d[2],
                        ArmorType.BOOTS, d[3]),
                ENCHANT[level - 1],
                sound(level),
                TOUGHNESS[level - 1],
                KNOCKBACK_RES,
                REPAIRS_GEAR,
                assetKey);
    }

    private GearLevel() {}
}
