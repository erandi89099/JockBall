package com.jockball.client;

import com.jockball.entity.Actions;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.monster.zombie.ZombieModel;
import net.minecraft.util.Mth;

/**
 * Modelo propio de los jugadores. Usa el cuerpo humanoide estandar (asi la armadura encaja) pero NO la pose de
 * zombi: cada posicion tiene su postura, y las habilidades tienen su animacion.
 *
 * Cuerpo, cabeza y brazos son piezas hermanas (no hijas), asi que para inclinar el torso se mueven a mano
 * (ver pose()). Convenciones: brazo xRot negativo = hacia delante/arriba; zRot positivo en el brazo derecho y
 * negativo en el izquierdo = hacia afuera; body xRot positivo = inclinado hacia delante.
 *
 * AJUSTA AQUI las poses: cada bloque "case" es la postura de una posicion; abajo estan las acciones.
 */
public class FootballModel extends ZombieModel<FootballRenderState> {
    public FootballModel(ModelPart root) {
        super(root);
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static float ease(float t) {
        t = Mth.clamp(t, 0.0F, 1.0F);
        return t * t * (3.0F - 2.0F * t);
    }

    // ---- valores de la pose que se va componiendo ----
    private float lean, twist, roll, headX;
    private float rax, ray, raz, lax, lay, laz;     // brazo derecho / izquierdo (x, y, z)
    private float legSpread, rightLegX, leftLegX;    // piernas (ademas del caminar)
    private boolean legsOverride;

    @Override
    public void setupAnim(FootballRenderState state) {
        super.setupAnim(state); // caminar de piernas, cabeza... (los brazos de zombi se sobreescriben abajo)

        float pos = state.walkAnimationPos;
        float spd = Mth.clamp(state.walkAnimationSpeed, 0.0F, 1.0F);
        float t = state.ageInTicks;
        float run = Mth.clamp(spd * 1.6F, 0.0F, 1.0F);
        float swing = Mth.cos(pos * 0.6662F) * spd * 1.2F;   // balanceo natural de brazos

        // ---- 1) postura base segun la posicion ----
        lean = 0; twist = 0; roll = 0; headX = head.xRot;
        rax = -swing; lax = swing; ray = 0; lay = 0; raz = 0.05F; laz = -0.05F;
        legSpread = 0; rightLegX = 0; leftLegX = 0; legsOverride = false;

        switch (state.position) {
            case LINEMAN -> {          // postura baja y ancha, brazos adelante listos para empujar
                lean = 0.28F + run * 0.10F; legSpread = 0.12F;
                rax = -1.0F - swing * 0.4F; lax = -1.0F + swing * 0.4F; raz = 0.14F; laz = -0.14F;
            }
            case LINEBACKER -> {       // agachado con los brazos abiertos, listo para taclear
                lean = 0.18F + run * 0.10F; legSpread = 0.06F;
                rax = -0.65F - swing * 0.5F; lax = -0.65F + swing * 0.5F; raz = 0.55F; laz = -0.55F;
            }
            case SAFETY -> {           // erguido, manos adelante
                lean = 0.05F + run * 0.08F;
                rax = -0.45F - swing * 0.6F; lax = -0.45F + swing * 0.6F; raz = 0.2F; laz = -0.2F;
            }
            case RUNNING_BACK -> {     // inclinado, brazos bombeando fuerte y el balon pegado al cuerpo
                lean = 0.22F + run * 0.16F;
                rax = -0.9F + (-swing * 0.8F); ray = -0.55F; raz = 0.0F;
                lax = -0.5F + swing * 1.6F;
            }
            case RECEIVER -> {         // manos arriba y al frente, listo para atrapar
                lean = 0.10F + run * 0.16F;
                rax = -1.25F - swing * 0.5F; lax = -1.25F + swing * 0.5F; raz = 0.18F; laz = -0.18F;
            }
            case QUARTERBACK -> {      // balon junto a la oreja y mano izquierda al frente
                lean = 0.05F + run * 0.08F;
                rax = -2.05F; raz = 0.30F; lax = -0.95F; lay = 0.45F; laz = -0.1F;
            }
            case KICKER -> {           // relajado, manos en la cintura
                lean = 0.04F + run * 0.08F;
                rax = -0.25F - swing; lax = -0.25F + swing; raz = 0.40F; laz = -0.40F;
            }
            case COACH -> {            // tabla de jugadas en el brazo izquierdo
                lean = 0.0F;
                lax = -1.15F; lay = 0.85F; laz = -0.1F; rax = -swing * 0.5F;
                headX += Mth.sin(t * 0.07F) * 0.05F;
            }
            case CAPTAIN -> {          // pecho afuera; en el ultimo cuarto, encorvado y amenazante
                lean = state.phase >= 3 ? 0.20F + run * 0.10F : -0.06F;
                raz = 0.30F; laz = -0.30F;
                if (state.phase >= 3) { rax = -0.6F - swing * 0.4F; lax = -0.6F + swing * 0.4F; }
            }
        }

        // ---- 2) acciones (animaciones de habilidades) ----
        if (state.action != Actions.NONE) {
            int total = Actions.duration(state.action);
            float p = 1.0F - Mth.clamp(state.actionTicks / (float) total, 0.0F, 1.0F); // 0 -> 1 durante la accion
            applyAction(state, p, t);
        }

        // ---- 3) golpe normal (vanilla: attackTime 0..1) ----
        if (state.attackTime > 0.0F) {
            float f = state.attackTime;
            rax -= Mth.sin(f * (float) Math.PI) * 1.7F;
            twist += Mth.sin(Mth.sqrt(f) * (float) (Math.PI * 2.0)) * 0.18F;
        }

        // ---- 4) aplicar ----
        float c = Mth.cos(lean), s = Mth.sin(lean);
        float neckY = 12.0F * (1.0F - c), neckZ = -12.0F * s;      // el cuello gira alrededor de la cadera
        body.xRot = lean; body.yRot = twist; body.zRot = roll;
        body.x = 0; body.y = neckY; body.z = neckZ;
        head.y = neckY; head.z = neckZ; head.xRot = headX;
        float shoulderY = 2.0F + 10.0F * (1.0F - c), shoulderZ = -10.0F * s;
        rightArm.y = shoulderY; leftArm.y = shoulderY; rightArm.z = shoulderZ; leftArm.z = shoulderZ;
        rightArm.xRot = rax; rightArm.yRot = ray; rightArm.zRot = raz;
        leftArm.xRot = lax; leftArm.yRot = lay; leftArm.zRot = laz;
        rightLeg.zRot = legSpread; leftLeg.zRot = -legSpread;
        if (legsOverride) { rightLeg.xRot = rightLegX; leftLeg.xRot = leftLegX; }
        hat.copyFrom(head);
    }

    private void applyAction(FootballRenderState state, float p, float t) {
        switch (state.action) {
            case Actions.STOMP_WINDUP -> {     // brazos al cielo, torso hacia atras
                float e = ease(p);
                lean = lerp(lean, -0.35F, e); headX -= 0.25F * e;
                rax = lerp(rax, -3.05F, e); lax = lerp(lax, -3.05F, e);
                raz = lerp(raz, 0.18F, e); laz = lerp(laz, -0.18F, e); ray = 0; lay = 0;
            }
            case Actions.STOMP_SLAM -> {       // golpe seco al suelo
                float q = ease(p * 1.6F);
                lean = lerp(-0.35F, 0.65F, q); headX += 0.3F * q;
                rax = lerp(-3.05F, -0.2F, q); lax = lerp(-3.05F, -0.2F, q);
                raz = 0.15F; laz = -0.15F; ray = 0; lay = 0;
            }
            case Actions.CHARGE_WINDUP -> {    // se agacha y escarba como un toro
                float e = ease(p);
                lean = lerp(lean, 0.55F, e); headX -= 0.7F * e;
                rax = lerp(rax, 0.5F, e); lax = lerp(lax, 0.5F, e); raz = 0.25F * e; laz = -0.25F * e;
                legsOverride = true;
                rightLegX = -0.9F * Math.abs(Mth.sin(t * 0.9F)) * e; leftLegX = 0.1F * e;
            }
            case Actions.CHARGING -> {         // en carrera: muy inclinado, brazos hacia atras
                lean = 0.78F; headX -= 0.55F;
                rax = 0.85F; lax = 0.85F; raz = 0.25F; laz = -0.25F; ray = 0; lay = 0;
                legsOverride = true;
                rightLegX = Mth.cos(t * 1.5F) * 1.2F; leftLegX = -Mth.cos(t * 1.5F) * 1.2F;
            }
            case Actions.STUNNED -> {          // aturdido: encorvado y tambaleando
                lean = 0.55F; headX += 0.5F;
                rax = 0.2F; lax = 0.2F; raz = 0.12F; laz = -0.12F; ray = 0; lay = 0;
                roll = Mth.sin(t * 0.35F) * 0.07F;
            }
            case Actions.THROW_WINDUP -> {     // brazo atras (o pierna atras, el pateador)
                float e = ease(p);
                twist = lerp(twist, -0.5F, e);
                if (state.position == com.jockball.entity.Position.KICKER) {
                    legsOverride = true; rightLegX = 0.9F * e; leftLegX = -0.1F * e;
                    rax = lerp(rax, -0.9F, e); lax = lerp(lax, -0.9F, e); raz = 0.8F * e; laz = -0.8F * e;
                } else {
                    rax = lerp(rax, -2.5F, e); raz = lerp(raz, 0.30F, e);
                    lax = lerp(lax, -1.5F, e); lay = 0.3F * e;
                }
            }
            case Actions.THROW_FOLLOW -> {     // el lanzamiento / la patada
                float q = ease(p * 1.5F);
                twist = lerp(-0.5F, 0.45F, q);
                if (state.position == com.jockball.entity.Position.KICKER) {
                    legsOverride = true; rightLegX = lerp(0.9F, -1.5F, q); leftLegX = 0.0F;
                    rax = -0.9F; lax = -0.9F; raz = 0.8F; laz = -0.8F;
                } else {
                    rax = lerp(-2.5F, -0.4F, q); raz = 0.2F; lax = -0.8F;
                }
            }
            case Actions.SHOUT -> {            // el entrenador senala y grita
                float e = (float) Math.sin(Mth.clamp(p, 0.0F, 1.0F) * Math.PI);
                rax = lerp(rax, -2.3F, e); raz = lerp(raz, -0.25F, e); ray = 0;
                headX -= 0.3F * e;
            }
            case Actions.ROAR -> {             // el Capitan ruge con los brazos abiertos
                float e = (float) Math.sin(Mth.clamp(p, 0.0F, 1.0F) * Math.PI);
                lean = lerp(lean, -0.25F, e); headX -= 0.6F * e;
                rax = lerp(rax, -0.3F, e); lax = lerp(lax, -0.3F, e);
                raz = lerp(raz, 1.45F, e); laz = lerp(laz, -1.45F, e); ray = 0; lay = 0;
            }
            default -> { }
        }
    }
}
