package com.jockball.client;

import com.jockball.entity.Actions;
import com.jockball.entity.Position;
import net.minecraft.client.renderer.entity.state.ZombieRenderState;

/** Datos del jugador que el modelo necesita para posar y animar (se copian del jugador en cada fotograma). */
public class FootballRenderState extends ZombieRenderState {
    public Position position = Position.LINEMAN;
    public int action = Actions.NONE;
    public int actionTicks = 0;
    public int phase = 1;
}
