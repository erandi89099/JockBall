package com.jockball.client;

import com.jockball.entity.FootballPlayer;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.AbstractZombieRenderer;
import net.minecraft.client.renderer.entity.ArmorModelSet;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.Identifier;

/**
 * Dibuja a los jugadores con el modelo propio (FootballModel). Reutiliza la estructura del render de zombi
 * (incluida la capa de armadura, que tambien usa nuestro modelo: asi la armadura se anima igual que el cuerpo)
 * pero con la piel de cada posicion.
 */
public class FootballRenderer
        extends AbstractZombieRenderer<FootballPlayer, FootballRenderState, FootballModel> {
    private final Identifier texture;

    public FootballRenderer(EntityRendererProvider.Context context, Identifier texture) {
        super(context,
                new FootballModel(context.bakeLayer(ModelLayers.ZOMBIE)),
                new FootballModel(context.bakeLayer(ModelLayers.ZOMBIE_BABY)),
                ArmorModelSet.bake(ModelLayers.ZOMBIE_ARMOR, context.getModelSet(), FootballModel::new),
                ArmorModelSet.bake(ModelLayers.ZOMBIE_BABY_ARMOR, context.getModelSet(), FootballModel::new));
        this.texture = texture;
    }

    @Override
    public FootballRenderState createRenderState() {
        return new FootballRenderState();
    }

    @Override
    public void extractRenderState(FootballPlayer entity, FootballRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.position = entity.getFootballPosition();
        state.action = entity.getAction();
        state.actionTicks = entity.getActionTicks();
        state.phase = entity.getPhase();
    }

    @Override
    public Identifier getTextureLocation(FootballRenderState state) {
        return texture;
    }
}
