package com.jockball.client;

import com.jockball.JockBall;
import com.jockball.entity.ModEntities;
import com.jockball.entity.Position;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.resources.Identifier;

public class JockBallClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        for (Position pos : Position.values()) {
            Identifier texture = JockBall.id("textures/entity/football/" + pos.id + ".png");
            EntityRenderers.register(ModEntities.TYPES.get(pos), ctx -> new FootballRenderer(ctx, texture));
        }
    }
}
