package com.jockball;

import com.jockball.entity.FootballPlayer;
import com.jockball.entity.ModEntities;
import com.jockball.entity.Position;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Logros (data/jockball/advancement/*.json). Todos usan el criterio "done" y se otorgan desde aqui:
 *   first_set / max_set  -> set completo puesto (SetBonus)
 *   match_1/5/10/20      -> veces que has derrotado a un Capitan (estadistica de vanilla)
 *   flawless             -> derrotar al Capitan sin recibir dano de ningun jugador de ese estadio
 *   coach / kicker       -> derrotar a los mini-jefes
 *   set_2/3/4            -> set completo de ese nivel
 *   stadium, scout, ball, timeout, converter -> primeras veces (entrar a un estadio, usar mapa, balon, silbato, Maxiconvertor)
 *   halftime / fourth_quarter -> presenciar esas fases del Capitan
 *   horde_25 / horde_100 -> jugadores derrotados en total | scouting -> derrotar a uno de cada posicion
 */
public final class Achievements {
    /** estadio (clave de su centro) -> jugadores que recibieron dano en la pelea */
    private static final Map<Long, Set<UUID>> HURT = new HashMap<>();

    private static long key(int hx, int hz) {
        return ((long) hx << 32) ^ (hz & 0xFFFFFFFFL);
    }

    public static void markHurt(int hx, int hz, UUID player) {
        HURT.computeIfAbsent(key(hx, hz), k -> new HashSet<>()).add(player);
    }

    /** Al (re)crear un estadio empieza una pelea limpia. */
    public static void resetFight(int hx, int hz) {
        HURT.remove(key(hx, hz));
    }

    public static void award(ServerPlayer player, String name) {
        AdvancementHolder holder = player.level().getServer().getAdvancements().get(JockBall.id(name));
        if (holder != null) {
            player.getAdvancements().award(holder, "done");
        }
    }

    public static void onKill(ServerPlayer killer, FootballPlayer victim) {
        switch (victim.getFootballPosition()) {
            case CAPTAIN -> {
                award(killer, "match_1");
                int wins = killer.getStats().getValue(Stats.ENTITY_KILLED.get(ModEntities.TYPES.get(Position.CAPTAIN)));
                if (wins >= 5) award(killer, "match_5");
                if (wins >= 10) award(killer, "match_10");
                if (wins >= 20) award(killer, "match_20");
                Set<UUID> hurt = HURT.remove(key(victim.getHomeX(), victim.getHomeZ()));
                if (hurt == null || !hurt.contains(killer.getUUID())) {
                    award(killer, "flawless");
                }
            }
            case COACH -> award(killer, "coach");
            case KICKER -> award(killer, "kicker");
            default -> { }
        }
        // totales de derrotas (estadistica de vanilla): 25, 100 y "uno de cada posicion"
        int total = 0;
        boolean all = true;
        for (Position pos : Position.values()) {
            int n = killer.getStats().getValue(Stats.ENTITY_KILLED.get(ModEntities.TYPES.get(pos)));
            total += n;
            if (n <= 0) all = false;
        }
        if (total >= 25) award(killer, "horde_25");
        if (total >= 100) award(killer, "horde_100");
        if (all) award(killer, "scouting");
    }

    private Achievements() {}
}
