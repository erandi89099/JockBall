"""Genera las 8 pinturas de JockBall (pixel art, 16 px por bloque). Uso: python3 tools/gen_paintings.py --force"""
import sys
if "--force" not in sys.argv:
    sys.exit("ATENCION: este script SOBRESCRIBE las pinturas. Usa --force si de verdad quieres regenerarlas.")
import json, math, os, random
from PIL import Image, ImageDraw

ROOT = os.path.join(os.path.dirname(__file__), "..")
A = os.path.join(ROOT, "src/main/resources/assets/jockball")
D = os.path.join(ROOT, "src/main/resources/data")
OUT = os.path.join(A, "textures/painting")
rnd = random.Random(2026)

def canvas(w, h, color=(0, 0, 0)):
    img = Image.new("RGB", (w * 16, h * 16), color)
    return img, ImageDraw.Draw(img)

def vgrad(d, W, H, top, bottom, y0=0, y1=None):
    y1 = H if y1 is None else y1
    for y in range(y0, y1):
        t = (y - y0) / max(1, y1 - y0 - 1)
        d.line([(0, y), (W, y)], fill=tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3)))

def frame(d, W, H, c=(60, 40, 25)):
    d.rectangle([0, 0, W - 1, H - 1], outline=c)

DIG = {  # fuente 3x5
 "0": "111101101101111", "1": "010110010010111", "2": "111001111100111", "3": "111001111001111",
 "4": "101101111001001", "5": "111100111001111", "6": "111100111101111", "7": "111001001001001",
 "8": "111101111101111", "9": "111101111001111", "-": "000000111000000"}
def digit(d, ch, x, y, c, s=1):
    for i, b in enumerate(DIG[ch]):
        if b == "1":
            d.rectangle([x + (i % 3) * s, y + (i // 3) * s, x + (i % 3) * s + s - 1, y + (i // 3) * s + s - 1], fill=c)

GOLD, GOLD_D, GOLD_L = (235, 190, 40), (165, 120, 20), (255, 235, 130)

# 1) estadio de noche 4x2
def night_stadium():
    img, d = canvas(4, 2); W, H = img.size
    vgrad(d, W, H, (8, 10, 40), (40, 40, 90), 0, 18)
    for _ in range(26): d.point((rnd.randrange(W), rnd.randrange(14)), fill=(230, 230, 255))
    for y in range(16, 24):                                         # gradas oscuras con luces de la gente
        d.rectangle([0, y, W, y], fill=(28, 30, 48) if y % 2 else (36, 38, 60))
        for x in range(rnd.randrange(3), W, 5): 
            if rnd.random() < 0.5: d.point((x, y), fill=(120, 120, 150))
    d.rectangle([0, 24, W, H], fill=(36, 120, 56))                  # campo
    for x in range(0, W, 8): d.line([(x, 24), (x - 6, H)], fill=(235, 235, 235))
    d.line([(0, 24), (W, 24)], fill=(235, 235, 235))
    for tx in (5, W - 6):                                           # torres de luces
        d.line([(tx, 4), (tx, 22)], fill=(60, 60, 70))
        d.rectangle([tx - 3, 2, tx + 3, 4], fill=(255, 245, 190))
        for r in range(1, 5): d.ellipse([tx - 3 - r, 3 - r, tx + 3 + r, 3 + r], outline=(100 + 30 * (5 - r), 100 + 30 * (5 - r), 70 + 10 * (5 - r)))
    frame(d, W, H); return img

# 2) trofeo 2x2
def trophy():
    img, d = canvas(2, 2); W, H = img.size
    for x in range(W): d.line([(x, 0), (x, H)], fill=(110, 18, 28) if (x // 4) % 2 else (130, 24, 34))
    d.rectangle([10, 24, 21, 27], fill=(70, 50, 30)); d.rectangle([8, 27, 23, 30], fill=(95, 68, 40))
    d.rectangle([14, 17, 17, 24], fill=GOLD_D)
    d.polygon([(8, 5), (23, 5), (21, 14), (17, 17), (14, 17), (10, 14)], fill=GOLD)
    d.polygon([(10, 6), (13, 6), (12, 13), (11, 13)], fill=GOLD_L)
    d.arc([2, 6, 10, 14], 90, 270, fill=GOLD); d.arc([21, 6, 29, 14], 270, 90, fill=GOLD)
    d.rectangle([8, 4, 23, 5], fill=GOLD_L)
    frame(d, W, H, (50, 10, 14)); return img

# 3) casco del capitan 2x2
def captain_helmet():
    img, d = canvas(2, 2, (12, 12, 16)); W, H = img.size
    for r in range(14, 0, -2): d.ellipse([16 - r, 16 - r, 16 + r, 16 + r], outline=(24 + (14 - r) * 3,) * 3)
    d.pieslice([6, 5, 27, 26], 180, 360, fill=GOLD)                 # cupula
    d.rectangle([6, 15, 27, 22], fill=GOLD)
    d.rectangle([5, 14, 27, 15], fill=GOLD_D)
    d.rectangle([14, 5, 17, 14], fill=(30, 30, 36))                 # franja central negra
    d.rectangle([20, 16, 27, 24], fill=(30, 30, 36))                # abertura de la cara
    for y in (17, 19, 21, 23): d.line([(19, y), (28, y)], fill=GOLD_L)   # barras de la mascara
    d.line([(19, 16), (19, 25)], fill=GOLD_L)
    d.rectangle([8, 17, 10, 21], fill=GOLD_D)                       # oreja
    d.text((10, 8), "C", fill=(30, 30, 36))
    d.pieslice([6, 5, 27, 26], 200, 250, fill=GOLD_L)
    frame(d, W, H, (50, 40, 10)); return img

# 4) pizarra de jugadas 2x1
def playbook():
    img, d = canvas(2, 1, (30, 70, 52)); W, H = img.size
    d.rectangle([0, 0, W - 1, H - 1], outline=(110, 74, 40)); d.rectangle([1, 1, W - 2, H - 2], outline=(80, 54, 30))
    for (x, y) in [(6, 4), (9, 8), (6, 12), (12, 4)]:               # O (defensa)
        d.ellipse([x - 2, y - 2, x + 2, y + 2], outline=(240, 240, 240))
    for (x, y) in [(20, 4), (24, 12), (20, 12), (27, 6)]:           # X (ataque)
        d.line([(x - 2, y - 2), (x + 2, y + 2)], fill=(240, 120, 110)); d.line([(x - 2, y + 2), (x + 2, y - 2)], fill=(240, 120, 110))
    d.line([(16, 8), (13, 8)], fill=(235, 235, 235)); d.line([(20, 12), (17, 8), (14, 4)], fill=(255, 235, 130))
    d.polygon([(14, 4), (16, 5), (15, 7)], fill=(255, 235, 130))
    return img

# 5) touchdown 3x2
def touchdown():
    img, d = canvas(3, 2); W, H = img.size
    vgrad(d, W, H, (30, 50, 120), (150, 40, 50), 0, 20)
    for x in range(0, W, 3):                                         # publico
        for y in range(8, 18): 
            if rnd.random() < 0.18: d.point((x + rnd.randrange(3), y), fill=rnd.choice([(255, 220, 120), (235, 235, 235), (255, 120, 120)]))
    d.rectangle([0, 20, W, H], fill=(190, 40, 52))                  # zona de anotacion
    for x in range(0, W, 8): d.line([(x, 20), (x - 4, H)], fill=(235, 235, 235))
    cx = 24                                                          # jugador festejando
    d.rectangle([cx - 4, 12, cx + 4, 22], fill=GOLD); d.rectangle([cx - 4, 12, cx + 4, 13], fill=GOLD_L)
    d.rectangle([cx - 3, 22, cx - 1, 29], fill=(235, 235, 235)); d.rectangle([cx + 1, 22, cx + 3, 29], fill=(235, 235, 235))
    d.ellipse([cx - 3, 5, cx + 3, 11], fill=(224, 172, 130)); d.pieslice([cx - 4, 3, cx + 4, 11], 180, 360, fill=GOLD_D)
    d.line([(cx - 4, 13), (cx - 9, 6)], fill=GOLD, width=2); d.line([(cx + 4, 13), (cx + 9, 6)], fill=GOLD, width=2)
    d.ellipse([cx + 8, 2, cx + 13, 6], fill=(139, 84, 45)); d.point((cx + 10, 4), fill=(240, 240, 240))
    frame(d, W, H); return img

# 6) corrillo 4x2 (vista desde arriba)
def huddle():
    img, d = canvas(4, 2); W, H = img.size
    for x in range(W): d.line([(x, 0), (x, H)], fill=(40, 120, 58) if (x // 8) % 2 else (46, 134, 64))
    for x in range(0, W, 16): d.line([(x, 0), (x, H)], fill=(225, 225, 225))
    cx, cy = 32, 16
    d.ellipse([cx - 11, cy - 11, cx + 11, cy + 11], outline=(255, 235, 130))
    cols = [(190, 40, 52), (235, 235, 235), (190, 40, 52), (235, 235, 235)] * 3
    for i in range(11):
        a = i * 2 * math.pi / 11
        x, y = cx + math.cos(a) * 8, cy + math.sin(a) * 8
        d.ellipse([x - 3, y - 3, x + 3, y + 3], fill=cols[i], outline=(20, 20, 30))
        d.ellipse([x - 1, y - 1, x + 1, y + 1], fill=(224, 172, 130))
    d.ellipse([cx - 2, cy - 2, cx + 2, cy + 2], fill=(139, 84, 45))
    frame(d, W, H); return img

# 7) postes de gol 1x2
def goalposts():
    img, d = canvas(1, 2); W, H = img.size
    vgrad(d, W, H, (110, 170, 235), (200, 225, 245), 0, 26); d.rectangle([0, 26, W, H], fill=(40, 120, 56))
    d.line([(8, 14), (8, 28)], fill=(250, 220, 40), width=2)        # poste
    d.line([(3, 14), (13, 14)], fill=(250, 220, 40), width=2)       # travesano
    d.line([(3, 3), (3, 14)], fill=(250, 220, 40), width=2); d.line([(13, 3), (13, 14)], fill=(250, 220, 40), width=2)
    d.point((3, 2), fill=(255, 80, 60)); d.point((13, 2), fill=(255, 80, 60))
    frame(d, W, H, (50, 70, 60)); return img

# 8) marcador 3x1
def scoreboard():
    img, d = canvas(3, 1, (14, 14, 18)); W, H = img.size
    d.rectangle([0, 0, W - 1, H - 1], outline=(70, 70, 80)); d.rectangle([2, 2, W - 3, H - 3], outline=(40, 40, 48))
    amber, dim = (255, 170, 30), (90, 56, 12)
    d.rectangle([4, 3, 19, 5], fill=(30, 30, 40)); d.rectangle([28, 3, 43, 5], fill=(30, 30, 40))
    for x in range(5, 19, 3): d.point((x, 4), fill=(235, 235, 235))     # "LOCAL" / "VISITA" simbolicos
    for x in range(29, 43, 3): d.point((x, 4), fill=(235, 235, 235))
    for i, ch in enumerate("21"): digit(d, ch, 5 + i * 5, 7, amber, 1); digit(d, "8", 5 + i * 5, 7, dim, 1) if False else None
    digit(d, "-", 21, 8, amber, 1)
    for i, ch in enumerate("14"): digit(d, ch, 29 + i * 5, 7, amber, 1)
    d.rectangle([22, 3, 25, 5], fill=(200, 60, 50))                      # luz de "tiempo"
    return img

PAINTINGS = {  # id: (ancho, alto, funcion, titulo_es, titulo_en)
 "night_stadium":  (4, 2, night_stadium,  "Noche de partido",        "Game Night"),
 "trophy":         (2, 2, trophy,         "El Trofeo",               "The Trophy"),
 "captain_helmet": (2, 2, captain_helmet, "Casco del Capitán",       "Captain's Helmet"),
 "playbook":       (2, 1, playbook,       "Libro de jugadas",        "Playbook"),
 "touchdown":      (3, 2, touchdown,      "¡Touchdown!",             "Touchdown!"),
 "huddle":         (4, 2, huddle,         "El corrillo",             "The Huddle"),
 "goalposts":      (1, 2, goalposts,      "Postes de gol",           "Goalposts"),
 "scoreboard":     (3, 1, scoreboard,     "Marcador",                "Scoreboard"),
}

os.makedirs(OUT, exist_ok=True)
os.makedirs(os.path.join(D, "jockball/painting_variant"), exist_ok=True)
os.makedirs(os.path.join(D, "minecraft/tags/painting_variant"), exist_ok=True)
for pid, (w, h, fn, es, en) in PAINTINGS.items():
    img = fn()
    assert img.size == (w * 16, h * 16), (pid, img.size)
    img.save(os.path.join(OUT, f"{pid}.png"))
    json.dump({"asset_id": f"jockball:{pid}", "width": w, "height": h,
               "title": {"translate": f"painting.jockball.{pid}.title"},
               "author": {"translate": f"painting.jockball.{pid}.author"}},
              open(os.path.join(D, f"jockball/painting_variant/{pid}.json"), "w"), indent=2)
json.dump({"values": [f"jockball:{p}" for p in PAINTINGS]},
          open(os.path.join(D, "minecraft/tags/painting_variant/placeable.json"), "w"), indent=2)
for f in os.listdir(os.path.join(A, "lang")):
    path = os.path.join(A, "lang", f)
    d = json.load(open(path, encoding="utf-8"))
    for pid, (w, h, fn, es, en) in PAINTINGS.items():
        d[f"painting.jockball.{pid}.title"] = en if f == "en_us.json" else es
        d[f"painting.jockball.{pid}.author"] = "InventorPWB"
    json.dump(d, open(path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
print("pinturas:", list(PAINTINGS))
