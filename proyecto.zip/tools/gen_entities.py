"""Genera pieles (64x64), nombres y loot de los jugadores enemigos. Uso: python3 tools/gen_entities.py"""
import json, os
from PIL import Image

ROOT = os.path.join(os.path.dirname(__file__), "..")
A = os.path.join(ROOT, "src/main/resources/assets/jockball")
D = os.path.join(ROOT, "src/main/resources/data/jockball")

# id: (jersey, jersey_dark, pants, nombre_es, nombre_en, numero)
POS = {
    "lineman":      ((150, 30, 35),  (100, 18, 22),  (230, 230, 230), "Liniero",   "Lineman",      "7"),
    "running_back": ((235, 130, 30), (160, 85, 15),  (40, 40, 45),    "Corredor",  "Running Back", "2"),
    "receiver":     ((70, 160, 230), (40, 100, 160), (235, 235, 235), "Receptor",  "Receiver",     "1"),
    "linebacker":   ((120, 60, 170), (75, 35, 110),  (200, 200, 205), "Apoyador",  "Linebacker",   "5"),
    "safety":       ((30, 150, 140), (18, 95, 90),   (40, 40, 45),    "Safety",    "Safety",       "3"),
    "captain":      ((235, 190, 40), (160, 120, 20), (25, 25, 30),    "Capitán",   "Captain",      "1"),
}
SKIN, SKIN_D, HAIR, EYE, WHITE = (224, 172, 130), (190, 140, 100), (60, 40, 25), (30, 30, 35), (245, 245, 245)

DIGITS = {
 "1": ["..#..", ".##..", "..#..", "..#..", "..#..", ".###."],
 "2": [".###.", "#...#", "...#.", "..#..", ".#...", "#####"],
 "3": ["####.", "....#", ".###.", "....#", "....#", "####."],
 "5": ["#####", "#....", "####.", "....#", "#...#", ".###."],
 "7": ["#####", "....#", "...#.", "..#..", ".#...", ".#..."],
}

def paint_box(img, x, y, W, H, Dp, fn):
    """fn(face, i, j) -> color o None. Mapa UV vanilla de una caja WxHxD en (x,y)."""
    px = img.load()
    faces = {
        "top": (x + Dp, y, W, Dp), "bottom": (x + Dp + W, y, W, Dp),
        "right": (x, y + Dp, Dp, H), "front": (x + Dp, y + Dp, W, H),
        "left": (x + Dp + W, y + Dp, Dp, H), "back": (x + 2 * Dp + W, y + Dp, W, H)}
    for face, (fx, fy, fw, fh) in faces.items():
        for j in range(fh):
            for i in range(fw):
                c = fn(face, i, j)
                if c is not None:
                    px[fx + i, fy + j] = tuple(c) + (255,)

def make(pid):
    jersey, jdark, pants, _, _, num = POS[pid]
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))

    def head(face, i, j):
        if face == "front":
            if j < 2: return HAIR
            if j == 3 and i in (1, 2, 5, 6): return EYE
            if j == 5 and 2 <= i <= 5: return SKIN_D
            return SKIN
        if face in ("top",): return HAIR
        if face in ("back",): return HAIR if j < 6 else SKIN_D
        if face in ("left", "right"): return HAIR if j < 2 else SKIN
        return SKIN_D
    paint_box(img, 0, 0, 8, 8, 8, head)

    digit = DIGITS[num]
    def body(face, i, j):
        if face in ("front", "back"):
            if face == "front" and 1 <= j <= 6 and 1 <= i <= 5 and digit[j - 1][i - 1] == "#":
                return WHITE
            if face == "back" and 2 <= j <= 7 and 1 <= i <= 5 and digit[j - 2][i - 1] == "#":
                return WHITE
            return jersey if j < 11 else jdark
        return jdark
    paint_box(img, 16, 16, 8, 12, 4, body)

    def arm(face, i, j):
        if j < 4: return jersey if face != "bottom" else SKIN
        if j == 4: return WHITE
        return SKIN if face != "bottom" else SKIN_D
    paint_box(img, 40, 16, 4, 12, 4, arm)   # brazo derecho
    paint_box(img, 32, 48, 4, 12, 4, arm)   # brazo izquierdo

    def leg(face, i, j):
        if j < 8: return pants
        if j < 10: return WHITE
        return jdark
    paint_box(img, 0, 16, 4, 12, 4, leg)    # pierna derecha
    paint_box(img, 16, 48, 4, 12, 4, leg)   # pierna izquierda

    out = os.path.join(A, "textures/entity/football")
    os.makedirs(out, exist_ok=True)
    img.save(os.path.join(out, f"{pid}.png"))

for pid in POS:
    make(pid)

# nombres (se unen a los de objetos)
for lang, idx in (("es_es", 3), ("en_us", 4)):
    path = os.path.join(A, f"lang/{lang}.json")
    data = json.load(open(path, encoding="utf-8"))
    for pid, v in POS.items():
        data[f"entity.jockball.{pid}"] = v[idx]
    data["entity.jockball.captain"] = POS["captain"][idx]
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# loot: solo el capitan suelta el Trofeo
cap = os.path.join(D, "loot_table/entities")
os.makedirs(cap, exist_ok=True)
with open(os.path.join(cap, "captain.json"), "w") as f:
    json.dump({"type": "minecraft:entity", "pools": [{"rolls": 1, "entries": [
        {"type": "minecraft:item", "name": "jockball:trophy"}]}]}, f, indent=2)
print("Entidades generadas.")
