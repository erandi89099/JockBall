# JockBall 1.0 — Football americano para Minecraft (Fabric 26.2)

Mod de late game: encuentra estadios-mazmorra, vence a 53 jugadores y a su Capitán, y sube de nivel tu equipamiento
de football hasta el set legendario. Pensado para **un jugador**. Dificultad fija y alta: lo que se facilita es tu equipo.

## Requisitos
Minecraft **26.2**, Fabric Loader 0.19.3+, **Fabric API** 0.150.1+26.2 y Java 25. Pon `jockball-1.0.0.jar` y Fabric API en `mods`.
Todos los objetos están en la pestaña **JockBall** del creativo.

## La progresión
1. **Consigue equipo viejo (nivel 1)** — es de nivel *netherite* y MUY difícil de conseguir:
   - Compralo al **Vendedor de Equipo** de las tiendas de aldea: 64 esmeraldas + la pieza de netherite equivalente
     (casco → casco, hombreras → pechera, fundas → pantalón, tachos → botas).
   - Con suerte: 30% de soltar una pieza al derrotar al Warden, Dragón, Wither o Guardián Anciano; muy raro en cofres
     de tiendas (casco 1%) y vestidores (tachos 2%); mas raro aun con el Maxiconvertor.
2. **Encuentra un estadio** — usa un **Mapa de Estadio** (cofres de tiendas, mansiones, ruinas y barcos hundidos;
   los cartografos lo venden) o el comando `/jockball locate`.
3. **Vence al Capitán** (un "partido"). Es el único que suelta el **Trofeo**.
4. **Mejora una pieza** en la mesa de herrería: *Plantilla de Mejora* + pieza + *Trofeo* → un nivel más.
   La plantilla: tienda (64 esmeraldas + 1 netherite), 1.5% Maxiconvertor, 3% cofres de tienda/estadio, 10% en
   Ciudades Antiguas, Ciudades del End y Minas. Se repara con lingotes de netherite en el yunque o con Reparación.
5. **20 partidos** para llegar al nivel 5. Los estadios se reinician solos tras vencer al Capitán.

## Bonus de set (con las 4 piezas; cuenta la de menor nivel). F3+H en una pieza muestra su set.
| Nivel | Vida | Fuerza | Velocidad | Armadura extra | Saturación | Efectos |
|---|---|---|---|---|---|---|
| 1 | 24 (12 ♥) | +1.5 | +4% | +1 | 0.5 | |
| 2 | 28 | +3 | +8% | +2 | 1 | |
| 3 | 32 | +5 | +13% | +3 | 2 | Resistencia I |
| 4 | 36 | +7.5 | +19% | +4 | 3 | Resistencia II, Res. al fuego |
| 5 | 40 (20 ♥) | +10 | +26% | +5 | 5 | Resistencia III, Res. al fuego, Regeneración I |

Sin resistencia al empuje. Las piezas se pueden encantar como cualquier armadura.

## El estadio (193 × 241 bloques)
53 jugadores *dormidos* que despiertan al acercarte: 10 titulares + Capitán en el campo, 39 de reserva en gradas,
pasillos y vestidores, un **Entrenador** en la banda y un **Pateador** en cada zona de anotación (mini-jefes).
Los vestidores tienen cofres con botín de late game (silbatos, discos —incluido **"Pass"**, la música del mod—, y 5% de libros con Lealtad/Perforación). Una barra roja muestra los jugadores restantes.
Los jugadores tienen **modelo y animaciones propias**: postura distinta por posición y animación para el pisotón, la taclada, el lanzamiento/patada, las órdenes del entrenador y el rugido del Capitán.

| Posición | Habilidad |
|---|---|
| Liniero | Pisotón: fauces del invocador + onda que te lanza con Levitación IV |
| Apoyador | Taclada tipo cabra; su golpe da Lentitud III |
| Safety | Su golpe da Ceguera |
| Corredor | Se desvía de lado; su golpe te impide saltar |
| Receptor | Salta 3 bloques; su golpe da Náuseas |
| Quarterback | Lanza balones |
| Pateador (mini-jefe) | Abanico de 5 a 10 balones |
| Entrenador (mini-jefe) | Potencia a todo el equipo; se esconde tras los linieros o huye |
| **Capitán (jefe)** | Taclada + pisotón. **50% de vida: medio tiempo** (4 refuerzos). **25%: último cuarto** — más rápido, **trepa muros** como una araña, golpes que ciegan, ralentizan e **impiden saltar**, lluvia de balones |

## Objetos
Silbato (congela enemigos 3 s, no a jefes) · Balón (clic derecho, 4 cuero + 1 hilo → 4) · Mapa de Estadio ·
Maxiconvertor (10 usos, convierte animales pacíficos en botín) · Bebida energética · Barrita de proteína · 24 logros.

**Balón de Élite** — un balón rodeado de 8 lingotes de netherite (solo se obtiene crafteándolo). Clic derecho para
lanzarlo: 9 de daño, no se gasta (pierde 1 de durabilidad por lanzamiento). Encantable con **Lealtad** (vuelve a tu mano),
**Perforación** (atraviesa enemigos), **Filo**, **Irrompibilidad** y **Reparación**. Lealtad y Perforación son
encantamientos propios del balón (los de vanilla son del tridente y la ballesta).

**Disco "Pass"** — música original del mod (66 s), solo sale en los estadios (también cae con cualquier otro disco). Se puede reemplazar: ver `GUIA_DE_ARCHIVOS.md`.

**8 pinturas** de football (Noche de partido, El Trofeo, Casco del Capitán, Libro de jugadas, ¡Touchdown!, El corrillo,
Postes de gol y Marcador) en el catálogo normal de pinturas.

**Huevos generadores** de los 9 jugadores en el creativo (solo creativo): salen despiertos como reservas.

## Comandos (sin restricción de permisos: pensado para un jugador)
`/jockball locate` (o `locate stadium`) · `/jockball locate shop` — las coordenadas devueltas son **clicables**: al pulsarlas
se escribe el `/tp` en el chat (necesitas comandos activados). `/jockball stadium` (construye uno donde estés; reemplaza lo que
haya) · `/jockball shop` (construye una tienda delante de ti).
(El `/locate` de vanilla no encuentra estas estructuras porque se colocan por código y no son estructuras del mundo.)

## Configuración
`config/jockball.properties` (se crea al primer arranque): estadios naturales on/off, frecuencia de estadios y tiendas,
minutos de reinicio. El resto del balance está en las tablas al inicio de cada clase (ver `LEEME.md`).

## Créditos y licencia
Autor: InventorPWB. Las rutas de audios, pinturas y texturas reemplazables están en `GUIA_DE_ARCHIVOS.md`. Todos los derechos reservados. Texturas, sonidos y modelos incluidos son provisionales y reemplazables.
