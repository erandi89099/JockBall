# Guía de archivos reemplazables (JockBall)

Todas las rutas son relativas a la carpeta del proyecto. Para reemplazar un archivo: **mismo nombre y mismo tamaño**,
copia el tuyo encima, sube el `proyecto.zip` y compila. Los idiomas están en `assets/jockball/lang/` (es_es, es_ar, es_cl, es_mx, es_uy, es_ve y en_us).

## Audios (formato .ogg Vorbis, mono recomendado)
| Qué es | Archivo | Notas |
|---|---|---|
| Murmullo de multitud (ambiente del estadio) | `src/main/resources/assets/jockball/sounds/crowd.ogg` | 12 s, se repite mientras estás dentro. Volumen en `sounds.json` (0.5) |
| Ovación (fases del Capitán y victoria) | `src/main/resources/assets/jockball/sounds/cheer.ogg` | 4 s |
| **Disco "Pass"** | `src/main/resources/assets/jockball/sounds/music/pass.ogg` | 66 s. Si cambias la duración, edita `length_in_seconds` en `src/main/resources/data/jockball/jukebox_song/pass.json` |
| Qué sonido es cuál | `src/main/resources/assets/jockball/sounds.json` | enlaza cada evento con su .ogg |

## Pinturas (16 píxeles por bloque, PNG)
Carpeta: `src/main/resources/assets/jockball/textures/painting/`
| Archivo | Tamaño en píxeles | Bloques | Nombre en el juego |
|---|---|---|---|
| `night_stadium.png` | 64×32 | 4×2 | Noche de partido |
| `trophy.png` | 32×32 | 2×2 | El Trofeo |
| `captain_helmet.png` | 32×32 | 2×2 | Casco del Capitán |
| `playbook.png` | 32×16 | 2×1 | Libro de jugadas |
| `touchdown.png` | 48×32 | 3×2 | ¡Touchdown! |
| `huddle.png` | 64×32 | 4×2 | El corrillo |
| `goalposts.png` | 16×32 | 1×2 | Postes de gol |
| `scoreboard.png` | 48×16 | 3×1 | Marcador |
Tamaños/títulos: `src/main/resources/data/jockball/painting_variant/<nombre>.json` (si cambias el tamaño, cambia `width`/`height` en bloques).

## Texturas
- **Objetos (16×16):** `src/main/resources/assets/jockball/textures/item/` — 39 archivos:
  `captain_spawn_egg.png, cleats_l1.png, cleats_l2.png, cleats_l3.png, cleats_l4.png, cleats_l5.png, coach_spawn_egg.png, elite_football.png, energy_drink.png, football.png, helmet_l1.png, helmet_l2.png, helmet_l3.png, helmet_l4.png, helmet_l5.png, kicker_spawn_egg.png, linebacker_spawn_egg.png, lineman_spawn_egg.png, maxiconvertor.png, music_disc_pass.png, pants_l1.png, pants_l2.png, pants_l3.png, pants_l4.png, pants_l5.png, protein_bar.png, quarterback_spawn_egg.png, receiver_spawn_egg.png, running_back_spawn_egg.png, safety_spawn_egg.png, shoulder_pads_l1.png, shoulder_pads_l2.png, shoulder_pads_l3.png, shoulder_pads_l4.png, shoulder_pads_l5.png, stadium_map.png, trophy.png, upgrade_template.png, whistle.png`
  (incluye `music_disc_pass.png` = el disco nuevo, y los huevos `*_spawn_egg.png`).
- **Armadura puesta (64×32):** `src/main/resources/assets/jockball/textures/entity/equipment/humanoid/level_1..5.png` (casco, pechera y botas) y `.../humanoid_leggings/level_1..5.png` (fundas).
- **Pieles de los jugadores (64×64):** `src/main/resources/assets/jockball/textures/entity/football/`: `captain.png, coach.png, kicker.png, linebacker.png, lineman.png, quarterback.png, receiver.png, running_back.png, safety.png`.
  Se pintan sobre el modelo humanoide estándar (la capa exterior/sombrero no se usa).
- **Icono del mod (128×128):** `src/main/resources/assets/jockball/icon.png`.
- Modelos de objetos: `.../assets/jockball/models/item/*.json` y `.../assets/jockball/items/*.json` (no hace falta tocarlos si mantienes los nombres).

## Cómo reemplazar las estructuras (estadio y tienda)
Hoy se dibujan por **código** (funciones puras que dicen qué bloque va en cada coordenada):
- Estadio: `src/main/java/com/jockball/stadium/StadiumDesign.java` (forma, gradas, campo, túneles, vestidores, techos, paletas por bioma y por equipo). Jugadores: `StadiumRoster.java`. Cofres con loot: `data/jockball/loot_table/chests/locker_room.json`.
- Tienda: `src/main/java/com/jockball/shop/ShopDesign.java` (+ `ShopBuilder.java` para el vendedor y sus ofertas).
Tres caminos, de menos a más trabajo:
1. **Retocar el diseño actual:** cambia las constantes/colores de `StadiumDesign.java` / `ShopDesign.java` (filas, alturas, bloques por bioma...). Es lo más sencillo y encaja con el reinicio automático.
2. **Poner una construcción tuya (recomendado):** constrúyela en el juego, guárdala con un *bloque de estructura* (modo Guardar; queda como `.nbt` en `generated/minecraft/structures/` del mundo) o conviértela desde Litematica ("Guardar como estructura vanilla"), y colócala en `src/main/resources/data/jockball/structure/stadium.nbt` (o `shop.nbt`). Hace falta una pequeña modificación de código para que el constructor la use en vez de la función; en ella irían: dónde están los 53 jugadores (marcadores), los cofres (con `LootTable: "jockball:chests/locker_room"`) y el centro del campo. Pídemelo y lo agrego, con una opción en `config/jockball.properties` para elegir entre el diseño por código y tu archivo.
3. **Reescribir `StadiumDesign.column(...)` completo** con tu propio diseño procedural (para expertos en Java).
Límites: el estadio actual ocupa 193×241×50 bloques; un diseño mayor solo sirve con el comando `/jockball stadium` (la generación natural se detiene a unos 128 bloques del centro).
